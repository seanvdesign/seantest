if(!window.cp)window.cp = function(str){return document.getElementById(str)};cp.CPProjInit = function(){if(cp && cp.model && cp.model.data) return; cp.model = {}; cp.poolResources = {}; cp.D = cp.model.data = {
pref:{
acc:1,
rkt:1,
hsr:0,
atp:false
},
si486:{
name:'Simulation_1',
type:1268,
from:2056,
to:2145,
rp:0,
rpa:0,
mdi:'si486c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si478',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si486c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:486,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si486',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si478:{
name:'Simulation_non_responsive_1',
type:1268,
from:2056,
to:2145,
rp:0,
rpa:0,
mdi:'si478c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si486',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si577',
t:612
}
,{
n:'si588',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":true,"slide-item-inputfield":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":1,"slide-item-inputfield":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si486',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si478c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:478,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si478',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:494,
tsp:50,
ip:'dr/0494.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si577:{
name:'Instructions_1',
type:612,
from:2056,
to:2145,
rp:0,
rpa:0,
mdi:'si577c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Select ( + ) ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":13,"style":"fontStyle:normal"},{"offset":0,"length":13,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":13,"style":"hlnkt:wp"},{"offset":0,"length":13,"style":"tablet-fontSize:20"},{"offset":0,"length":13,"style":"textOutlineEnable:false"},{"offset":0,"length":13,"style":"opacity:1"},{"offset":0,"length":13,"style":"hlnke:true"},{"offset":0,"length":13,"style":"backgroundColor:unset"},{"offset":0,"length":13,"style":"fontStretch:normal"},{"offset":0,"length":13,"style":"fontType:regular"},{"offset":0,"length":13,"style":"fontFamily:Tahoma"},{"offset":0,"length":13,"style":"lineHeight:135%"},{"offset":0,"length":13,"style":"letterSpacing:0%"},{"offset":0,"length":13,"style":"textHighlightEnable:false"},{"offset":0,"length":13,"style":"textTransform:none"},{"offset":0,"length":13,"style":"color:#020C1C"},{"offset":0,"length":13,"style":"overridden:true"},{"offset":0,"length":13,"style":"textDecoration:none"},{"offset":0,"length":13,"style":"desktop-fontSize:20"},{"offset":0,"length":13,"style":"borderBottomStyle:none"},{"offset":0,"length":13,"style":"textShadowEnable:false"},{"offset":0,"length":13,"style":"hlnk:"},{"offset":0,"length":13,"style":"fontWeight:normal"},{"offset":0,"length":13,"style":"mobile-fontSize:20"}],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1},"overriddenProperties":[60004,"fillColor",60005],"appearenceProperties":{"fill":{"color":"#CDD1DEFF"},"shadow":{},"stroke":{}}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":78.98743386243386,"left":1097.8054453262787,"width":238.4218000399787}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
oh:'{"scripts":[{"then":[["cp.toggleView([\\"si577\\"],3266,\\"si577\\",10);"],["cp.jumpToNextSlide(3981);"]]}]}',
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[577]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si577c:{
b:[1221,67,1541,167],
fh:false,
fw:false,
uid:577,
iso:false,
css:{
360:{
l:'125.617%',
t:'11.020%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.617%',
lhID:-1,
lvEID:0,
lvV:'11.020%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'125.617%',
t:'11.020%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.617%',
lhID:-1,
lvEID:0,
lvV:'11.020%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'125.617%',
t:'11.020%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.617%',
lhID:-1,
lvEID:0,
lvV:'11.020%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si577',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,1543,169],
vb:[-2,-2,1543,169]
},
si588:{
name:'Mouse_1',
type:12,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si588c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":0,"mouseStartPointY":0,"mouseEndPointX":1233.2946095415778,"mouseEndPointY":41.411313965884865}}',
parentGroup:'si478',
retainState:false,
immo:false,
apsn:'Slide460',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si588Ad',
trin:0,
trout:0,
isDD:false
},
si588c:{
b:[1218,39,1250,71],
fh:false,
fw:false,
uid:588,
iso:false,
css:{
360:{
l:'125.309%',
t:'6.414%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.309%',
lhID:-1,
lvEID:0,
lvV:'6.414%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'125.309%',
t:'6.414%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.309%',
lhID:-1,
lvEID:0,
lvV:'6.414%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'125.309%',
t:'6.414%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.309%',
lhID:-1,
lvEID:0,
lvV:'6.414%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si588',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[0,0,1250,71],
vb:[0,0,1250,71]
},
si588Ad:{
src:'ar/Mouse.mp3',
from:1,
to:6,
del:2.818,
msa:1,
du:0.182
},
Slide460:{
lb:'Simulation slide 1',
id:460,
from:2056,
to:2145,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide460c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si486',
t:1268
}
]
,
iph:[]
,
oa:'si588Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
3266:{
ts:''
}
,
3981:{
ts:''
}

}

},
Slide460c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:460,
dn:'Slide460',
visible:'1'
},
si630:{
name:'Simulation_2',
type:1268,
from:91,
to:120,
rp:0,
rpa:0,
mdi:'si630c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide604',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si622',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si630c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:630,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si630',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si622:{
name:'Simulation_non_responsive_2',
type:1268,
from:91,
to:120,
rp:0,
rpa:0,
mdi:'si622c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si630',
retainState:false,
immo:false,
apsn:'Slide604',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si641',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si630',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si622c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:622,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si622',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:638,
tsp:50,
ip:'dr/0638.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si641:{
name:'Mouse_2',
type:12,
from:91,
to:120,
rp:0,
rpa:0,
mdi:'si641c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":1233.2946095415778,"mouseStartPointY":41.411313965884865,"mouseEndPointX":1232,"mouseEndPointY":47}}',
parentGroup:'si622',
retainState:false,
immo:false,
apsn:'Slide604',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si641Ad',
trin:0,
trout:0,
isDD:false
},
si641c:{
b:[1219,39,1251,71],
fh:false,
fw:false,
uid:641,
iso:false,
css:{
360:{
l:'125.412%',
t:'6.414%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.412%',
lhID:-1,
lvEID:0,
lvV:'6.414%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'125.412%',
t:'6.414%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.412%',
lhID:-1,
lvEID:0,
lvV:'6.414%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'125.412%',
t:'6.414%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'125.412%',
lhID:-1,
lvEID:0,
lvV:'6.414%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si641',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[1219,39,1251,71],
vb:[1219,39,1251,71]
},
si641Ad:{
src:'ar/Mouse.mp3',
from:91,
to:96,
del:0.818,
msa:1,
du:0.182
},
Slide604:{
lb:'Simulation slide 2',
id:604,
from:2146,
to:2175,
iols:0,
i360qs:false,
sdu:1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide604c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si630',
t:1268
}
]
,
iph:[]
,
oa:'si641Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide604c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:604,
dn:'Slide604',
visible:'1'
},
si3384:{
name:'Image_12',
type:1268,
from:2176,
to:2466,
rp:0,
rpa:0,
mdi:'si3384c',
tag:'container-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":751,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_SCALE","padding":{"top":5,"bottom":5,"right":0,"left":4},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":0.84765625}',
retainState:false,
immo:false,
apsn:'Slide3409',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3378',
t:1268
}
]
,
containerType:'image',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":751,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_SCALE","padding":{"top":5,"bottom":5,"right":0,"left":4},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":0.84765625}',
option:'INTRODUCTION_SINGLE_IMAGE_OPTION_1',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si3384c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3384,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3384',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3378:{
name:'Image_Group_12',
type:1268,
from:2176,
to:2466,
rp:0,
rpa:0,
mdi:'si3378c',
tag:'container-image-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-buttons":true,"card":false},"groupedItemsVisibility":{"slide-item-buttons":2},"padding":{"top":0,"bottom":0,"left":0,"right":0},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridGap":"10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"2 / 1 / span 1 / span 1","marginLeft":"20px","marginBottom":"20px","alignItems":"flex-start"},"tablet":{},"mobile":{}}}}',
parentGroup:'si3384',
retainState:false,
immo:false,
apsn:'Slide3409',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3286',
t:15
}
,{
n:'si3315',
t:1268
}
,{
n:'si3337',
t:29
}
,{
n:'si3356',
t:29
}
,{
n:'si3372',
t:29
}
]
,
containerType:'image-single-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-buttons":true,"card":false},"groupedItemsVisibility":{"slide-item-buttons":2},"padding":{"top":0,"bottom":0,"left":0,"right":0},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridGap":"10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"2 / 1 / span 1 / span 1","marginLeft":"20px","marginBottom":"20px","alignItems":"flex-start"},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3384',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si3378c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3378,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3378',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3286:{
name:'slide29_1',
type:15,
from:2191,
to:2466,
rp:0,
rpa:0,
mdi:'si3286c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0.5,
sid:9.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"imageContainerStyles":{"minWidth":"100%","maxWidth":"100%","gridArea":"1 / 2 / span 2 / span 1"}},"tablet":{},"mobile":{}}}',
parentGroup:'si3378',
retainState:false,
immo:false,
apsn:'Slide3409',
efph:{
3276:{
efdu:0.6,
efde:0,
efa:3,
efre:1,
efdi:3,
efe:207,
efty:0,
eftd:0,
efdaa:false,
efva:[]
}

}
,
eflh:[3276],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:-1,
irw:1908,
irh:1273,
w:1908,
h:1273,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3286]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3286c:{
b:[0,0,1908,1273],
fh:false,
fw:false,
uid:3286,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'131.579%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'131.579%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'131.579%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03274.jpeg',
dn:'si3286',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1909,1274],
vb:[-1,-1,1909,1274]
},
si3315:{
name:'Image_Group_Text_30',
type:1268,
from:2206,
to:2466,
rp:0,
rpa:0,
mdi:'si3315c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1,
sid:8.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"10px","paddingRight":"10px","paddingTop":"10px","paddingBottom":"0px","justifyContent":"flex-end"},"tablet":{"marginLeft":"0px","paddingBottom":"20px"},"mobile":{"marginLeft":"0px","paddingBottom":"20px"}}}',
parentGroup:'si3378',
retainState:false,
immo:false,
apsn:'Slide3409',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3298',
t:1250
}
,{
n:'si3309',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"10px","paddingRight":"10px","paddingTop":"10px","paddingBottom":"0px","justifyContent":"flex-end"},"tablet":{"marginLeft":"0px","paddingBottom":"20px"},"mobile":{"marginLeft":"0px","paddingBottom":"20px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3378',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3315c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3315,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3315',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3298:{
name:'Text_268',
type:1250,
from:2206,
to:2466,
rp:0,
rpa:0,
mdi:'si3298c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1,
sid:8.7,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3315',
retainState:false,
immo:false,
apsn:'Slide3409',
efph:{
3290:{
efdu:0.6,
efde:0,
efa:3,
efre:1,
efdi:0,
efe:207,
efty:0,
eftd:0,
efdaa:false,
efva:[]
}

}
,
eflh:[3290],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6l2vc","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-2","listSize":"100%"}},{"key":"l7mf","text":"Benefits of a Healthy Diet","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":26,"style":"textShadowBlur:8px"},{"offset":0,"length":26,"style":"desktop-fontSize:24"},{"offset":0,"length":26,"style":"mobile-fontSize:20"},{"offset":0,"length":26,"style":"overridden:false"},{"offset":0,"length":26,"style":"backgroundColor:unset"},{"offset":0,"length":26,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":26,"style":"hlnkt:wp"},{"offset":0,"length":26,"style":"fontStyle:normal"},{"offset":0,"length":26,"style":"textOutlineEnable:false"},{"offset":0,"length":26,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":26,"style":"opacity:1"},{"offset":0,"length":26,"style":"tablet-fontSize:22"},{"offset":0,"length":26,"style":"fontFamily:DM Sans"},{"offset":0,"length":26,"style":"hlnke:true"},{"offset":0,"length":26,"style":"defaultTextShadow:none"},{"offset":0,"length":26,"style":"fontWeight:700"},{"offset":0,"length":26,"style":"textShadow:none"},{"offset":0,"length":26,"style":"textShadowX:0px"},{"offset":0,"length":26,"style":"fontStretch:normal"},{"offset":0,"length":26,"style":"color:#000000"},{"offset":0,"length":26,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":26,"style":"textShadowY:4px"},{"offset":0,"length":26,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":26,"style":"lineHeight:135%"},{"offset":0,"length":26,"style":"letterSpacing:0%"},{"offset":0,"length":26,"style":"textHighlightEnable:false"},{"offset":0,"length":26,"style":"textTransform:none"},{"offset":0,"length":26,"style":"WebkitTextStrokeColor:#96d5cc"},{"offset":0,"length":26,"style":"defaultTextStrokeColor:#96d5cc"},{"offset":0,"length":26,"style":"textShadowOpacity:none"},{"offset":0,"length":26,"style":"textDecoration:none"},{"offset":0,"length":26,"style":"borderBottomStyle:none"},{"offset":0,"length":26,"style":"fontType:normal"},{"offset":0,"length":26,"style":"textShadowEnable:false"},{"offset":0,"length":26,"style":"hlnk:"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-2","listSize":"100%"}},{"key":"2u9s2","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3298]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3298c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:3298,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3298',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si3309:{
name:'Text_269',
type:1250,
from:2218,
to:2466,
rp:0,
rpa:0,
mdi:'si3309c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[6800,6800],
siaf:1.4,
sid:8.3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3315',
retainState:false,
immo:false,
apsn:'Slide3409',
efph:{
3301:{
efdu:0.6,
efde:0,
efa:3,
efre:1,
efdi:0,
efe:207,
efty:0,
eftd:0,
efdaa:false,
efva:[]
}

}
,
eflh:[3301],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5gskb","text":"Embracing a healthy eating lifestyle is a powerful investment in our health and can lead to a higher quality of life. Let us look at some benefits of healthy eating.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":165,"style":"textShadowX:0px"},{"offset":0,"length":165,"style":"fontStretch:normal"},{"offset":0,"length":165,"style":"fontType:regular"},{"offset":0,"length":165,"style":"color:#000000"},{"offset":0,"length":165,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":165,"style":"textShadowY:4px"},{"offset":0,"length":165,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":165,"style":"letterSpacing:0%"},{"offset":0,"length":165,"style":"textHighlightEnable:false"},{"offset":0,"length":165,"style":"textTransform:none"},{"offset":0,"length":165,"style":"WebkitTextStrokeColor:#96d5cc"},{"offset":0,"length":165,"style":"defaultTextStrokeColor:#96d5cc"},{"offset":0,"length":165,"style":"textShadowOpacity:none"},{"offset":0,"length":165,"style":"textDecoration:none"},{"offset":0,"length":165,"style":"lineHeight:130%"},{"offset":0,"length":165,"style":"borderBottomStyle:none"},{"offset":0,"length":165,"style":"desktop-fontSize:22"},{"offset":0,"length":165,"style":"textShadowEnable:false"},{"offset":0,"length":165,"style":"hlnk:"},{"offset":0,"length":165,"style":"textShadowBlur:8px"},{"offset":0,"length":165,"style":"overridden:false"},{"offset":0,"length":165,"style":"backgroundColor:unset"},{"offset":0,"length":165,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":165,"style":"hlnkt:wp"},{"offset":0,"length":165,"style":"fontStyle:normal"},{"offset":0,"length":165,"style":"tablet-fontSize:20"},{"offset":0,"length":165,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":165,"style":"fontWeight:400"},{"offset":0,"length":165,"style":"textOutlineEnable:false"},{"offset":0,"length":165,"style":"opacity:1"},{"offset":0,"length":165,"style":"fontFamily:DM Sans"},{"offset":0,"length":165,"style":"hlnke:true"},{"offset":0,"length":165,"style":"defaultTextShadow:none"},{"offset":0,"length":165,"style":"textShadow:none"},{"offset":0,"length":165,"style":"mobile-fontSize:18"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"1hvrv","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"ugq7","text":"Weight Management: Body Mass Index (BMI) within a healthy weight range of 18.5-23.0","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":83,"style":"defaultTextShadow:none"},{"offset":0,"length":83,"style":"textShadow:none"},{"offset":0,"length":83,"style":"mobile-fontSize:18"},{"offset":0,"length":83,"style":"textShadowX:0px"},{"offset":0,"length":83,"style":"fontStretch:normal"},{"offset":0,"length":83,"style":"fontType:regular"},{"offset":0,"length":83,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":83,"style":"textShadowY:4px"},{"offset":0,"length":83,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":83,"style":"lineHeight:135%"},{"offset":0,"length":83,"style":"letterSpacing:0%"},{"offset":0,"length":83,"style":"textHighlightEnable:false"},{"offset":0,"length":83,"style":"textTransform:none"},{"offset":0,"length":83,"style":"WebkitTextStrokeColor:#96d5cc"},{"offset":0,"length":83,"style":"defaultTextStrokeColor:#96d5cc"},{"offset":0,"length":83,"style":"textShadowOpacity:none"},{"offset":0,"length":83,"style":"textDecoration:none"},{"offset":0,"length":83,"style":"borderBottomStyle:none"},{"offset":0,"length":83,"style":"color:#3a3b3b"},{"offset":0,"length":83,"style":"desktop-fontSize:22"},{"offset":0,"length":83,"style":"textShadowEnable:false"},{"offset":0,"length":83,"style":"hlnk:"},{"offset":0,"length":83,"style":"textShadowBlur:8px"},{"offset":0,"length":83,"style":"overridden:false"},{"offset":0,"length":83,"style":"backgroundColor:unset"},{"offset":0,"length":83,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":83,"style":"hlnkt:wp"},{"offset":0,"length":83,"style":"fontStyle:normal"},{"offset":0,"length":83,"style":"tablet-fontSize:20"},{"offset":0,"length":83,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":83,"style":"fontWeight:400"},{"offset":0,"length":83,"style":"textOutlineEnable:false"},{"offset":0,"length":83,"style":"opacity:1"},{"offset":0,"length":83,"style":"fontFamily:DM Sans"},{"offset":0,"length":83,"style":"hlnke:true"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#3a3b3bFF","verticalAlignMarginBottom":"80px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"80%","presetId":"text-body-3","listSize":"70%"}},{"key":"fbbuf","text":"Disease Prevention: Better immunity","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":35,"style":"opacity:1"},{"offset":0,"length":35,"style":"fontFamily:DM Sans"},{"offset":0,"length":35,"style":"hlnke:true"},{"offset":0,"length":35,"style":"defaultTextShadow:none"},{"offset":0,"length":35,"style":"textShadow:none"},{"offset":0,"length":35,"style":"mobile-fontSize:18"},{"offset":0,"length":35,"style":"textShadowX:0px"},{"offset":0,"length":35,"style":"fontStretch:normal"},{"offset":0,"length":35,"style":"fontType:regular"},{"offset":0,"length":35,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":35,"style":"textShadowY:4px"},{"offset":0,"length":35,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":35,"style":"lineHeight:135%"},{"offset":0,"length":35,"style":"letterSpacing:0%"},{"offset":0,"length":35,"style":"textHighlightEnable:false"},{"offset":0,"length":35,"style":"textTransform:none"},{"offset":0,"length":35,"style":"WebkitTextStrokeColor:#96d5cc"},{"offset":0,"length":35,"style":"defaultTextStrokeColor:#96d5cc"},{"offset":0,"length":35,"style":"textShadowOpacity:none"},{"offset":0,"length":35,"style":"textDecoration:none"},{"offset":0,"length":35,"style":"borderBottomStyle:none"},{"offset":0,"length":35,"style":"color:#3a3b3b"},{"offset":0,"length":35,"style":"desktop-fontSize:22"},{"offset":0,"length":35,"style":"textShadowEnable:false"},{"offset":0,"length":35,"style":"hlnk:"},{"offset":0,"length":35,"style":"textShadowBlur:8px"},{"offset":0,"length":35,"style":"overridden:false"},{"offset":0,"length":35,"style":"backgroundColor:unset"},{"offset":0,"length":35,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":35,"style":"hlnkt:wp"},{"offset":0,"length":35,"style":"fontStyle:normal"},{"offset":0,"length":35,"style":"tablet-fontSize:20"},{"offset":0,"length":35,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":35,"style":"fontWeight:400"},{"offset":0,"length":35,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#3a3b3bFF","verticalAlignMarginBottom":"80px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"80%","presetId":"text-body-3","listSize":"70%"}},{"key":"mv8i","text":"Increased Energy and Productivity","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":33,"style":"tablet-fontSize:20"},{"offset":0,"length":33,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":33,"style":"fontWeight:400"},{"offset":0,"length":33,"style":"textOutlineEnable:false"},{"offset":0,"length":33,"style":"opacity:1"},{"offset":0,"length":33,"style":"fontFamily:DM Sans"},{"offset":0,"length":33,"style":"hlnke:true"},{"offset":0,"length":33,"style":"defaultTextShadow:none"},{"offset":0,"length":33,"style":"textShadow:none"},{"offset":0,"length":33,"style":"mobile-fontSize:18"},{"offset":0,"length":33,"style":"textShadowX:0px"},{"offset":0,"length":33,"style":"fontStretch:normal"},{"offset":0,"length":33,"style":"fontType:regular"},{"offset":0,"length":33,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":33,"style":"textShadowY:4px"},{"offset":0,"length":33,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":33,"style":"lineHeight:135%"},{"offset":0,"length":33,"style":"letterSpacing:0%"},{"offset":0,"length":33,"style":"textHighlightEnable:false"},{"offset":0,"length":33,"style":"textTransform:none"},{"offset":0,"length":33,"style":"WebkitTextStrokeColor:#96d5cc"},{"offset":0,"length":33,"style":"defaultTextStrokeColor:#96d5cc"},{"offset":0,"length":33,"style":"textShadowOpacity:none"},{"offset":0,"length":33,"style":"textDecoration:none"},{"offset":0,"length":33,"style":"borderBottomStyle:none"},{"offset":0,"length":33,"style":"color:#3a3b3b"},{"offset":0,"length":33,"style":"desktop-fontSize:22"},{"offset":0,"length":33,"style":"textShadowEnable:false"},{"offset":0,"length":33,"style":"hlnk:"},{"offset":0,"length":33,"style":"textShadowBlur:8px"},{"offset":0,"length":33,"style":"overridden:false"},{"offset":0,"length":33,"style":"backgroundColor:unset"},{"offset":0,"length":33,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":33,"style":"hlnkt:wp"},{"offset":0,"length":33,"style":"fontStyle:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#3a3b3bFF","verticalAlignMarginBottom":"80px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"80%","presetId":"text-body-3","listSize":"70%"}},{"key":"2mdo4","text":"Better Mental Health: Healthy, happy individuals","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":48,"style":"overridden:false"},{"offset":0,"length":48,"style":"backgroundColor:unset"},{"offset":0,"length":48,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":48,"style":"hlnkt:wp"},{"offset":0,"length":48,"style":"fontStyle:normal"},{"offset":0,"length":48,"style":"tablet-fontSize:20"},{"offset":0,"length":48,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":48,"style":"fontWeight:400"},{"offset":0,"length":48,"style":"textOutlineEnable:false"},{"offset":0,"length":48,"style":"opacity:1"},{"offset":0,"length":48,"style":"fontFamily:DM Sans"},{"offset":0,"length":48,"style":"hlnke:true"},{"offset":0,"length":48,"style":"defaultTextShadow:none"},{"offset":0,"length":48,"style":"textShadow:none"},{"offset":0,"length":48,"style":"mobile-fontSize:18"},{"offset":0,"length":48,"style":"textShadowX:0px"},{"offset":0,"length":48,"style":"fontStretch:normal"},{"offset":0,"length":48,"style":"fontType:regular"},{"offset":0,"length":48,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":48,"style":"textShadowY:4px"},{"offset":0,"length":48,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":48,"style":"lineHeight:135%"},{"offset":0,"length":48,"style":"letterSpacing:0%"},{"offset":0,"length":48,"style":"textHighlightEnable:false"},{"offset":0,"length":48,"style":"textTransform:none"},{"offset":0,"length":48,"style":"WebkitTextStrokeColor:#96d5cc"},{"offset":0,"length":48,"style":"defaultTextStrokeColor:#96d5cc"},{"offset":0,"length":48,"style":"textShadowOpacity:none"},{"offset":0,"length":48,"style":"textDecoration:none"},{"offset":0,"length":48,"style":"borderBottomStyle:none"},{"offset":0,"length":48,"style":"color:#3a3b3b"},{"offset":0,"length":48,"style":"desktop-fontSize:22"},{"offset":0,"length":48,"style":"textShadowEnable:false"},{"offset":0,"length":48,"style":"hlnk:"},{"offset":0,"length":48,"style":"textShadowBlur:8px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#3a3b3bFF","verticalAlignMarginBottom":"80px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"80%","presetId":"text-body-3","listSize":"70%"}},{"key":"d7lva","text":"Improved Sleep: Helps rest and repair of body and mind","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":54,"style":"textShadowEnable:false"},{"offset":0,"length":54,"style":"hlnk:"},{"offset":0,"length":54,"style":"textShadowBlur:8px"},{"offset":0,"length":54,"style":"overridden:false"},{"offset":0,"length":54,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":54,"style":"backgroundColor:unset"},{"offset":0,"length":54,"style":"fontStyle:normal"},{"offset":0,"length":54,"style":"hlnkt:wp"},{"offset":0,"length":54,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":54,"style":"tablet-fontSize:20"},{"offset":0,"length":54,"style":"fontWeight:400"},{"offset":0,"length":54,"style":"textOutlineEnable:false"},{"offset":0,"length":54,"style":"opacity:1"},{"offset":0,"length":54,"style":"fontFamily:DM Sans"},{"offset":0,"length":54,"style":"hlnke:true"},{"offset":0,"length":54,"style":"defaultTextShadow:none"},{"offset":0,"length":54,"style":"textShadow:none"},{"offset":0,"length":54,"style":"mobile-fontSize:18"},{"offset":0,"length":54,"style":"textShadowX:0px"},{"offset":0,"length":54,"style":"fontStretch:normal"},{"offset":0,"length":54,"style":"fontType:regular"},{"offset":0,"length":54,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":54,"style":"textShadowY:4px"},{"offset":0,"length":54,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":54,"style":"lineHeight:135%"},{"offset":0,"length":54,"style":"letterSpacing:0%"},{"offset":0,"length":54,"style":"textHighlightEnable:false"},{"offset":0,"length":54,"style":"textTransform:none"},{"offset":0,"length":54,"style":"WebkitTextStrokeColor:#96d5cc"},{"offset":0,"length":54,"style":"defaultTextStrokeColor:#96d5cc"},{"offset":0,"length":54,"style":"textShadowOpacity:none"},{"offset":0,"length":54,"style":"textDecoration:none"},{"offset":0,"length":54,"style":"borderBottomStyle:none"},{"offset":0,"length":54,"style":"color:#3a3b3b"},{"offset":0,"length":54,"style":"desktop-fontSize:22"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#3a3b3bFF","verticalAlignMarginBottom":"80px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"80%","presetId":"text-body-3","listSize":"70%"}},{"key":"7808d","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#3a3b3bFF","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"70%"}},{"key":"41kt0","text":"Select ‘Back\' to return to ‘Table of Content’ or ‘Next’ to proceed to Section 3: Physical Activity and Fitness.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":111,"style":"textDecoration:none"},{"offset":0,"length":111,"style":"lineHeight:130%"},{"offset":0,"length":111,"style":"borderBottomStyle:none"},{"offset":0,"length":111,"style":"desktop-fontSize:22"},{"offset":0,"length":111,"style":"textShadowEnable:false"},{"offset":0,"length":111,"style":"hlnk:"},{"offset":0,"length":111,"style":"textShadowBlur:8px"},{"offset":0,"length":111,"style":"defaultTextShadow:none"},{"offset":0,"length":111,"style":"overridden:false"},{"offset":0,"length":111,"style":"hlnkt:wp"},{"offset":0,"length":111,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":111,"style":"tablet-fontSize:20"},{"offset":0,"length":111,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":111,"style":"fontType:italic"},{"offset":0,"length":111,"style":"textOutlineEnable:false"},{"offset":0,"length":111,"style":"opacity:1"},{"offset":0,"length":111,"style":"fontFamily:DM Sans"},{"offset":0,"length":111,"style":"fontWeight:600"},{"offset":0,"length":111,"style":"hlnke:true"},{"offset":0,"length":111,"style":"backgroundColor:unset"},{"offset":0,"length":111,"style":"textShadow:none"},{"offset":0,"length":111,"style":"mobile-fontSize:18"},{"offset":0,"length":111,"style":"fontStyle:italic"},{"offset":0,"length":111,"style":"textShadowX:0px"},{"offset":0,"length":111,"style":"fontStretch:normal"},{"offset":0,"length":111,"style":"color:#000000"},{"offset":0,"length":111,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":111,"style":"textShadowY:4px"},{"offset":0,"length":111,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":111,"style":"letterSpacing:0%"},{"offset":0,"length":111,"style":"textHighlightEnable:false"},{"offset":0,"length":111,"style":"textTransform:none"},{"offset":0,"length":111,"style":"WebkitTextStrokeColor:#96d5cc"},{"offset":0,"length":111,"style":"defaultTextStrokeColor:#96d5cc"},{"offset":0,"length":111,"style":"textShadowOpacity:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#3a3b3bFF","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-2","listSize":"70%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3309]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3309c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:3309,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3309',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si3337:{
name:'Button_216',
type:29,
from:2233,
to:2466,
rp:0,
rpa:0,
mdi:'si3337c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.9,
sid:7.8,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":false,"hover":false,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ef86n","text":"   Back   ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"desktop-fontSize:22"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"tablet-fontSize:20"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"fontFamily:DM Sans"},{"offset":0,"length":10,"style":"fontType:400"},{"offset":0,"length":10,"style":"textShadowColor:ffffff00"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textTransform:capitalize"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"textShadowY:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":10,"style":"color:#FFFFFF"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":10,"style":"letterSpacing:2%"},{"offset":0,"length":10,"style":"lineHeight:125%"},{"offset":0,"length":10,"style":"textShadowBlur:0px"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"true","presetId":"text-button-normal","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"76ib3","text":"   Back   ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"color:#FFFFFF"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":10,"style":"letterSpacing:2%"},{"offset":0,"length":10,"style":"lineHeight:125%"},{"offset":0,"length":10,"style":"textShadowBlur:0px"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"desktop-fontSize:22"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"tablet-fontSize:20"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"fontFamily:DM Sans"},{"offset":0,"length":10,"style":"fontType:400"},{"offset":0,"length":10,"style":"textShadowColor:ffffff00"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textTransform:capitalize"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"textShadowY:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"true","presetId":"text-button-visited","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"03318.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4vf1d","text":"   Back   ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":10,"style":"letterSpacing:2%"},{"offset":0,"length":10,"style":"lineHeight:125%"},{"offset":0,"length":10,"style":"textShadowBlur:0px"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"desktop-fontSize:22"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"tablet-fontSize:20"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"fontFamily:DM Sans"},{"offset":0,"length":10,"style":"fontType:400"},{"offset":0,"length":10,"style":"textShadowColor:ffffff00"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textTransform:capitalize"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"textShadowY:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":10,"style":"color:#FFFFFF"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"true","presetId":"text-button-selected","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"879rh","text":"   Back   ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":10,"style":"color:#FFFFFF"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":10,"style":"letterSpacing:2%"},{"offset":0,"length":10,"style":"lineHeight:125%"},{"offset":0,"length":10,"style":"textShadowBlur:0px"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"desktop-fontSize:22"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"tablet-fontSize:20"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"fontFamily:DM Sans"},{"offset":0,"length":10,"style":"fontType:400"},{"offset":0,"length":10,"style":"textShadowColor:ffffff00"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textTransform:capitalize"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"true","presetId":"text-button-hover","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6p03p","text":"   Back   ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"textShadowBlur:0px"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"desktop-fontSize:22"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"color:#f7f2e7"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"tablet-fontSize:20"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"fontFamily:DM Sans"},{"offset":0,"length":10,"style":"fontType:400"},{"offset":0,"length":10,"style":"textShadowColor:ffffff00"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textTransform:capitalize"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"textShadowY:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":10,"style":"letterSpacing:2%"},{"offset":0,"length":10,"style":"lineHeight:125%"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"true","presetId":"text-button-disabled","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si3378',
retainState:false,
immo:false,
apsn:'Slide3409',
efph:{
3329:{
efdu:0.6,
efde:0,
efa:3,
efre:1,
efdi:0,
efe:207,
efty:0,
eftd:0,
efdaa:false,
efva:[]
}

}
,
eflh:[3329],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3337]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3337c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3337,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3337',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3356:{
name:'Button_217',
type:29,
from:2233,
to:2466,
rp:0,
rpa:0,
mdi:'si3356c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.9,
sid:7.8,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":false,"hover":false,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"aa09u","text":"   Next   ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"tablet-fontSize:20"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"fontFamily:DM Sans"},{"offset":0,"length":10,"style":"fontType:400"},{"offset":0,"length":10,"style":"textShadowColor:ffffff00"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textTransform:capitalize"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"textShadowY:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":10,"style":"color:#FFFFFF"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":10,"style":"letterSpacing:2%"},{"offset":0,"length":10,"style":"lineHeight:125%"},{"offset":0,"length":10,"style":"textShadowBlur:0px"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"desktop-fontSize:22"},{"offset":0,"length":10,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"textAlign":"center","listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"true","presetId":"text-button-normal"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d7g6i","text":"   Next   ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"textShadowY:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":10,"style":"color:#FFFFFF"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":10,"style":"letterSpacing:2%"},{"offset":0,"length":10,"style":"lineHeight:125%"},{"offset":0,"length":10,"style":"textShadowBlur:0px"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"desktop-fontSize:22"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"tablet-fontSize:20"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"fontFamily:DM Sans"},{"offset":0,"length":10,"style":"fontType:400"},{"offset":0,"length":10,"style":"textShadowColor:ffffff00"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textTransform:capitalize"}],"entityRanges":[],"data":{"textAlign":"center","listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"true","presetId":"text-button-visited"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"03318.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4tq8f","text":"   Next   ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":10,"style":"color:#FFFFFF"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":10,"style":"letterSpacing:2%"},{"offset":0,"length":10,"style":"lineHeight:125%"},{"offset":0,"length":10,"style":"textShadowBlur:0px"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"desktop-fontSize:22"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"tablet-fontSize:20"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"fontFamily:DM Sans"},{"offset":0,"length":10,"style":"fontType:400"},{"offset":0,"length":10,"style":"textShadowColor:ffffff00"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textTransform:capitalize"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"textAlign":"center","listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"true","presetId":"text-button-selected"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"f1kf7","text":"   Next   ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textTransform:capitalize"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"textShadowY:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":10,"style":"color:#FFFFFF"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":10,"style":"letterSpacing:2%"},{"offset":0,"length":10,"style":"lineHeight:125%"},{"offset":0,"length":10,"style":"textShadowBlur:0px"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"desktop-fontSize:22"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"tablet-fontSize:20"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"fontFamily:DM Sans"},{"offset":0,"length":10,"style":"fontType:400"},{"offset":0,"length":10,"style":"textShadowColor:ffffff00"},{"offset":0,"length":10,"style":"hlnke:true"}],"entityRanges":[],"data":{"textAlign":"center","listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"true","presetId":"text-button-hover"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"615gn","text":"   Next   ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":10,"style":"letterSpacing:2%"},{"offset":0,"length":10,"style":"lineHeight:125%"},{"offset":0,"length":10,"style":"textShadowBlur:0px"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"desktop-fontSize:22"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"color:#f7f2e7"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"tablet-fontSize:20"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"fontFamily:DM Sans"},{"offset":0,"length":10,"style":"fontType:400"},{"offset":0,"length":10,"style":"textShadowColor:ffffff00"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textTransform:capitalize"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"textShadowY:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"textAlign":"center","listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"true","presetId":"text-button-disabled"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si3378',
retainState:false,
immo:false,
apsn:'Slide3409',
efph:{
3348:{
efdu:0.6,
efde:0,
efa:3,
efre:1,
efdi:0,
efe:207,
efty:0,
eftd:0,
efdaa:false,
efva:[]
}

}
,
eflh:[3348],
oca:'{"scripts":[{"then":[["cp.jumpToNextSlide(3338);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3356]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3356c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3356,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3356',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3372:{
name:'Button_218',
type:29,
from:2176,
to:2466,
rp:0,
rpa:0,
mdi:'si3372c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:9.7,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cil2t","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"477p1","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"03318.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"11rkg","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6ce9l","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"c0bou","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si3378',
retainState:false,
immo:false,
apsn:'Slide3409',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3372]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3372c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3372,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3372',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide3409:{
lb:'Benefits of a Healthy Diet',
id:3409,
from:2176,
to:2466,
iols:0,
i360qs:false,
sdu:9.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide3409c',
st:'Normal Slide',
sk:'Introduction',
slideTag:'introduction-slide',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si3384',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#e3fbeb',
fa:1,
fe:true,
imgf:{
ip:'dr/03404.png',
tiletype:0,
imageFocus:-1,
extraImageProps:'',
id:3404,
w:1366,
h:768,
tsp:100
}
,
iso:true,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
3338:{
ts:''
}
,
3319:{
ts:''
}

}

},
Slide3409c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:3409,
dn:'Slide3409',
visible:'1'
},
si674:{
name:'Simulation_3',
type:1268,
from:2467,
to:2556,
rp:0,
rpa:0,
mdi:'si674c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide648',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si666',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si674c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:674,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si674',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si666:{
name:'Simulation_non_responsive_3',
type:1268,
from:2467,
to:2556,
rp:0,
rpa:0,
mdi:'si666c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si674',
retainState:false,
immo:false,
apsn:'Slide648',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si685',
t:1269
}
,{
n:'si705',
t:612
}
,{
n:'si765',
t:612
}
,{
n:'si775',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si674',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si666c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:666,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si666',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:682,
tsp:50,
ip:'dr/0682.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si685:{
name:'Highlight_box_2',
type:1269,
from:121,
to:210,
rp:0,
rpa:0,
mdi:'si685c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":121,"left":1154,"width":34,"height":20}}',
parentGroup:'si666',
retainState:false,
immo:false,
apsn:'Slide648',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si695',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[685]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si685c:{
b:[1154,121,1188,141],
fh:false,
fw:false,
uid:685,
iso:false,
css:{
360:{
l:'118.724%',
t:'19.901%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'118.724%',
lhID:-1,
lvEID:0,
lvV:'19.901%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'118.724%',
t:'19.901%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'118.724%',
lhID:-1,
lvEID:0,
lvV:'19.901%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'118.724%',
t:'19.901%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'118.724%',
lhID:-1,
lvEID:0,
lvV:'19.901%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si685',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[1154,121,1188,141],
vb:[1154,121,1188,141]
},
si695:{
name:'Shape_2',
type:612,
from:121,
to:210,
rp:0,
rpa:0,
mdi:'si695c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide648',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[695]
}
]
,
stis:0,
bstiid:685,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si685',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si695c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:695,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si695',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si705:{
name:'Rectangle_2',
type:612,
from:121,
to:210,
rp:0,
rpa:0,
mdi:'si705c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":181,"left":839,"width":300,"height":"auto"}}',
parentGroup:'si666',
retainState:false,
immo:false,
apsn:'Slide648',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:716,
stt:0,
dsr:'Default_State',
stsi:[705]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si705','si718','si729','si740'],
isDD:false
},
si705c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:705,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si705',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si718:{
name:'',
type:612,
from:121,
to:210,
rp:0,
rpa:0,
mdi:'si718c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":181,"left":839,"width":300,"height":"auto"}}',
parentGroup:'si666',
retainState:false,
immo:false,
apsn:'Slide648',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si705',
stl:[{
stn:'Normal',
stt:0,
stsi:[718]
}
]
,
stis:0,
bstiid:705,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:705,
isDD:false
},
si718c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:718,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si718',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si729:{
name:'',
type:612,
from:121,
to:210,
rp:0,
rpa:0,
mdi:'si729c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":181,"left":839,"width":300,"height":"auto"}}',
parentGroup:'si666',
retainState:false,
immo:false,
apsn:'Slide648',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si705',
stl:[{
stn:'Normal',
stt:0,
stsi:[729]
}
]
,
stis:0,
bstiid:705,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:705,
isDD:false
},
si729c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:729,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si729',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si740:{
name:'',
type:612,
from:121,
to:210,
rp:0,
rpa:0,
mdi:'si740c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":181,"left":839,"width":300,"height":"auto"}}',
parentGroup:'si666',
retainState:false,
immo:false,
apsn:'Slide648',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si705',
stl:[{
stn:'Normal',
stt:0,
stsi:[740]
}
]
,
stis:0,
bstiid:705,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:705,
isDD:false
},
si740c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:740,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si740',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si765:{
name:'Instructions_2',
type:612,
from:2467,
to:2556,
rp:0,
rpa:0,
mdi:'si765c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":151,"left":1060,"width":320}}',
parentGroup:'si666',
retainState:false,
immo:false,
apsn:'Slide648',
efph:{
773:{
efdu:0.6,
efde:0,
efa:7,
efre:1,
efdi:8,
efe:214,
efty:0,
eftd:1,
efdaa:false,
efva:[]
}

}
,
eflh:[773],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[765]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si765c:{
b:[1161,151,1481,251],
fh:false,
fw:false,
uid:765,
iso:false,
css:{
360:{
l:'119.444%',
t:'24.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'119.444%',
lhID:-1,
lvEID:0,
lvV:'24.836%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'119.444%',
t:'24.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'119.444%',
lhID:-1,
lvEID:0,
lvV:'24.836%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'119.444%',
t:'24.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'119.444%',
lhID:-1,
lvEID:0,
lvV:'24.836%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si765',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,1483,253],
vb:[-2,-2,1483,253]
},
si775:{
name:'Mouse_3',
type:12,
from:2509,
to:2556,
rp:0,
rpa:0,
mdi:'si775c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":1232,"mouseStartPointY":47,"mouseEndPointX":1171,"mouseEndPointY":131}}',
parentGroup:'si666',
retainState:false,
immo:false,
apsn:'Slide648',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si775Ad',
trin:0,
trout:0,
isDD:false
},
si775c:{
b:[1158,123,1190,155],
fh:false,
fw:false,
uid:775,
iso:false,
css:{
360:{
l:'119.136%',
t:'20.230%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'119.136%',
lhID:-1,
lvEID:0,
lvV:'20.230%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'119.136%',
t:'20.230%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'119.136%',
lhID:-1,
lvEID:0,
lvV:'20.230%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'119.136%',
t:'20.230%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'119.136%',
lhID:-1,
lvEID:0,
lvV:'20.230%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si775',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[1158,51,1231,155],
vb:[1158,51,1231,155]
},
si775Ad:{
src:'ar/Mouse.mp3',
from:2509,
to:2514,
del:2.818,
msa:1,
du:0.182
},
Slide648:{
lb:'Simulation slide 3',
id:648,
from:2467,
to:2556,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide648c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si674',
t:1268
}
]
,
iph:[]
,
oa:'si775Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide648c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:648,
dn:'Slide648',
visible:'1'
},
sf_824:{
from:1,
to:90,
siaf:0.03,
sid:2.97,
mdi:'sf_824c',
apsn:'Slide782',
type:64
},
sf_824Ad:{
src:'ar/KeyClick.mp3',
from:1,
to:90,
du:2
},
sf_824c:{
id:'sf_824c',
b:[0,0,11,12],
l:528,
t:372,
dn:'sf_824',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg',
pkt:1
},
sf_828:{
from:1,
to:90,
siaf:0.03,
sid:2.97,
mdi:'sf_828c',
apsn:'Slide782',
type:64
},
sf_828c:{
id:'sf_828c',
b:[11,0,11,7],
l:528,
t:384,
dn:'sf_828',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_832:{
from:1,
to:90,
siaf:0.03,
sid:2.97,
mdi:'sf_832c',
apsn:'Slide782',
type:64
},
sf_832c:{
id:'sf_832c',
b:[22,0,39,12],
l:985,
t:663,
dn:'sf_832',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_836:{
from:1,
to:90,
siaf:0.03,
sid:2.97,
mdi:'sf_836c',
apsn:'Slide782',
type:64
},
sf_836c:{
id:'sf_836c',
b:[61,0,7,9],
l:1024,
t:666,
dn:'sf_836',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_844:{
from:6,
to:90,
siaf:0.2,
sid:2.8,
mdi:'sf_844c',
apsn:'Slide782',
type:64
},
sf_844Ad:{
src:'ar/KeyClick.mp3',
from:6,
to:90,
du:2
},
sf_844c:{
id:'sf_844c',
b:[68,0,10,12],
l:538,
t:372,
dn:'sf_844',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg',
pkt:1
},
sf_848:{
from:6,
to:90,
siaf:0.2,
sid:2.8,
mdi:'sf_848c',
apsn:'Slide782',
type:64
},
sf_848c:{
id:'sf_848c',
b:[78,0,10,7],
l:538,
t:384,
dn:'sf_848',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_856:{
from:10,
to:90,
siaf:0.33,
sid:2.67,
mdi:'sf_856c',
apsn:'Slide782',
type:64
},
sf_856Ad:{
src:'ar/KeyClick.mp3',
from:10,
to:90,
du:2
},
sf_856c:{
id:'sf_856c',
b:[88,0,13,12],
l:547,
t:372,
dn:'sf_856',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg',
pkt:1
},
sf_860:{
from:10,
to:90,
siaf:0.33,
sid:2.67,
mdi:'sf_860c',
apsn:'Slide782',
type:64
},
sf_860c:{
id:'sf_860c',
b:[101,0,13,7],
l:547,
t:384,
dn:'sf_860',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_868:{
from:15,
to:90,
siaf:0.5,
sid:2.5,
mdi:'sf_868c',
apsn:'Slide782',
type:64
},
sf_868Ad:{
src:'ar/KeyClick.mp3',
from:15,
to:90,
du:2
},
sf_868c:{
id:'sf_868c',
b:[114,0,5,12],
l:559,
t:372,
dn:'sf_868',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg',
pkt:1
},
sf_872:{
from:15,
to:90,
siaf:0.5,
sid:2.5,
mdi:'sf_872c',
apsn:'Slide782',
type:64
},
sf_872c:{
id:'sf_872c',
b:[119,0,5,7],
l:559,
t:384,
dn:'sf_872',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_878:{
from:17,
to:90,
siaf:0.57,
sid:2.43,
mdi:'sf_878c',
apsn:'Slide782',
type:64
},
sf_878c:{
id:'sf_878c',
b:[124,0,1,12],
l:563,
t:372,
dn:'sf_878',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_882:{
from:17,
to:90,
siaf:0.57,
sid:2.43,
mdi:'sf_882c',
apsn:'Slide782',
type:64
},
sf_882c:{
id:'sf_882c',
b:[125,0,1,7],
l:563,
t:384,
dn:'sf_882',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_888:{
from:19,
to:90,
siaf:0.63,
sid:2.37,
mdi:'sf_888c',
apsn:'Slide782',
type:64
},
sf_888Ad:{
src:'ar/KeyClick.mp3',
from:19,
to:90,
du:2
},
sf_888c:{
id:'sf_888c',
b:[126,0,10,12],
l:564,
t:372,
dn:'sf_888',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg',
pkt:1
},
sf_892:{
from:19,
to:90,
siaf:0.63,
sid:2.37,
mdi:'sf_892c',
apsn:'Slide782',
type:64
},
sf_892c:{
id:'sf_892c',
b:[136,0,10,7],
l:564,
t:384,
dn:'sf_892',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_900:{
from:24,
to:90,
siaf:0.8,
sid:2.2,
mdi:'sf_900c',
apsn:'Slide782',
type:64
},
sf_900Ad:{
src:'ar/KeyClick.mp3',
from:24,
to:90,
du:2
},
sf_900c:{
id:'sf_900c',
b:[146,0,5,12],
l:573,
t:372,
dn:'sf_900',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg',
pkt:1
},
sf_904:{
from:24,
to:90,
siaf:0.8,
sid:2.2,
mdi:'sf_904c',
apsn:'Slide782',
type:64
},
sf_904c:{
id:'sf_904c',
b:[151,0,5,7],
l:573,
t:384,
dn:'sf_904',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_912:{
from:28,
to:90,
siaf:0.93,
sid:2.07,
mdi:'sf_912c',
apsn:'Slide782',
type:64
},
sf_912Ad:{
src:'ar/KeyClick.mp3',
from:28,
to:90,
du:2
},
sf_912c:{
id:'sf_912c',
b:[156,0,10,12],
l:577,
t:372,
dn:'sf_912',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg',
pkt:1
},
sf_916:{
from:28,
to:90,
siaf:0.93,
sid:2.07,
mdi:'sf_916c',
apsn:'Slide782',
type:64
},
sf_916c:{
id:'sf_916c',
b:[166,0,10,7],
l:577,
t:384,
dn:'sf_916',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_924:{
from:33,
to:90,
siaf:1.1,
sid:1.9,
mdi:'sf_924c',
apsn:'Slide782',
type:64
},
sf_924Ad:{
src:'ar/KeyClick.mp3',
from:33,
to:90,
du:1
},
sf_924c:{
id:'sf_924c',
b:[176,0,9,12],
l:586,
t:372,
dn:'sf_924',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg',
pkt:1
},
sf_928:{
from:33,
to:90,
siaf:1.1,
sid:1.9,
mdi:'sf_928c',
apsn:'Slide782',
type:64
},
sf_928c:{
id:'sf_928c',
b:[185,0,9,7],
l:586,
t:384,
dn:'sf_928',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
sf_936:{
from:37,
to:90,
siaf:1.23,
sid:1.77,
mdi:'sf_936c',
apsn:'Slide782',
type:64
},
sf_936Ad:{
src:'ar/KeyClick.mp3',
from:37,
to:90,
du:1
},
sf_936c:{
id:'sf_936c',
b:[194,0,10,12],
l:594,
t:372,
dn:'sf_936',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg',
pkt:1
},
sf_940:{
from:37,
to:90,
siaf:1.23,
sid:1.77,
mdi:'sf_940c',
apsn:'Slide782',
type:64
},
sf_940c:{
id:'sf_940c',
b:[204,0,10,7],
l:594,
t:384,
dn:'sf_940',
visible:1,
effectiveVi:1,
ip:'dr/sfs3.jpg'
},
si808:{
name:'Simulation_4',
type:1268,
from:253,
to:300,
rp:0,
rpa:0,
mdi:'si808c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide782',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si800',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si808c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:808,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si808',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si800:{
name:'Simulation_non_responsive_4',
type:1268,
from:253,
to:300,
rp:0,
rpa:0,
mdi:'si800c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"object-typing-text":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si808',
retainState:false,
immo:false,
apsn:'Slide782',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'sf_824',
t:64
}
,{
n:'sf_828',
t:64
}
,{
n:'sf_832',
t:64
}
,{
n:'sf_836',
t:64
}
,{
n:'sf_844',
t:64
}
,{
n:'sf_848',
t:64
}
,{
n:'sf_856',
t:64
}
,{
n:'sf_860',
t:64
}
,{
n:'sf_868',
t:64
}
,{
n:'sf_872',
t:64
}
,{
n:'sf_878',
t:64
}
,{
n:'sf_882',
t:64
}
,{
n:'sf_888',
t:64
}
,{
n:'sf_892',
t:64
}
,{
n:'sf_900',
t:64
}
,{
n:'sf_904',
t:64
}
,{
n:'sf_912',
t:64
}
,{
n:'sf_916',
t:64
}
,{
n:'sf_924',
t:64
}
,{
n:'sf_928',
t:64
}
,{
n:'sf_936',
t:64
}
,{
n:'sf_940',
t:64
}
,{
n:'si942',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"object-typing-text":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si808',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si800c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:800,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si800',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:816,
tsp:50,
ip:'dr/0816.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si942:{
name:'Mouse_4',
type:12,
from:253,
to:300,
rp:0,
rpa:0,
mdi:'si942c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":1170,"mouseStartPointY":135,"mouseEndPointX":1171,"mouseEndPointY":131}}',
parentGroup:'si800',
retainState:false,
immo:false,
apsn:'Slide782',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si942Ad',
trin:0,
trout:0,
isDD:false
},
si942c:{
b:[1167,127,1184,150],
fh:false,
fw:false,
uid:942,
iso:false,
css:{
360:{
l:'120.062%',
t:'20.888%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'120.062%',
lhID:-1,
lvEID:0,
lvV:'20.888%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'120.062%',
t:'20.888%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'120.062%',
lhID:-1,
lvEID:0,
lvV:'20.888%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'120.062%',
t:'20.888%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'120.062%',
lhID:-1,
lvEID:0,
lvV:'20.888%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si942',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[1167,127,1184,150],
vb:[1167,127,1184,150]
},
si942Ad:{
src:'ar/Mouse.mp3',
from:253,
to:258,
del:2.818,
msa:1,
du:0.182
},
Slide782:{
lb:'Simulation slide 4',
id:782,
from:2557,
to:2646,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide782c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si808',
t:1268
}
]
,
iph:[]
,
oa:'si942Ad,sf_824Ad,sf_844Ad,sf_856Ad,sf_868Ad,sf_888Ad,sf_900Ad,sf_912Ad,sf_924Ad,sf_936Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide782c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:782,
dn:'Slide782',
visible:'1'
},
si975:{
name:'Simulation_5',
type:1268,
from:301,
to:390,
rp:0,
rpa:0,
mdi:'si975c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide949',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si967',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si975c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:975,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si975',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si967:{
name:'Simulation_non_responsive_5',
type:1268,
from:301,
to:390,
rp:0,
rpa:0,
mdi:'si967c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si975',
retainState:false,
immo:false,
apsn:'Slide949',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si986',
t:1269
}
,{
n:'si1006',
t:612
}
,{
n:'si1066',
t:612
}
,{
n:'si1076',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si975',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si967c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:967,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si967',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:983,
tsp:50,
ip:'dr/0983.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si986:{
name:'Highlight_box_3',
type:1269,
from:301,
to:390,
rp:0,
rpa:0,
mdi:'si986c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":661,"left":987,"width":34,"height":20}}',
parentGroup:'si967',
retainState:false,
immo:false,
apsn:'Slide949',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si996',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[986]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si986c:{
b:[987,661,1021,681],
fh:false,
fw:false,
uid:986,
iso:false,
css:{
360:{
l:'101.543%',
t:'108.717%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'101.543%',
lhID:-1,
lvEID:0,
lvV:'108.717%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'101.543%',
t:'108.717%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'101.543%',
lhID:-1,
lvEID:0,
lvV:'108.717%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'101.543%',
t:'108.717%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'101.543%',
lhID:-1,
lvEID:0,
lvV:'108.717%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si986',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[987,661,1021,681],
vb:[987,661,1021,681]
},
si996:{
name:'Shape_3',
type:612,
from:301,
to:390,
rp:0,
rpa:0,
mdi:'si996c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide949',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[996]
}
]
,
stis:0,
bstiid:986,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si986',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si996c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:996,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si996',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1006:{
name:'Rectangle_3',
type:612,
from:301,
to:390,
rp:0,
rpa:0,
mdi:'si1006c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":721,"left":1002,"width":300,"height":"auto"}}',
parentGroup:'si967',
retainState:false,
immo:false,
apsn:'Slide949',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1017,
stt:0,
dsr:'Default_State',
stsi:[1006]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1006','si1019','si1030','si1041'],
isDD:false
},
si1006c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1006,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1006',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1019:{
name:'',
type:612,
from:301,
to:390,
rp:0,
rpa:0,
mdi:'si1019c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":721,"left":1002,"width":300,"height":"auto"}}',
parentGroup:'si967',
retainState:false,
immo:false,
apsn:'Slide949',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1006',
stl:[{
stn:'Normal',
stt:0,
stsi:[1019]
}
]
,
stis:0,
bstiid:1006,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1006,
isDD:false
},
si1019c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1019,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1019',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1030:{
name:'',
type:612,
from:301,
to:390,
rp:0,
rpa:0,
mdi:'si1030c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":721,"left":1002,"width":300,"height":"auto"}}',
parentGroup:'si967',
retainState:false,
immo:false,
apsn:'Slide949',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1006',
stl:[{
stn:'Normal',
stt:0,
stsi:[1030]
}
]
,
stis:0,
bstiid:1006,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1006,
isDD:false
},
si1030c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1030,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1030',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1041:{
name:'',
type:612,
from:301,
to:390,
rp:0,
rpa:0,
mdi:'si1041c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":721,"left":1002,"width":300,"height":"auto"}}',
parentGroup:'si967',
retainState:false,
immo:false,
apsn:'Slide949',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1006',
stl:[{
stn:'Normal',
stt:0,
stsi:[1041]
}
]
,
stis:0,
bstiid:1006,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1006,
isDD:false
},
si1041c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1041,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1041',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1066:{
name:'Instructions_3',
type:612,
from:301,
to:390,
rp:0,
rpa:0,
mdi:'si1066c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":691,"left":994,"width":320}}',
parentGroup:'si967',
retainState:false,
immo:false,
apsn:'Slide949',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1066]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1066c:{
b:[994,691,1314,791],
fh:false,
fw:false,
uid:1066,
iso:false,
css:{
360:{
l:'102.263%',
t:'113.651%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'102.263%',
lhID:-1,
lvEID:0,
lvV:'113.651%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'102.263%',
t:'113.651%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'102.263%',
lhID:-1,
lvEID:0,
lvV:'113.651%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'102.263%',
t:'113.651%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'102.263%',
lhID:-1,
lvEID:0,
lvV:'113.651%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1066',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,1316,793],
vb:[-2,-2,1316,793]
},
si1076:{
name:'Mouse_5',
type:12,
from:307,
to:390,
rp:0,
rpa:0,
mdi:'si1076c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0.2,
sid:2.8,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":1179,"mouseStartPointY":139,"mouseEndPointX":1004,"mouseEndPointY":671}}',
parentGroup:'si967',
retainState:false,
immo:false,
apsn:'Slide949',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si1076Ad',
trin:0,
trout:0,
isDD:false
},
si1076c:{
b:[991,663,1023,695],
fh:false,
fw:false,
uid:1076,
iso:false,
css:{
360:{
l:'101.955%',
t:'109.046%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'101.955%',
lhID:-1,
lvEID:0,
lvV:'109.046%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'101.955%',
t:'109.046%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'101.955%',
lhID:-1,
lvEID:0,
lvV:'109.046%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'101.955%',
t:'109.046%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'101.955%',
lhID:-1,
lvEID:0,
lvV:'109.046%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1076',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[991,139,1180,695],
vb:[991,139,1180,695]
},
si1076Ad:{
src:'ar/Mouse.mp3',
from:307,
to:312,
del:2.818,
msa:1,
du:0.182
},
Slide949:{
lb:'Simulation slide 5',
id:949,
from:2647,
to:2736,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide949c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si975',
t:1268
}
]
,
iph:[]
,
oa:'si1076Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide949c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:949,
dn:'Slide949',
visible:'1'
},
si1109:{
name:'Simulation_6',
type:1268,
from:391,
to:420,
rp:0,
rpa:0,
mdi:'si1109c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1083',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1101',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1109c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1109,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1109',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1101:{
name:'Simulation_non_responsive_6',
type:1268,
from:391,
to:420,
rp:0,
rpa:0,
mdi:'si1101c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1109',
retainState:false,
immo:false,
apsn:'Slide1083',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1120',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1109',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1101c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1101,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1101',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:1117,
tsp:50,
ip:'dr/01117.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1120:{
name:'Mouse_6',
type:12,
from:391,
to:420,
rp:0,
rpa:0,
mdi:'si1120c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":1003,"mouseStartPointY":675,"mouseEndPointX":1074,"mouseEndPointY":662}}',
parentGroup:'si1101',
retainState:false,
immo:false,
apsn:'Slide1083',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si1120Ad',
trin:0,
trout:0,
isDD:false
},
si1120c:{
b:[1070,658,1087,681],
fh:false,
fw:false,
uid:1120,
iso:false,
css:{
360:{
l:'110.082%',
t:'108.224%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'110.082%',
lhID:-1,
lvEID:0,
lvV:'108.224%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'110.082%',
t:'108.224%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'110.082%',
lhID:-1,
lvEID:0,
lvV:'108.224%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'110.082%',
t:'108.224%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'110.082%',
lhID:-1,
lvEID:0,
lvV:'108.224%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1120',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[1003,658,1087,681],
vb:[1003,658,1087,681]
},
si1120Ad:{
src:'ar/Mouse.mp3',
from:391,
to:396,
del:0.818,
msa:1,
du:0.182
},
Slide1083:{
lb:'Simulation slide 6',
id:1083,
from:2737,
to:2766,
iols:0,
i360qs:false,
sdu:1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1083c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si1109',
t:1268
}
]
,
iph:[]
,
oa:'si1120Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1083c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1083,
dn:'Slide1083',
visible:'1'
},
si1153:{
name:'Simulation_7',
type:1268,
from:421,
to:510,
rp:0,
rpa:0,
mdi:'si1153c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1127',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1145',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1153c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1153,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1153',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1145:{
name:'Simulation_non_responsive_7',
type:1268,
from:421,
to:510,
rp:0,
rpa:0,
mdi:'si1145c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1153',
retainState:false,
immo:false,
apsn:'Slide1127',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1164',
t:1269
}
,{
n:'si1184',
t:612
}
,{
n:'si1244',
t:612
}
,{
n:'si1254',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1153',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1145c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1145,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1145',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:1161,
tsp:50,
ip:'dr/01161.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1164:{
name:'Highlight_box_4',
type:1269,
from:421,
to:510,
rp:0,
rpa:0,
mdi:'si1164c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":88,"left":603,"width":34,"height":20}}',
parentGroup:'si1145',
retainState:false,
immo:false,
apsn:'Slide1127',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si1174',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1164]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1164c:{
b:[603,88,637,108],
fh:false,
fw:false,
uid:1164,
iso:false,
css:{
360:{
l:'62.037%',
t:'14.474%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.037%',
lhID:-1,
lvEID:0,
lvV:'14.474%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'62.037%',
t:'14.474%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.037%',
lhID:-1,
lvEID:0,
lvV:'14.474%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'62.037%',
t:'14.474%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.037%',
lhID:-1,
lvEID:0,
lvV:'14.474%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1164',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[603,88,637,108],
vb:[603,88,637,108]
},
si1174:{
name:'Shape_4',
type:612,
from:421,
to:510,
rp:0,
rpa:0,
mdi:'si1174c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1127',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1174]
}
]
,
stis:0,
bstiid:1164,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1164',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1174c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1174,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1174',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1184:{
name:'Rectangle_4',
type:612,
from:421,
to:510,
rp:0,
rpa:0,
mdi:'si1184c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":148,"left":618,"width":300,"height":"auto"}}',
parentGroup:'si1145',
retainState:false,
immo:false,
apsn:'Slide1127',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1195,
stt:0,
dsr:'Default_State',
stsi:[1184]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1184','si1197','si1208','si1219'],
isDD:false
},
si1184c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1184,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1184',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1197:{
name:'',
type:612,
from:421,
to:510,
rp:0,
rpa:0,
mdi:'si1197c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":148,"left":618,"width":300,"height":"auto"}}',
parentGroup:'si1145',
retainState:false,
immo:false,
apsn:'Slide1127',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1184',
stl:[{
stn:'Normal',
stt:0,
stsi:[1197]
}
]
,
stis:0,
bstiid:1184,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1184,
isDD:false
},
si1197c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1197,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1197',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1208:{
name:'',
type:612,
from:421,
to:510,
rp:0,
rpa:0,
mdi:'si1208c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":148,"left":618,"width":300,"height":"auto"}}',
parentGroup:'si1145',
retainState:false,
immo:false,
apsn:'Slide1127',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1184',
stl:[{
stn:'Normal',
stt:0,
stsi:[1208]
}
]
,
stis:0,
bstiid:1184,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1184,
isDD:false
},
si1208c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1208,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1208',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1219:{
name:'',
type:612,
from:421,
to:510,
rp:0,
rpa:0,
mdi:'si1219c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":148,"left":618,"width":300,"height":"auto"}}',
parentGroup:'si1145',
retainState:false,
immo:false,
apsn:'Slide1127',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1184',
stl:[{
stn:'Normal',
stt:0,
stsi:[1219]
}
]
,
stis:0,
bstiid:1184,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1184,
isDD:false
},
si1219c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1219,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1219',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1244:{
name:'Instructions_4',
type:612,
from:421,
to:510,
rp:0,
rpa:0,
mdi:'si1244c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":118,"left":610,"width":320}}',
parentGroup:'si1145',
retainState:false,
immo:false,
apsn:'Slide1127',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1244]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1244c:{
b:[610,118,930,218],
fh:false,
fw:false,
uid:1244,
iso:false,
css:{
360:{
l:'62.757%',
t:'19.408%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.757%',
lhID:-1,
lvEID:0,
lvV:'19.408%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'62.757%',
t:'19.408%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.757%',
lhID:-1,
lvEID:0,
lvV:'19.408%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'62.757%',
t:'19.408%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.757%',
lhID:-1,
lvEID:0,
lvV:'19.408%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1244',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,932,220],
vb:[-2,-2,932,220]
},
si1254:{
name:'Mouse_7',
type:12,
from:421,
to:510,
rp:0,
rpa:0,
mdi:'si1254c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":1082,"mouseStartPointY":670,"mouseEndPointX":620,"mouseEndPointY":98}}',
parentGroup:'si1145',
retainState:false,
immo:false,
apsn:'Slide1127',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si1254Ad',
trin:0,
trout:0,
isDD:false
},
si1254c:{
b:[607,90,639,122],
fh:false,
fw:false,
uid:1254,
iso:false,
css:{
360:{
l:'62.449%',
t:'14.803%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.449%',
lhID:-1,
lvEID:0,
lvV:'14.803%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'62.449%',
t:'14.803%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.449%',
lhID:-1,
lvEID:0,
lvV:'14.803%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'62.449%',
t:'14.803%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.449%',
lhID:-1,
lvEID:0,
lvV:'14.803%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1254',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[607,90,1082,670],
vb:[607,90,1082,670]
},
si1254Ad:{
src:'ar/Mouse.mp3',
from:421,
to:426,
del:2.818,
msa:1,
du:0.182
},
Slide1127:{
lb:'Simulation slide 7',
id:1127,
from:2767,
to:2856,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1127c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si1153',
t:1268
}
]
,
iph:[]
,
oa:'si1254Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1127c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1127,
dn:'Slide1127',
visible:'1'
},
si1287:{
name:'Simulation_8',
type:1268,
from:511,
to:600,
rp:0,
rpa:0,
mdi:'si1287c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1261',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1279',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1287c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1287,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1287',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1279:{
name:'Simulation_non_responsive_8',
type:1268,
from:511,
to:600,
rp:0,
rpa:0,
mdi:'si1279c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1287',
retainState:false,
immo:false,
apsn:'Slide1261',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1298',
t:1269
}
,{
n:'si1318',
t:612
}
,{
n:'si1378',
t:612
}
,{
n:'si1388',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1287',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1279c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1279,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1279',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:1295,
tsp:50,
ip:'dr/01295.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1298:{
name:'Highlight_box_5',
type:1269,
from:511,
to:600,
rp:0,
rpa:0,
mdi:'si1298c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":151,"left":569,"width":34,"height":20}}',
parentGroup:'si1279',
retainState:false,
immo:false,
apsn:'Slide1261',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si1308',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1298]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1298c:{
b:[569,151,603,171],
fh:false,
fw:false,
uid:1298,
iso:false,
css:{
360:{
l:'58.539%',
t:'24.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'58.539%',
lhID:-1,
lvEID:0,
lvV:'24.836%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'58.539%',
t:'24.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'58.539%',
lhID:-1,
lvEID:0,
lvV:'24.836%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'58.539%',
t:'24.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'58.539%',
lhID:-1,
lvEID:0,
lvV:'24.836%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1298',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[569,151,603,171],
vb:[569,151,603,171]
},
si1308:{
name:'Shape_5',
type:612,
from:511,
to:600,
rp:0,
rpa:0,
mdi:'si1308c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1261',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1308]
}
]
,
stis:0,
bstiid:1298,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1298',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1308c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1308,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1308',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1318:{
name:'Rectangle_5',
type:612,
from:511,
to:600,
rp:0,
rpa:0,
mdi:'si1318c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":211,"left":584,"width":300,"height":"auto"}}',
parentGroup:'si1279',
retainState:false,
immo:false,
apsn:'Slide1261',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1329,
stt:0,
dsr:'Default_State',
stsi:[1318]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1318','si1331','si1342','si1353'],
isDD:false
},
si1318c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1318,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1318',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1331:{
name:'',
type:612,
from:511,
to:600,
rp:0,
rpa:0,
mdi:'si1331c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":211,"left":584,"width":300,"height":"auto"}}',
parentGroup:'si1279',
retainState:false,
immo:false,
apsn:'Slide1261',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1318',
stl:[{
stn:'Normal',
stt:0,
stsi:[1331]
}
]
,
stis:0,
bstiid:1318,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1318,
isDD:false
},
si1331c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1331,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1331',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1342:{
name:'',
type:612,
from:511,
to:600,
rp:0,
rpa:0,
mdi:'si1342c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":211,"left":584,"width":300,"height":"auto"}}',
parentGroup:'si1279',
retainState:false,
immo:false,
apsn:'Slide1261',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1318',
stl:[{
stn:'Normal',
stt:0,
stsi:[1342]
}
]
,
stis:0,
bstiid:1318,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1318,
isDD:false
},
si1342c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1342,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1342',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1353:{
name:'',
type:612,
from:511,
to:600,
rp:0,
rpa:0,
mdi:'si1353c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":211,"left":584,"width":300,"height":"auto"}}',
parentGroup:'si1279',
retainState:false,
immo:false,
apsn:'Slide1261',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1318',
stl:[{
stn:'Normal',
stt:0,
stsi:[1353]
}
]
,
stis:0,
bstiid:1318,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1318,
isDD:false
},
si1353c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1353,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1353',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1378:{
name:'Instructions_5',
type:612,
from:511,
to:600,
rp:0,
rpa:0,
mdi:'si1378c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":181,"left":576,"width":320}}',
parentGroup:'si1279',
retainState:false,
immo:false,
apsn:'Slide1261',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1378]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1378c:{
b:[576,181,896,281],
fh:false,
fw:false,
uid:1378,
iso:false,
css:{
360:{
l:'59.259%',
t:'29.770%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'59.259%',
lhID:-1,
lvEID:0,
lvV:'29.770%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'59.259%',
t:'29.770%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'59.259%',
lhID:-1,
lvEID:0,
lvV:'29.770%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'59.259%',
t:'29.770%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'59.259%',
lhID:-1,
lvEID:0,
lvV:'29.770%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1378',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,898,283],
vb:[-2,-2,898,283]
},
si1388:{
name:'Mouse_8',
type:12,
from:553,
to:600,
rp:0,
rpa:0,
mdi:'si1388c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":619,"mouseStartPointY":102,"mouseEndPointX":586,"mouseEndPointY":161}}',
parentGroup:'si1279',
retainState:false,
immo:false,
apsn:'Slide1261',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si1388Ad',
trin:0,
trout:0,
isDD:false
},
si1388c:{
b:[573,153,605,185],
fh:false,
fw:false,
uid:1388,
iso:false,
css:{
360:{
l:'58.951%',
t:'25.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'58.951%',
lhID:-1,
lvEID:0,
lvV:'25.164%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'58.951%',
t:'25.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'58.951%',
lhID:-1,
lvEID:0,
lvV:'25.164%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'58.951%',
t:'25.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'58.951%',
lhID:-1,
lvEID:0,
lvV:'25.164%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1388',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[573,102,619,185],
vb:[573,102,619,185]
},
si1388Ad:{
src:'ar/Mouse.mp3',
from:553,
to:558,
del:2.818,
msa:1,
du:0.182
},
Slide1261:{
lb:'Simulation slide 8',
id:1261,
from:2857,
to:2946,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1261c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si1287',
t:1268
}
]
,
iph:[]
,
oa:'si1388Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1261c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1261,
dn:'Slide1261',
visible:'1'
},
si1421:{
name:'Simulation_9',
type:1268,
from:601,
to:690,
rp:0,
rpa:0,
mdi:'si1421c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1395',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1413',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1421c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1421,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1421',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1413:{
name:'Simulation_non_responsive_9',
type:1268,
from:601,
to:690,
rp:0,
rpa:0,
mdi:'si1413c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1421',
retainState:false,
immo:false,
apsn:'Slide1395',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1432',
t:1269
}
,{
n:'si1452',
t:612
}
,{
n:'si1512',
t:612
}
,{
n:'si1522',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1421',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1413c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1413,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1413',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:1429,
tsp:50,
ip:'dr/01429.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1432:{
name:'Highlight_box_6',
type:1269,
from:601,
to:690,
rp:0,
rpa:0,
mdi:'si1432c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":215,"left":595,"width":34,"height":20}}',
parentGroup:'si1413',
retainState:false,
immo:false,
apsn:'Slide1395',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si1442',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1432]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1432c:{
b:[595,215,629,235],
fh:false,
fw:false,
uid:1432,
iso:false,
css:{
360:{
l:'61.214%',
t:'35.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'61.214%',
lhID:-1,
lvEID:0,
lvV:'35.362%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'61.214%',
t:'35.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'61.214%',
lhID:-1,
lvEID:0,
lvV:'35.362%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'61.214%',
t:'35.362%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'61.214%',
lhID:-1,
lvEID:0,
lvV:'35.362%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1432',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[595,215,629,235],
vb:[595,215,629,235]
},
si1442:{
name:'Shape_6',
type:612,
from:601,
to:690,
rp:0,
rpa:0,
mdi:'si1442c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1395',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1442]
}
]
,
stis:0,
bstiid:1432,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1432',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1442c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1442,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1442',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1452:{
name:'Rectangle_6',
type:612,
from:601,
to:690,
rp:0,
rpa:0,
mdi:'si1452c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":275,"left":610,"width":300,"height":"auto"}}',
parentGroup:'si1413',
retainState:false,
immo:false,
apsn:'Slide1395',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1463,
stt:0,
dsr:'Default_State',
stsi:[1452]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1452','si1465','si1476','si1487'],
isDD:false
},
si1452c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1452,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1452',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1465:{
name:'',
type:612,
from:601,
to:690,
rp:0,
rpa:0,
mdi:'si1465c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":275,"left":610,"width":300,"height":"auto"}}',
parentGroup:'si1413',
retainState:false,
immo:false,
apsn:'Slide1395',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1452',
stl:[{
stn:'Normal',
stt:0,
stsi:[1465]
}
]
,
stis:0,
bstiid:1452,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1452,
isDD:false
},
si1465c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1465,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1465',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1476:{
name:'',
type:612,
from:601,
to:690,
rp:0,
rpa:0,
mdi:'si1476c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":275,"left":610,"width":300,"height":"auto"}}',
parentGroup:'si1413',
retainState:false,
immo:false,
apsn:'Slide1395',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1452',
stl:[{
stn:'Normal',
stt:0,
stsi:[1476]
}
]
,
stis:0,
bstiid:1452,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1452,
isDD:false
},
si1476c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1476,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1476',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1487:{
name:'',
type:612,
from:601,
to:690,
rp:0,
rpa:0,
mdi:'si1487c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":275,"left":610,"width":300,"height":"auto"}}',
parentGroup:'si1413',
retainState:false,
immo:false,
apsn:'Slide1395',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1452',
stl:[{
stn:'Normal',
stt:0,
stsi:[1487]
}
]
,
stis:0,
bstiid:1452,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1452,
isDD:false
},
si1487c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1487,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1487',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1512:{
name:'Instructions_6',
type:612,
from:601,
to:690,
rp:0,
rpa:0,
mdi:'si1512c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":245,"left":602,"width":320}}',
parentGroup:'si1413',
retainState:false,
immo:false,
apsn:'Slide1395',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1512]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1512c:{
b:[602,245,922,345],
fh:false,
fw:false,
uid:1512,
iso:false,
css:{
360:{
l:'61.934%',
t:'40.296%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'61.934%',
lhID:-1,
lvEID:0,
lvV:'40.296%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'61.934%',
t:'40.296%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'61.934%',
lhID:-1,
lvEID:0,
lvV:'40.296%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'61.934%',
t:'40.296%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'61.934%',
lhID:-1,
lvEID:0,
lvV:'40.296%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1512',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,924,347],
vb:[-2,-2,924,347]
},
si1522:{
name:'Mouse_9',
type:12,
from:643,
to:690,
rp:0,
rpa:0,
mdi:'si1522c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":585,"mouseStartPointY":165,"mouseEndPointX":612,"mouseEndPointY":225}}',
parentGroup:'si1413',
retainState:false,
immo:false,
apsn:'Slide1395',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si1522Ad',
trin:0,
trout:0,
isDD:false
},
si1522c:{
b:[599,217,631,249],
fh:false,
fw:false,
uid:1522,
iso:false,
css:{
360:{
l:'61.626%',
t:'35.691%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'61.626%',
lhID:-1,
lvEID:0,
lvV:'35.691%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'61.626%',
t:'35.691%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'61.626%',
lhID:-1,
lvEID:0,
lvV:'35.691%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'61.626%',
t:'35.691%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'61.626%',
lhID:-1,
lvEID:0,
lvV:'35.691%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1522',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[585,165,631,249],
vb:[585,165,631,249]
},
si1522Ad:{
src:'ar/Mouse.mp3',
from:643,
to:648,
del:2.818,
msa:1,
du:0.182
},
Slide1395:{
lb:'Simulation slide 9',
id:1395,
from:2947,
to:3036,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1395c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si1421',
t:1268
}
]
,
iph:[]
,
oa:'si1522Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1395c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1395,
dn:'Slide1395',
visible:'1'
},
si3459:{
name:'ResponsiveContainer_47',
type:1268,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3459c',
tag:'container-true-or-false',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":20,"bottom":20,"left":10,"right":10},"canBeCard":false,"isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3467',
t:1268
}
,{
n:'si3624',
t:612
}
,{
n:'si3669',
t:612
}
]
,
containerType:'true-or-false',
widgetProps:'{"padding":{"top":20,"bottom":20,"left":10,"right":10},"canBeCard":false,"isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3459c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3459,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3459',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--undefined)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3467:{
name:'ResponsiveContainer_48',
type:1268,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3467c',
tag:'container-true-or-false-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"visibilityInfo":{"slide-item-review-back-button":true,"slide-item-skip-button":true,"slide-item-submit-button":true,"slide-item-progress-indicator":true,"slide-item-clear-button":false,"card":true,"slide-item-answer-checkbox":true,"slide-item-review-next-button":true,"slide-item-question-text":true,"slide-item-view-answer-button":true,"slide-item-back-button":false},"groupedItemsVisibility":{"slide-item-answer-checkbox":2},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":10,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":12,"bottomLeft":12,"bottomRight":12,"topRight":12}},"shadow":{"shadowX":0,"shadowY":3,"shadowBlur":6,"enabled":true,"color":"var(--c4)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingLeft":"30px","paddingRight":"30px"},"tablet":{"paddingLeft":"15px","paddingRight":"15px"},"mobile":{"paddingLeft":"15px","paddingRight":"15px"}},"childNodesCustomStyles":{"container-question-answer-area":{"all":{"display":"flex","flexDirection":"column","marginBottom":"50px","paddingLeft":"60px","paddingRight":"60px"},"tablet":{"paddingLeft":"15px","paddingRight":"15px","marginBottom":"30px"},"mobile":{"paddingLeft":"15px","paddingRight":"15px","marginBottom":"30px"}},"container-answer-area":{"all":{"display":"flex","flexDirection":"row","marginBottom":"50px","rowGap":"12px","marginTop":"50px","marginRight":"60px","gap":"18px","width":"fit-content"},"tablet":{"marginTop":"15px","marginBottom":"20px","flexDirection":"column"},"mobile":{"flexDirection":"column","marginTop":"15px","marginBottom":"20px"}},"container-question-buttons":{"all":{"display":"flex","justifyContent":"flex-end","gap":"20px","marginTop":"30px","paddingLeft":"60px","marginBottom":"40px","paddingRight":"60px"},"tablet":{"paddingLeft":"20px","paddingRight":"20px","marginTop":"10px","marginBottom":"20px"},"mobile":{"flexDirection":"column","paddingLeft":"15px","paddingRight":"15px","marginTop":"10px","marginBottom":"20px"}}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3475',
t:1250
}
,{
n:'si3484',
t:1250
}
,{
n:'si3495',
t:10090
}
,{
n:'si3507',
t:10090
}
,{
n:'si3522',
t:29
}
,{
n:'si3570',
t:29
}
,{
n:'si3585',
t:29
}
,{
n:'si3594',
t:29
}
,{
n:'si3609',
t:29
}
]
,
containerType:'true-or-false-card',
widgetProps:'{"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"visibilityInfo":{"slide-item-review-back-button":true,"slide-item-skip-button":true,"slide-item-submit-button":true,"slide-item-progress-indicator":true,"slide-item-clear-button":false,"card":true,"slide-item-answer-checkbox":true,"slide-item-review-next-button":true,"slide-item-question-text":true,"slide-item-view-answer-button":true,"slide-item-back-button":false},"groupedItemsVisibility":{"slide-item-answer-checkbox":2},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":10,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":12,"bottomLeft":12,"bottomRight":12,"topRight":12}},"shadow":{"shadowX":0,"shadowY":3,"shadowBlur":6,"enabled":true,"color":"var(--c4)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingLeft":"30px","paddingRight":"30px"},"tablet":{"paddingLeft":"15px","paddingRight":"15px"},"mobile":{"paddingLeft":"15px","paddingRight":"15px"}},"childNodesCustomStyles":{"container-question-answer-area":{"all":{"display":"flex","flexDirection":"column","marginBottom":"50px","paddingLeft":"60px","paddingRight":"60px"},"tablet":{"paddingLeft":"15px","paddingRight":"15px","marginBottom":"30px"},"mobile":{"paddingLeft":"15px","paddingRight":"15px","marginBottom":"30px"}},"container-answer-area":{"all":{"display":"flex","flexDirection":"row","marginBottom":"50px","rowGap":"12px","marginTop":"50px","marginRight":"60px","gap":"18px","width":"fit-content"},"tablet":{"marginTop":"15px","marginBottom":"20px","flexDirection":"column"},"mobile":{"flexDirection":"column","marginTop":"15px","marginBottom":"20px"}},"container-question-buttons":{"all":{"display":"flex","justifyContent":"flex-end","gap":"20px","marginTop":"30px","paddingLeft":"60px","marginBottom":"40px","paddingRight":"60px"},"tablet":{"paddingLeft":"20px","paddingRight":"20px","marginTop":"10px","marginBottom":"20px"},"mobile":{"flexDirection":"column","paddingLeft":"15px","paddingRight":"15px","marginTop":"10px","marginBottom":"20px"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3459',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3467c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3467,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3467',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3475:{
name:'Text_270',
type:1250,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3475c',
tag:'slide-item-progress-indicator',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"editable":false,"supportStates":false,"shouldRender":true,"designOptionStyles":{"all":{"marginTop":"5%","marginBottom":"15px"},"tablet":{},"mobile":{}}}',
parentGroup:'si3467',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"cm9c4","text":"Question @#{101} / @#{102}","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":26,"style":"hlnk:"},{"offset":0,"length":26,"style":"hlnkt:wp"},{"offset":0,"length":26,"style":"textOutlineEnable:false"},{"offset":0,"length":26,"style":"opacity:1"},{"offset":0,"length":26,"style":"hlnke:true"},{"offset":0,"length":26,"style":"backgroundColor:unset"},{"offset":0,"length":26,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":26,"style":"textHighlightEnable:false"},{"offset":0,"length":26,"style":"textShadowEnable:false"},{"offset":0,"length":26,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:14,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3475]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3475c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3475,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3475',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3484:{
name:'Text_271',
type:1250,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3484c',
tag:'slide-item-question-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"supportStates":false,"shouldRender":true,"designOptionStyles":{"all":{"marginTop":"20px","marginBottom":"30px"},"tablet":{"marginBottom":"15px"},"mobile":{"marginBottom":"15px"}}}',
parentGroup:'si3467',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"es8kv","text":"Sequential or Topic Driven","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":26,"style":"overridden:false"},{"offset":0,"length":26,"style":"hlnk:"},{"offset":0,"length":26,"style":"hlnkt:wp"},{"offset":0,"length":26,"style":"textOutlineEnable:false"},{"offset":0,"length":26,"style":"opacity:1"},{"offset":0,"length":26,"style":"hlnke:true"},{"offset":0,"length":26,"style":"backgroundColor:unset"},{"offset":0,"length":26,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":26,"style":"textHighlightEnable:false"},{"offset":0,"length":26,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-question-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3484]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3484c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:3484,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3484',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si3495:{
name:'Checkbox_1',
type:10090,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3495c',
tag:'slide-item-answer-checkbox0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:11,
isOverridden:false
}
]
,
widgetProps:'{"imagePath":"03493.png","size":{"desktop":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":280,"height":210},"imageMarginLeft":36,"textMarginLeft":36,"fontSize":18,"rowGap":16},"tablet":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":240,"height":180},"imageMarginLeft":36,"textMarginLeft":36,"fontSize":18,"rowGap":16},"mobile":{"shapeSize":{"width":18,"height":18},"imageSize":{"width":200,"height":150},"imageMarginLeft":36,"textMarginLeft":36,"fontSize":18,"rowGap":16}},"stateVisibility":{"normal":true,"hover":true,"selected":true,"disabledChecked":true,"disabledUnchecked":true},"imageSizeData":{"x":0,"y":0,"originalWidth":490,"originalHeight":370},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"cn447","text":"True","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style","fillEnable":false,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_default","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color3)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"scaleValue":"medium","shouldRender":true,"disabledChecked":{"opacity":100,"editorState":{"blocks":[{"key":"9kksr","text":"True","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_checked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color3)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color3)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"shapeData":{"type":"rect","attributes":{"rx":"25%"}},"selectedByDefault":false,"disabledUnchecked":{"opacity":100,"editorState":{"blocks":[{"key":"cmp78","text":"True","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_unchecked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"appearenceProperties":{"fill":{"enabled":false,"color":"var(--design-option-color3)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"CHECKBOX_ITEM_OPTION_2","isImageActive":true,"currentState":"normal","selected":{"opacity":100,"editorState":{"blocks":[{"key":"1p4qd","text":"True","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":false,"overlayEnabled":true,"magnificationEnabled":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color3)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":3}},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color4)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"hover":{"opacity":100,"editorState":{"blocks":[{"key":"vog2","text":"True","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-uic-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color3)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"isTextActive":true,"designOptionStyles":{}}',
parentGroup:'si3467',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
sz:1,
ccmn:'',
ic:true,
si:[]
,
te:true,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3495]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3495c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3495,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.889%',
h:'0.526%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'2.333%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'1.440%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3495',
visible:1,
effectiveVi:1,
JSONEffectData:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:true,
ap:0,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3507:{
name:'Checkbox_2',
type:10090,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3507c',
tag:'slide-item-answer-checkbox1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:11,
isOverridden:false
}
]
,
widgetProps:'{"imagePath":"03493.png","size":{"desktop":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":280,"height":210},"imageMarginLeft":36,"textMarginLeft":36,"fontSize":18,"rowGap":16},"tablet":{"shapeSize":{"width":20,"height":20},"imageSize":{"width":240,"height":180},"imageMarginLeft":36,"textMarginLeft":36,"fontSize":18,"rowGap":16},"mobile":{"shapeSize":{"width":18,"height":18},"imageSize":{"width":200,"height":150},"imageMarginLeft":36,"textMarginLeft":36,"fontSize":18,"rowGap":16}},"stateVisibility":{"normal":true,"hover":true,"selected":true,"disabledChecked":true,"disabledUnchecked":true},"imageSizeData":{"x":0,"y":0,"originalWidth":490,"originalHeight":370},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"5pmne","text":"False","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"overridden:false"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style","fillEnable":false,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_default","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color3)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"scaleValue":"medium","shouldRender":true,"disabledChecked":{"opacity":100,"editorState":{"blocks":[{"key":"d6129","text":"False","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"overridden:false"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_checked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color3)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color3)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"shapeData":{"type":"rect","attributes":{"rx":"25%"}},"selectedByDefault":false,"disabledUnchecked":{"opacity":100,"editorState":{"blocks":[{"key":"25m34","text":"False","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"overridden:false"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-uic-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_disabled_unchecked","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"appearenceProperties":{"fill":{"enabled":false,"color":"var(--design-option-color3)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"CHECKBOX_ITEM_OPTION_2","isImageActive":true,"currentState":"normal","selected":{"opacity":100,"editorState":{"blocks":[{"key":"9o4fc","text":"False","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":false,"overlayEnabled":true,"magnificationEnabled":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color3)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":3}},"svgAppearenceProperties":{"stroke":{"color":"var(--palette-color4)","dasharray":0,"enabled":true,"linecap":0,"width":4},"tickType":0}},"hover":{"opacity":100,"editorState":{"blocks":[{"key":"e1qka","text":"False","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-uic-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_checkbox_shape_1_solid_style_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"imagePresetData":{"presetId":"theme_image_overlay","borderEnable":true,"shadowEnable":true,"overlayEnabled":true,"magnificationEnabled":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color3)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"isTextActive":true,"designOptionStyles":{}}',
parentGroup:'si3467',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
sz:1,
ccmn:'',
ic:false,
si:[]
,
te:true,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3507]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3507c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3507,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.889%',
h:'0.526%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'2.333%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'1.440%',
h:'0.658%',
cah:false,
cav:false,
rpmm:{
mw:'14px',
mh:'4px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3507',
visible:1,
effectiveVi:1,
JSONEffectData:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:true,
ap:0,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3522:{
name:'Button_219',
type:29,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3522c',
tag:'slide-item-submit-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"blv5m","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8a7th","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","iconProps":{"srcPath":"03519.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2nm8h","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"433el","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7q259","text":"Submit","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOptionStyles":{}}',
parentGroup:'si3467',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3522]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3522c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3522,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3522',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3570:{
name:'Button_222',
type:29,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3570c',
tag:'slide-item-skip-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"94bsm","text":"Skip","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2qu7q","text":"Skip","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","iconProps":{"srcPath":"03519.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d16ep","text":"Skip","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7o0nl","text":"Skip","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2arn4","text":"Skip","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOptionStyles":{}}',
parentGroup:'si3467',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3570]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3570c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3570,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3570',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3585:{
name:'Button_223',
type:29,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3585c',
tag:'slide-item-view-answer-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9a3k1","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"68utt","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{"all":{"marginRight":"auto"},"tablet":{},"mobile":{"marginRight":"unset"}},"iconProps":{"srcPath":"03519.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dsqio","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5icbu","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9dq1d","text":"View answer","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si3467',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:6,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3585]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3585c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3585,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3585',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3594:{
name:'Button_224',
type:29,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3594c',
tag:'slide-item-review-back-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9oru","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"c8t4f","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","iconProps":{"srcPath":"03519.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5t5vc","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"30qb0","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"qa1m","text":"Back","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOptionStyles":{}}',
parentGroup:'si3467',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:5,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3594]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3594c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3594,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3594',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3609:{
name:'Button_225',
type:29,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3609c',
tag:'slide-item-review-next-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"b6bii","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1v36","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","iconProps":{"srcPath":"03519.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cs80j","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d0417","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"eu44t","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOptionStyles":{}}',
parentGroup:'si3467',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:4,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3609]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3609c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3609,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3609',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3637:{
name:'Caption_1',
type:612,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3637c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ef571","text":"That\'s correct! Click anywhere or press \'y\' to continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"hlnk:"},{"offset":0,"length":55,"style":"hlnkt:wp"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"hlnke:true"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"},{"offset":0,"length":55,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3624',
stl:[{
stn:'Normal',
stt:0,
stsi:[3637]
}
]
,
stis:0,
bstiid:3624,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3624,
isDD:false
},
si3637c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3637,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3637',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3648:{
name:'Caption_1',
type:612,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3648c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"aosoo","text":"That\'s incorrect! Click anywhere or press \'y\' to continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"},{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"hlnk:"},{"offset":0,"length":57,"style":"hlnkt:wp"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"hlnke:true"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3624',
stl:[{
stn:'Normal',
stt:0,
stsi:[3648]
}
]
,
stis:0,
bstiid:3624,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3624,
isDD:false
},
si3648c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3648,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3648',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3659:{
name:'Caption_1',
type:612,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3659c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"31uui","text":"You must answer the question before continuing","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":46,"style":"hlnk:"},{"offset":0,"length":46,"style":"hlnkt:wp"},{"offset":0,"length":46,"style":"textOutlineEnable:false"},{"offset":0,"length":46,"style":"opacity:1"},{"offset":0,"length":46,"style":"hlnke:true"},{"offset":0,"length":46,"style":"backgroundColor:unset"},{"offset":0,"length":46,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":46,"style":"textHighlightEnable:false"},{"offset":0,"length":46,"style":"textShadowEnable:false"},{"offset":0,"length":46,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incomplete","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3624',
stl:[{
stn:'Normal',
stt:0,
stsi:[3659]
}
]
,
stis:0,
bstiid:3624,
sipst:104,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3624,
isDD:false
},
si3659c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3659,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3659',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3624:{
name:'Caption_1',
type:612,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3624c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"3rkf5","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:3635,
stt:0,
dsr:'Default_State',
stsi:[3624]
}
,{
stn:3636,
stt:101,
dsr:'Correct',
stsi:[3637]
}
,{
stn:3647,
stt:102,
dsr:'Incorrect',
stsi:[3648]
}
,{
stn:3658,
stt:104,
dsr:'Incomplete',
stsi:[3659]
}
,{
stn:3982,
stt:105,
dsr:'Retry',
stsi:[3983]
}
,{
stn:3993,
stt:103,
dsr:'Hint',
stsi:[3994]
}
,{
stn:4004,
stt:106,
dsr:'Timeout',
stsi:[4005]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si3624','si3637','si3648','si3659','si3983','si3994','si4005'],
isDD:false
},
si3624c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3624,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3624',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3983:{
name:'Caption_1',
type:612,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3983c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"dlkru","text":"That\'s incorrect! Try again.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":28,"style":"hlnk:"},{"offset":0,"length":28,"style":"hlnkt:wp"},{"offset":0,"length":28,"style":"textOutlineEnable:false"},{"offset":0,"length":28,"style":"opacity:1"},{"offset":0,"length":28,"style":"hlnke:true"},{"offset":0,"length":28,"style":"backgroundColor:unset"},{"offset":0,"length":28,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":28,"style":"textHighlightEnable:false"},{"offset":0,"length":28,"style":"textShadowEnable:false"},{"offset":0,"length":28,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_retry","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3624',
stl:[{
stn:'Normal',
stt:0,
stsi:[3983]
}
]
,
stis:0,
bstiid:3624,
sipst:105,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3624,
isDD:false
},
si3983c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3983,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3983',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3994:{
name:'Caption_1',
type:612,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3994c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4oib9","text":"Here is a hint to help you answer the question.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":47,"style":"textHighlightEnable:false"},{"offset":0,"length":47,"style":"textShadowEnable:false"},{"offset":0,"length":47,"style":"overridden:false"},{"offset":0,"length":47,"style":"hlnk:"},{"offset":0,"length":47,"style":"hlnkt:wp"},{"offset":0,"length":47,"style":"textOutlineEnable:false"},{"offset":0,"length":47,"style":"opacity:1"},{"offset":0,"length":47,"style":"hlnke:true"},{"offset":0,"length":47,"style":"backgroundColor:unset"},{"offset":0,"length":47,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-caption_hint","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3624',
stl:[{
stn:'Normal',
stt:0,
stsi:[3994]
}
]
,
stis:0,
bstiid:3624,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3624,
isDD:false
},
si3994c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3994,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3994',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si4005:{
name:'Caption_1',
type:612,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si4005c',
tag:'slide-item-question-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"bv96c","text":"The time to answer this question has expired. Click anywhere or press \'y\' to continue.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":86,"style":"hlnk:"},{"offset":0,"length":86,"style":"hlnkt:wp"},{"offset":0,"length":86,"style":"textOutlineEnable:false"},{"offset":0,"length":86,"style":"opacity:1"},{"offset":0,"length":86,"style":"hlnke:true"},{"offset":0,"length":86,"style":"backgroundColor:unset"},{"offset":0,"length":86,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":86,"style":"textHighlightEnable:false"},{"offset":0,"length":86,"style":"textShadowEnable:false"},{"offset":0,"length":86,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_timeout","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3624',
stl:[{
stn:'Normal',
stt:0,
stsi:[4005]
}
]
,
stis:0,
bstiid:3624,
sipst:106,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3624,
isDD:false
},
si4005c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:4005,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si4005',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3682:{
name:'Caption_2',
type:612,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3682c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"bbc6d","text":"Your answer is correct","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":22,"style":"overridden:false"},{"offset":0,"length":22,"style":"hlnk:"},{"offset":0,"length":22,"style":"hlnkt:wp"},{"offset":0,"length":22,"style":"textOutlineEnable:false"},{"offset":0,"length":22,"style":"opacity:1"},{"offset":0,"length":22,"style":"hlnke:true"},{"offset":0,"length":22,"style":"backgroundColor:unset"},{"offset":0,"length":22,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":22,"style":"textHighlightEnable:false"},{"offset":0,"length":22,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3669',
stl:[{
stn:'Normal',
stt:0,
stsi:[3682]
}
]
,
stis:0,
bstiid:3669,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3669,
isDD:false
},
si3682c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3682,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3682',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3693:{
name:'Caption_2',
type:612,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3693c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"8ntt8","text":"Your answer is incorrect","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"hlnk:"},{"offset":0,"length":24,"style":"hlnkt:wp"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"backgroundColor:unset"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":24,"style":"textHighlightEnable:false"},{"offset":0,"length":24,"style":"textShadowEnable:false"},{"offset":0,"length":24,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3669',
stl:[{
stn:'Normal',
stt:0,
stsi:[3693]
}
]
,
stis:0,
bstiid:3669,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3669,
isDD:false
},
si3693c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3693,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3693',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3704:{
name:'Caption_2',
type:612,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3704c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"401la","text":"You did not answer this question completely","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":43,"style":"hlnk:"},{"offset":0,"length":43,"style":"hlnkt:wp"},{"offset":0,"length":43,"style":"textOutlineEnable:false"},{"offset":0,"length":43,"style":"opacity:1"},{"offset":0,"length":43,"style":"hlnke:true"},{"offset":0,"length":43,"style":"backgroundColor:unset"},{"offset":0,"length":43,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":43,"style":"textHighlightEnable:false"},{"offset":0,"length":43,"style":"textShadowEnable:false"},{"offset":0,"length":43,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incomplete","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3669',
stl:[{
stn:'Normal',
stt:0,
stsi:[3704]
}
]
,
stis:0,
bstiid:3669,
sipst:104,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3669,
isDD:false
},
si3704c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3704,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3704',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3669:{
name:'Caption_2',
type:612,
from:3037,
to:3126,
rp:0,
rpa:0,
mdi:'si3669c',
tag:'slide-item-question-review-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3459',
retainState:false,
immo:false,
apsn:'Slide3410',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"2g2ol","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:3680,
stt:0,
dsr:'Default_State',
stsi:[3669]
}
,{
stn:3681,
stt:101,
dsr:'Correct',
stsi:[3682]
}
,{
stn:3692,
stt:102,
dsr:'Incorrect',
stsi:[3693]
}
,{
stn:3703,
stt:104,
dsr:'Incomplete',
stsi:[3704]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si3669','si3682','si3693','si3704'],
isDD:false
},
si3669c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3669,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3669',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide3410:{
lb:'True or false 1',
id:3410,
from:3037,
to:3126,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide3410c',
st:'Question Slide',
sk:'True or false',
slideTag:'true-false-slide',
type:77,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si3459',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
imgf:{
ip:'dr/04015.jpg',
tiletype:0,
imageFocus:0,
extraImageProps:'',
id:4015,
w:1133,
h:836,
tsp:50
}
,
iso:true,
se:false
}
,
osa:'{"scripts":[{"then":[["cp.goToSlide(3449,949);"],["cp.goToSlide(3972,);"]]}]}',
ofa:'{"scripts":[{"then":[["cp.jumpToNextSlide(3458);"]]}]}',
bph:[]
,
bookmarks:[]
,
qs:'Slide3410q0',
qnq:0,
pa:3080,
iph:{
3449:{
ts:'',
tr:''
}
,
3972:{
ts:'',
tr:''
}
,
3458:{
ts:'',
tr:''
}

}

},
Slide3410c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:3410,
dn:'Slide3410',
visible:'1'
},
Slide3410q0:{
noa:1024,
qt:'',
it:false,
is:false,
ipq:false,
ikc:true,
sat:true,
qst:3,
ish:false,
ips:false,
qnq:0,
sn:'Slide3410',
oid:'$$OBJECTIVE_ID',
iid:'3435',
sra:false,
w:0,
nw:0,
itp:'true-false',
qtp:'TrueFalse',
gn:'Slide3410_ag',
tl:60000,
sfrc:false,
frc:'',
ifc:[],
ofct:false,
ao:['si3495c:0','si3507c:1'],
qtc:'',
JSONTT_4:[],
JSONTT_5:[],
oic:'',
sic:false,
osc:'',
osct:false,
qmas:1,
amfitb:-1,
csfitb:false,
quizNumberingEnabled:false,
quizNumberingType:26,
ail:['si3495','si3507'],
cal:['si3495']
},
si1547:{
name:'Video_1',
type:1268,
from:691,
to:786,
rp:0,
rpa:0,
mdi:'si1547c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide1529',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1566',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1547c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1547,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1547',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1566:{
name:'SlideVideo_1',
type:365,
from:691,
to:786,
rp:0,
rpa:0,
mdi:'si1566c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3.2,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1547',
retainState:false,
immo:false,
apsn:'Slide1529',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si1566c:{
b:[-204,-188,1176,796],
fh:false,
fw:false,
uid:1566,
iso:false,
css:{
360:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1566',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/01562.png',
mp4:'vr/Vi1555.mp4',
vsf:0,
vst:3.2,
o:100,
vbwr:[-205,-189,1177,797],
vb:[-205,-189,1177,797]
},
Slide1529:{
lb:'Simulation slide 10',
id:1529,
from:3127,
to:3222,
iols:0,
i360qs:false,
sdu:3.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1529c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si1547',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1529c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1529,
dn:'Slide1529',
visible:'1'
},
sf_1615:{
from:1,
to:90,
siaf:0.03,
sid:2.97,
mdi:'sf_1615c',
apsn:'Slide1573',
type:64
},
sf_1615Ad:{
src:'ar/KeyClick.mp3',
from:1,
to:90,
du:2
},
sf_1615c:{
id:'sf_1615c',
b:[0,0,5,18],
l:162,
t:174,
dn:'sf_1615',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg',
pkt:1
},
sf_1623:{
from:6,
to:90,
siaf:0.2,
sid:2.8,
mdi:'sf_1623c',
apsn:'Slide1573',
type:64
},
sf_1623Ad:{
src:'ar/KeyClick.mp3',
from:6,
to:90,
du:2
},
sf_1623c:{
id:'sf_1623c',
b:[5,0,11,18],
l:166,
t:174,
dn:'sf_1623',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg',
pkt:1
},
sf_1631:{
from:10,
to:90,
siaf:0.33,
sid:2.67,
mdi:'sf_1631c',
apsn:'Slide1573',
type:64
},
sf_1631Ad:{
src:'ar/KeyClick.mp3',
from:10,
to:90,
du:2
},
sf_1631c:{
id:'sf_1631c',
b:[16,0,10,18],
l:176,
t:174,
dn:'sf_1631',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg',
pkt:1
},
sf_1639:{
from:15,
to:90,
siaf:0.5,
sid:2.5,
mdi:'sf_1639c',
apsn:'Slide1573',
type:64
},
sf_1639Ad:{
src:'ar/KeyClick.mp3',
from:15,
to:90,
du:2
},
sf_1639c:{
id:'sf_1639c',
b:[26,0,9,18],
l:185,
t:174,
dn:'sf_1639',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg',
pkt:1
},
sf_1645:{
from:17,
to:90,
siaf:0.57,
sid:2.43,
mdi:'sf_1645c',
apsn:'Slide1573',
type:64
},
sf_1645c:{
id:'sf_1645c',
b:[35,0,1,18],
l:193,
t:174,
dn:'sf_1645',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg'
},
sf_1651:{
from:19,
to:90,
siaf:0.63,
sid:2.37,
mdi:'sf_1651c',
apsn:'Slide1573',
type:64
},
sf_1651Ad:{
src:'ar/KeyClick.mp3',
from:19,
to:90,
du:2
},
sf_1651c:{
id:'sf_1651c',
b:[36,0,4,18],
l:194,
t:174,
dn:'sf_1651',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg',
pkt:1
},
sf_1657:{
from:22,
to:90,
siaf:0.73,
sid:2.27,
mdi:'sf_1657c',
apsn:'Slide1573',
type:64
},
sf_1657c:{
id:'sf_1657c',
b:[40,0,13,15],
l:1011,
t:4,
dn:'sf_1657',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg'
},
sf_1661:{
from:22,
to:90,
siaf:0.73,
sid:2.27,
mdi:'sf_1661c',
apsn:'Slide1573',
type:64
},
sf_1661c:{
id:'sf_1661c',
b:[53,0,64,12],
l:1024,
t:6,
dn:'sf_1661',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg'
},
sf_1665:{
from:22,
to:90,
siaf:0.73,
sid:2.27,
mdi:'sf_1665c',
apsn:'Slide1573',
type:64
},
sf_1665c:{
id:'sf_1665c',
b:[117,0,55,13],
l:1088,
t:5,
dn:'sf_1665',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg'
},
sf_1669:{
from:22,
to:90,
siaf:0.73,
sid:2.27,
mdi:'sf_1669c',
apsn:'Slide1573',
type:64
},
sf_1669c:{
id:'sf_1669c',
b:[172,0,14,14],
l:1195,
t:5,
dn:'sf_1669',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg'
},
sf_1675:{
from:24,
to:90,
siaf:0.8,
sid:2.2,
mdi:'sf_1675c',
apsn:'Slide1573',
type:64
},
sf_1675Ad:{
src:'ar/KeyClick.mp3',
from:24,
to:90,
du:2
},
sf_1675c:{
id:'sf_1675c',
b:[186,0,10,18],
l:197,
t:174,
dn:'sf_1675',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg',
pkt:1
},
sf_1683:{
from:28,
to:90,
siaf:0.93,
sid:2.07,
mdi:'sf_1683c',
apsn:'Slide1573',
type:64
},
sf_1683Ad:{
src:'ar/KeyClick.mp3',
from:28,
to:90,
du:2
},
sf_1683c:{
id:'sf_1683c',
b:[196,0,10,18],
l:206,
t:174,
dn:'sf_1683',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg',
pkt:1
},
sf_1691:{
from:33,
to:90,
siaf:1.1,
sid:1.9,
mdi:'sf_1691c',
apsn:'Slide1573',
type:64
},
sf_1691Ad:{
src:'ar/KeyClick.mp3',
from:33,
to:90,
du:1
},
sf_1691c:{
id:'sf_1691c',
b:[206,0,15,18],
l:215,
t:174,
dn:'sf_1691',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg',
pkt:1
},
sf_1699:{
from:37,
to:90,
siaf:1.23,
sid:1.77,
mdi:'sf_1699c',
apsn:'Slide1573',
type:64
},
sf_1699Ad:{
src:'ar/KeyClick.mp3',
from:37,
to:90,
du:1
},
sf_1699c:{
id:'sf_1699c',
b:[221,0,10,18],
l:229,
t:174,
dn:'sf_1699',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg',
pkt:1
},
sf_1707:{
from:42,
to:90,
siaf:1.4,
sid:1.6,
mdi:'sf_1707c',
apsn:'Slide1573',
type:64
},
sf_1707Ad:{
src:'ar/KeyClick.mp3',
from:42,
to:90,
du:1
},
sf_1707c:{
id:'sf_1707c',
b:[231,0,10,18],
l:238,
t:174,
dn:'sf_1707',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg',
pkt:1
},
sf_1715:{
from:46,
to:90,
siaf:1.53,
sid:1.47,
mdi:'sf_1715c',
apsn:'Slide1573',
type:64
},
sf_1715Ad:{
src:'ar/KeyClick.mp3',
from:46,
to:90,
du:1
},
sf_1715c:{
id:'sf_1715c',
b:[241,0,6,18],
l:247,
t:174,
dn:'sf_1715',
visible:1,
effectiveVi:1,
ip:'dr/sfs4.jpg',
pkt:1
},
si1599:{
name:'Simulation_10',
type:1268,
from:829,
to:876,
rp:0,
rpa:0,
mdi:'si1599c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1573',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1591',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1599c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1599,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1599',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1591:{
name:'Simulation_non_responsive_10',
type:1268,
from:829,
to:876,
rp:0,
rpa:0,
mdi:'si1591c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"object-typing-text":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1599',
retainState:false,
immo:false,
apsn:'Slide1573',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'sf_1615',
t:64
}
,{
n:'sf_1623',
t:64
}
,{
n:'sf_1631',
t:64
}
,{
n:'sf_1639',
t:64
}
,{
n:'sf_1645',
t:64
}
,{
n:'sf_1651',
t:64
}
,{
n:'sf_1657',
t:64
}
,{
n:'sf_1661',
t:64
}
,{
n:'sf_1665',
t:64
}
,{
n:'sf_1669',
t:64
}
,{
n:'sf_1675',
t:64
}
,{
n:'sf_1683',
t:64
}
,{
n:'sf_1691',
t:64
}
,{
n:'sf_1699',
t:64
}
,{
n:'sf_1707',
t:64
}
,{
n:'sf_1715',
t:64
}
,{
n:'si1717',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"object-typing-text":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1599',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1591c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1591,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1591',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:1607,
tsp:50,
ip:'dr/01607.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1717:{
name:'Mouse_10',
type:12,
from:829,
to:876,
rp:0,
rpa:0,
mdi:'si1717c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":611,"mouseStartPointY":229,"mouseEndPointX":459,"mouseEndPointY":196}}',
parentGroup:'si1591',
retainState:false,
immo:false,
apsn:'Slide1573',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si1717Ad',
trin:0,
trout:0,
isDD:false
},
si1717c:{
b:[455,192,472,215],
fh:false,
fw:false,
uid:1717,
iso:false,
css:{
360:{
l:'46.811%',
t:'31.579%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'46.811%',
lhID:-1,
lvEID:0,
lvV:'31.579%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'46.811%',
t:'31.579%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'46.811%',
lhID:-1,
lvEID:0,
lvV:'31.579%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'46.811%',
t:'31.579%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'46.811%',
lhID:-1,
lvEID:0,
lvV:'31.579%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1717',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[455,192,612,229],
vb:[455,192,612,229]
},
si1717Ad:{
src:'ar/Mouse.mp3',
from:829,
to:834,
del:2.818,
msa:1,
du:0.182
},
Slide1573:{
lb:'Simulation slide 11',
id:1573,
from:3223,
to:3312,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1573c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si1599',
t:1268
}
]
,
iph:[]
,
oa:'si1717Ad,sf_1615Ad,sf_1623Ad,sf_1631Ad,sf_1639Ad,sf_1651Ad,sf_1675Ad,sf_1683Ad,sf_1691Ad,sf_1699Ad,sf_1707Ad,sf_1715Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1573c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1573,
dn:'Slide1573',
visible:'1'
},
si1750:{
name:'Simulation_11',
type:1268,
from:877,
to:966,
rp:0,
rpa:0,
mdi:'si1750c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1724',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1742',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1750c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1750,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1750',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1742:{
name:'Simulation_non_responsive_11',
type:1268,
from:877,
to:966,
rp:0,
rpa:0,
mdi:'si1742c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1750',
retainState:false,
immo:false,
apsn:'Slide1724',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1761',
t:1269
}
,{
n:'si1781',
t:612
}
,{
n:'si1841',
t:612
}
,{
n:'si1851',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1750',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1742c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1742,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1742',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:1758,
tsp:50,
ip:'dr/01758.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1761:{
name:'Highlight_box_7',
type:1269,
from:877,
to:966,
rp:0,
rpa:0,
mdi:'si1761c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":170,"left":1010,"width":34,"height":20}}',
parentGroup:'si1742',
retainState:false,
immo:false,
apsn:'Slide1724',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si1771',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1761]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1761c:{
b:[1010,170,1044,190],
fh:false,
fw:false,
uid:1761,
iso:false,
css:{
360:{
l:'103.909%',
t:'27.961%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'103.909%',
lhID:-1,
lvEID:0,
lvV:'27.961%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'103.909%',
t:'27.961%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'103.909%',
lhID:-1,
lvEID:0,
lvV:'27.961%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'103.909%',
t:'27.961%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'103.909%',
lhID:-1,
lvEID:0,
lvV:'27.961%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1761',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[1010,170,1044,190],
vb:[1010,170,1044,190]
},
si1771:{
name:'Shape_7',
type:612,
from:877,
to:966,
rp:0,
rpa:0,
mdi:'si1771c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1724',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1771]
}
]
,
stis:0,
bstiid:1761,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1761',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1771c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1771,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1771',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1781:{
name:'Rectangle_7',
type:612,
from:877,
to:966,
rp:0,
rpa:0,
mdi:'si1781c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":230,"left":1025,"width":300,"height":"auto"}}',
parentGroup:'si1742',
retainState:false,
immo:false,
apsn:'Slide1724',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1792,
stt:0,
dsr:'Default_State',
stsi:[1781]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1781','si1794','si1805','si1816'],
isDD:false
},
si1781c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1781,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1781',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1794:{
name:'',
type:612,
from:877,
to:966,
rp:0,
rpa:0,
mdi:'si1794c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":230,"left":1025,"width":300,"height":"auto"}}',
parentGroup:'si1742',
retainState:false,
immo:false,
apsn:'Slide1724',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1781',
stl:[{
stn:'Normal',
stt:0,
stsi:[1794]
}
]
,
stis:0,
bstiid:1781,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1781,
isDD:false
},
si1794c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1794,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1794',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1805:{
name:'',
type:612,
from:877,
to:966,
rp:0,
rpa:0,
mdi:'si1805c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":230,"left":1025,"width":300,"height":"auto"}}',
parentGroup:'si1742',
retainState:false,
immo:false,
apsn:'Slide1724',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1781',
stl:[{
stn:'Normal',
stt:0,
stsi:[1805]
}
]
,
stis:0,
bstiid:1781,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1781,
isDD:false
},
si1805c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1805,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1805',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1816:{
name:'',
type:612,
from:877,
to:966,
rp:0,
rpa:0,
mdi:'si1816c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":230,"left":1025,"width":300,"height":"auto"}}',
parentGroup:'si1742',
retainState:false,
immo:false,
apsn:'Slide1724',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1781',
stl:[{
stn:'Normal',
stt:0,
stsi:[1816]
}
]
,
stis:0,
bstiid:1781,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1781,
isDD:false
},
si1816c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1816,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1816',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1841:{
name:'Instructions_7',
type:612,
from:877,
to:966,
rp:0,
rpa:0,
mdi:'si1841c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":200,"left":1017,"width":320}}',
parentGroup:'si1742',
retainState:false,
immo:false,
apsn:'Slide1724',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1841]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si1841c:{
b:[1017,200,1337,300],
fh:false,
fw:false,
uid:1841,
iso:false,
css:{
360:{
l:'104.630%',
t:'32.895%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'104.630%',
lhID:-1,
lvEID:0,
lvV:'32.895%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'104.630%',
t:'32.895%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'104.630%',
lhID:-1,
lvEID:0,
lvV:'32.895%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'104.630%',
t:'32.895%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'104.630%',
lhID:-1,
lvEID:0,
lvV:'32.895%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1841',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,1339,302],
vb:[-2,-2,1339,302]
},
si1851:{
name:'Mouse_11',
type:12,
from:883,
to:966,
rp:0,
rpa:0,
mdi:'si1851c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0.2,
sid:2.8,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":467,"mouseStartPointY":204,"mouseEndPointX":1027,"mouseEndPointY":180}}',
parentGroup:'si1742',
retainState:false,
immo:false,
apsn:'Slide1724',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si1851Ad',
trin:0,
trout:0,
isDD:false
},
si1851c:{
b:[1014,172,1046,204],
fh:false,
fw:false,
uid:1851,
iso:false,
css:{
360:{
l:'104.321%',
t:'28.289%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'104.321%',
lhID:-1,
lvEID:0,
lvV:'28.289%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'104.321%',
t:'28.289%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'104.321%',
lhID:-1,
lvEID:0,
lvV:'28.289%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'104.321%',
t:'28.289%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'104.321%',
lhID:-1,
lvEID:0,
lvV:'28.289%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1851',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[467,172,1046,204],
vb:[467,172,1046,204]
},
si1851Ad:{
src:'ar/Mouse.mp3',
from:883,
to:888,
del:2.818,
msa:1,
du:0.182
},
Slide1724:{
lb:'Simulation slide 12',
id:1724,
from:3313,
to:3402,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1724c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si1750',
t:1268
}
]
,
iph:[]
,
oa:'si1851Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1724c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1724,
dn:'Slide1724',
visible:'1'
},
si1884:{
name:'Simulation_12',
type:1268,
from:967,
to:996,
rp:0,
rpa:0,
mdi:'si1884c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1858',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1876',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1884c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1884,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1884',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1876:{
name:'Simulation_non_responsive_12',
type:1268,
from:967,
to:996,
rp:0,
rpa:0,
mdi:'si1876c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1884',
retainState:false,
immo:false,
apsn:'Slide1858',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1895',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1884',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1876c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1876,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1876',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:1892,
tsp:50,
ip:'dr/01892.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1895:{
name:'Mouse_12',
type:12,
from:967,
to:996,
rp:0,
rpa:0,
mdi:'si1895c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":1026,"mouseStartPointY":184,"mouseEndPointX":1152,"mouseEndPointY":177}}',
parentGroup:'si1876',
retainState:false,
immo:false,
apsn:'Slide1858',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si1895Ad',
trin:0,
trout:0,
isDD:false
},
si1895c:{
b:[1139,169,1171,201],
fh:false,
fw:false,
uid:1895,
iso:false,
css:{
360:{
l:'117.181%',
t:'27.796%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.181%',
lhID:-1,
lvEID:0,
lvV:'27.796%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'117.181%',
t:'27.796%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.181%',
lhID:-1,
lvEID:0,
lvV:'27.796%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'117.181%',
t:'27.796%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.181%',
lhID:-1,
lvEID:0,
lvV:'27.796%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1895',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[1026,169,1171,201],
vb:[1026,169,1171,201]
},
si1895Ad:{
src:'ar/Mouse.mp3',
from:967,
to:972,
del:0.818,
msa:1,
du:0.182
},
Slide1858:{
lb:'Simulation slide 13',
id:1858,
from:3403,
to:3432,
iols:0,
i360qs:false,
sdu:1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1858c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si1884',
t:1268
}
]
,
iph:[]
,
oa:'si1895Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1858c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1858,
dn:'Slide1858',
visible:'1'
},
si1928:{
name:'Simulation_13',
type:1268,
from:997,
to:1086,
rp:0,
rpa:0,
mdi:'si1928c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1902',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1920',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1928c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1928,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1928',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1920:{
name:'Simulation_non_responsive_13',
type:1268,
from:997,
to:1086,
rp:0,
rpa:0,
mdi:'si1920c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si1928',
retainState:false,
immo:false,
apsn:'Slide1902',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1939',
t:1269
}
,{
n:'si1959',
t:612
}
,{
n:'si2019',
t:612
}
,{
n:'si2029',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1928',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1920c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1920,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1920',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:1936,
tsp:50,
ip:'dr/01936.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1939:{
name:'Highlight_box_8',
type:1269,
from:997,
to:1086,
rp:0,
rpa:0,
mdi:'si1939c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":59,"left":1139,"width":34,"height":20}}',
parentGroup:'si1920',
retainState:false,
immo:false,
apsn:'Slide1902',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si1949',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1939]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1939c:{
b:[1139,59,1173,79],
fh:false,
fw:false,
uid:1939,
iso:false,
css:{
360:{
l:'117.181%',
t:'9.704%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.181%',
lhID:-1,
lvEID:0,
lvV:'9.704%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'117.181%',
t:'9.704%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.181%',
lhID:-1,
lvEID:0,
lvV:'9.704%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'117.181%',
t:'9.704%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.181%',
lhID:-1,
lvEID:0,
lvV:'9.704%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1939',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[1139,59,1173,79],
vb:[1139,59,1173,79]
},
si1949:{
name:'Shape_8',
type:612,
from:997,
to:1086,
rp:0,
rpa:0,
mdi:'si1949c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1902',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1949]
}
]
,
stis:0,
bstiid:1939,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1939',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1949c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1949,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1949',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1959:{
name:'Rectangle_8',
type:612,
from:997,
to:1086,
rp:0,
rpa:0,
mdi:'si1959c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":119,"left":824,"width":300,"height":"auto"}}',
parentGroup:'si1920',
retainState:false,
immo:false,
apsn:'Slide1902',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1970,
stt:0,
dsr:'Default_State',
stsi:[1959]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1959','si1972','si1983','si1994'],
isDD:false
},
si1959c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1959,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1959',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1972:{
name:'',
type:612,
from:997,
to:1086,
rp:0,
rpa:0,
mdi:'si1972c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":119,"left":824,"width":300,"height":"auto"}}',
parentGroup:'si1920',
retainState:false,
immo:false,
apsn:'Slide1902',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1959',
stl:[{
stn:'Normal',
stt:0,
stsi:[1972]
}
]
,
stis:0,
bstiid:1959,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1959,
isDD:false
},
si1972c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1972,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1972',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1983:{
name:'',
type:612,
from:997,
to:1086,
rp:0,
rpa:0,
mdi:'si1983c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":119,"left":824,"width":300,"height":"auto"}}',
parentGroup:'si1920',
retainState:false,
immo:false,
apsn:'Slide1902',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1959',
stl:[{
stn:'Normal',
stt:0,
stsi:[1983]
}
]
,
stis:0,
bstiid:1959,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1959,
isDD:false
},
si1983c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1983,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1983',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1994:{
name:'',
type:612,
from:997,
to:1086,
rp:0,
rpa:0,
mdi:'si1994c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":119,"left":824,"width":300,"height":"auto"}}',
parentGroup:'si1920',
retainState:false,
immo:false,
apsn:'Slide1902',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1959',
stl:[{
stn:'Normal',
stt:0,
stsi:[1994]
}
]
,
stis:0,
bstiid:1959,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1959,
isDD:false
},
si1994c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1994,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1994',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2019:{
name:'Instructions_8',
type:612,
from:997,
to:1086,
rp:0,
rpa:0,
mdi:'si2019c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":89,"left":1060,"width":320}}',
parentGroup:'si1920',
retainState:false,
immo:false,
apsn:'Slide1902',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2019]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2019c:{
b:[1146,89,1466,189],
fh:false,
fw:false,
uid:2019,
iso:false,
css:{
360:{
l:'117.901%',
t:'14.638%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.901%',
lhID:-1,
lvEID:0,
lvV:'14.638%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'117.901%',
t:'14.638%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.901%',
lhID:-1,
lvEID:0,
lvV:'14.638%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'117.901%',
t:'14.638%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.901%',
lhID:-1,
lvEID:0,
lvV:'14.638%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2019',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,1468,191],
vb:[-2,-2,1468,191]
},
si2029:{
name:'Mouse_13',
type:12,
from:1039,
to:1086,
rp:0,
rpa:0,
mdi:'si2029c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":1151,"mouseStartPointY":181,"mouseEndPointX":1156,"mouseEndPointY":69}}',
parentGroup:'si1920',
retainState:false,
immo:false,
apsn:'Slide1902',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2029Ad',
trin:0,
trout:0,
isDD:false
},
si2029c:{
b:[1143,61,1175,93],
fh:false,
fw:false,
uid:2029,
iso:false,
css:{
360:{
l:'117.593%',
t:'10.033%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.593%',
lhID:-1,
lvEID:0,
lvV:'10.033%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'117.593%',
t:'10.033%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.593%',
lhID:-1,
lvEID:0,
lvV:'10.033%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'117.593%',
t:'10.033%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'117.593%',
lhID:-1,
lvEID:0,
lvV:'10.033%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2029',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[1143,61,1175,182],
vb:[1143,61,1175,182]
},
si2029Ad:{
src:'ar/Mouse.mp3',
from:1039,
to:1044,
del:2.818,
msa:1,
du:0.182
},
Slide1902:{
lb:'Simulation slide 14',
id:1902,
from:3433,
to:3522,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1902c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si1928',
t:1268
}
]
,
iph:[]
,
oa:'si2029Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1902c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1902,
dn:'Slide1902',
visible:'1'
},
si2062:{
name:'Simulation_14',
type:1268,
from:1087,
to:1176,
rp:0,
rpa:0,
mdi:'si2062c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2036',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2054',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2062c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2062,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2062',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2054:{
name:'Simulation_non_responsive_14',
type:1268,
from:1087,
to:1176,
rp:0,
rpa:0,
mdi:'si2054c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si2062',
retainState:false,
immo:false,
apsn:'Slide2036',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2073',
t:1269
}
,{
n:'si2093',
t:612
}
,{
n:'si2153',
t:612
}
,{
n:'si2163',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2062',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2054c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2054,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2054',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:2070,
tsp:50,
ip:'dr/02070.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2073:{
name:'Highlight_box_9',
type:1269,
from:1087,
to:1176,
rp:0,
rpa:0,
mdi:'si2073c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":608,"left":883,"width":34,"height":20}}',
parentGroup:'si2054',
retainState:false,
immo:false,
apsn:'Slide2036',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si2083',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2073]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2073c:{
b:[883,608,917,628],
fh:false,
fw:false,
uid:2073,
iso:false,
css:{
360:{
l:'90.844%',
t:'100.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'90.844%',
lhID:-1,
lvEID:0,
lvV:'100.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'90.844%',
t:'100.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'90.844%',
lhID:-1,
lvEID:0,
lvV:'100.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'90.844%',
t:'100.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'90.844%',
lhID:-1,
lvEID:0,
lvV:'100.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2073',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[883,608,917,628],
vb:[883,608,917,628]
},
si2083:{
name:'Shape_9',
type:612,
from:1087,
to:1176,
rp:0,
rpa:0,
mdi:'si2083c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2036',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2083]
}
]
,
stis:0,
bstiid:2073,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2073',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2083c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2083,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2083',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2093:{
name:'Rectangle_9',
type:612,
from:1087,
to:1176,
rp:0,
rpa:0,
mdi:'si2093c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":668,"left":898,"width":300,"height":"auto"}}',
parentGroup:'si2054',
retainState:false,
immo:false,
apsn:'Slide2036',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2104,
stt:0,
dsr:'Default_State',
stsi:[2093]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2093','si2106','si2117','si2128'],
isDD:false
},
si2093c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2093,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2093',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2106:{
name:'',
type:612,
from:1087,
to:1176,
rp:0,
rpa:0,
mdi:'si2106c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":668,"left":898,"width":300,"height":"auto"}}',
parentGroup:'si2054',
retainState:false,
immo:false,
apsn:'Slide2036',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2093',
stl:[{
stn:'Normal',
stt:0,
stsi:[2106]
}
]
,
stis:0,
bstiid:2093,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2093,
isDD:false
},
si2106c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2106,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2106',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2117:{
name:'',
type:612,
from:1087,
to:1176,
rp:0,
rpa:0,
mdi:'si2117c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":668,"left":898,"width":300,"height":"auto"}}',
parentGroup:'si2054',
retainState:false,
immo:false,
apsn:'Slide2036',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2093',
stl:[{
stn:'Normal',
stt:0,
stsi:[2117]
}
]
,
stis:0,
bstiid:2093,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2093,
isDD:false
},
si2117c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2117,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2117',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2128:{
name:'',
type:612,
from:1087,
to:1176,
rp:0,
rpa:0,
mdi:'si2128c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":668,"left":898,"width":300,"height":"auto"}}',
parentGroup:'si2054',
retainState:false,
immo:false,
apsn:'Slide2036',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2093',
stl:[{
stn:'Normal',
stt:0,
stsi:[2128]
}
]
,
stis:0,
bstiid:2093,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2093,
isDD:false
},
si2128c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2128,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2128',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2153:{
name:'Instructions_9',
type:612,
from:1087,
to:1176,
rp:0,
rpa:0,
mdi:'si2153c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":638,"left":890,"width":320}}',
parentGroup:'si2054',
retainState:false,
immo:false,
apsn:'Slide2036',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2153]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2153c:{
b:[890,638,1210,738],
fh:false,
fw:false,
uid:2153,
iso:false,
css:{
360:{
l:'91.564%',
t:'104.934%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'91.564%',
lhID:-1,
lvEID:0,
lvV:'104.934%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'91.564%',
t:'104.934%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'91.564%',
lhID:-1,
lvEID:0,
lvV:'104.934%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'91.564%',
t:'104.934%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'91.564%',
lhID:-1,
lvEID:0,
lvV:'104.934%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2153',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,1212,740],
vb:[-2,-2,1212,740]
},
si2163:{
name:'Mouse_14',
type:12,
from:1087,
to:1176,
rp:0,
rpa:0,
mdi:'si2163c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":1154,"mouseStartPointY":73,"mouseEndPointX":900,"mouseEndPointY":618}}',
parentGroup:'si2054',
retainState:false,
immo:false,
apsn:'Slide2036',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2163Ad',
trin:0,
trout:0,
isDD:false
},
si2163c:{
b:[887,610,919,642],
fh:false,
fw:false,
uid:2163,
iso:false,
css:{
360:{
l:'91.255%',
t:'100.329%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'91.255%',
lhID:-1,
lvEID:0,
lvV:'100.329%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'91.255%',
t:'100.329%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'91.255%',
lhID:-1,
lvEID:0,
lvV:'100.329%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'91.255%',
t:'100.329%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'91.255%',
lhID:-1,
lvEID:0,
lvV:'100.329%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2163',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[887,73,1155,642],
vb:[887,73,1155,642]
},
si2163Ad:{
src:'ar/Mouse.mp3',
from:1087,
to:1092,
del:2.818,
msa:1,
du:0.182
},
Slide2036:{
lb:'Simulation slide 15',
id:2036,
from:3523,
to:3612,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2036c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si2062',
t:1268
}
]
,
iph:[]
,
oa:'si2163Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2036c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2036,
dn:'Slide2036',
visible:'1'
},
si2196:{
name:'Simulation_15',
type:1268,
from:1177,
to:1266,
rp:0,
rpa:0,
mdi:'si2196c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2170',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2188',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2196c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2196,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2196',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2188:{
name:'Simulation_non_responsive_15',
type:1268,
from:1177,
to:1266,
rp:0,
rpa:0,
mdi:'si2188c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si2196',
retainState:false,
immo:false,
apsn:'Slide2170',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2207',
t:1269
}
,{
n:'si2227',
t:612
}
,{
n:'si2287',
t:612
}
,{
n:'si2297',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2196',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2188c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2188,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2188',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:2204,
tsp:50,
ip:'dr/02204.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2207:{
name:'Highlight_box_10',
type:1269,
from:1177,
to:1266,
rp:0,
rpa:0,
mdi:'si2207c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":191,"left":482,"width":34,"height":20}}',
parentGroup:'si2188',
retainState:false,
immo:false,
apsn:'Slide2170',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si2217',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2207]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2207c:{
b:[482,191,516,211],
fh:false,
fw:false,
uid:2207,
iso:false,
css:{
360:{
l:'49.588%',
t:'31.414%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.588%',
lhID:-1,
lvEID:0,
lvV:'31.414%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'49.588%',
t:'31.414%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.588%',
lhID:-1,
lvEID:0,
lvV:'31.414%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'49.588%',
t:'31.414%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.588%',
lhID:-1,
lvEID:0,
lvV:'31.414%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2207',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[482,191,516,211],
vb:[482,191,516,211]
},
si2217:{
name:'Shape_10',
type:612,
from:1177,
to:1266,
rp:0,
rpa:0,
mdi:'si2217c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2170',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2217]
}
]
,
stis:0,
bstiid:2207,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2207',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2217c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2217,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2217',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2227:{
name:'Rectangle_10',
type:612,
from:1177,
to:1266,
rp:0,
rpa:0,
mdi:'si2227c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":251,"left":497,"width":300,"height":"auto"}}',
parentGroup:'si2188',
retainState:false,
immo:false,
apsn:'Slide2170',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2238,
stt:0,
dsr:'Default_State',
stsi:[2227]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2227','si2240','si2251','si2262'],
isDD:false
},
si2227c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2227,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2227',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2240:{
name:'',
type:612,
from:1177,
to:1266,
rp:0,
rpa:0,
mdi:'si2240c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":251,"left":497,"width":300,"height":"auto"}}',
parentGroup:'si2188',
retainState:false,
immo:false,
apsn:'Slide2170',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2227',
stl:[{
stn:'Normal',
stt:0,
stsi:[2240]
}
]
,
stis:0,
bstiid:2227,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2227,
isDD:false
},
si2240c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2240,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2240',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2251:{
name:'',
type:612,
from:1177,
to:1266,
rp:0,
rpa:0,
mdi:'si2251c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":251,"left":497,"width":300,"height":"auto"}}',
parentGroup:'si2188',
retainState:false,
immo:false,
apsn:'Slide2170',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2227',
stl:[{
stn:'Normal',
stt:0,
stsi:[2251]
}
]
,
stis:0,
bstiid:2227,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2227,
isDD:false
},
si2251c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2251,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2251',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2262:{
name:'',
type:612,
from:1177,
to:1266,
rp:0,
rpa:0,
mdi:'si2262c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":251,"left":497,"width":300,"height":"auto"}}',
parentGroup:'si2188',
retainState:false,
immo:false,
apsn:'Slide2170',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2227',
stl:[{
stn:'Normal',
stt:0,
stsi:[2262]
}
]
,
stis:0,
bstiid:2227,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2227,
isDD:false
},
si2262c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2262,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2262',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2287:{
name:'Instructions_10',
type:612,
from:1177,
to:1266,
rp:0,
rpa:0,
mdi:'si2287c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":221,"left":489,"width":320}}',
parentGroup:'si2188',
retainState:false,
immo:false,
apsn:'Slide2170',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2287]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2287c:{
b:[489,221,809,321],
fh:false,
fw:false,
uid:2287,
iso:false,
css:{
360:{
l:'50.309%',
t:'36.349%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.309%',
lhID:-1,
lvEID:0,
lvV:'36.349%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'50.309%',
t:'36.349%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.309%',
lhID:-1,
lvEID:0,
lvV:'36.349%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'50.309%',
t:'36.349%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.309%',
lhID:-1,
lvEID:0,
lvV:'36.349%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2287',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,811,323],
vb:[-2,-2,811,323]
},
si2297:{
name:'Mouse_15',
type:12,
from:1180,
to:1266,
rp:0,
rpa:0,
mdi:'si2297c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0.1,
sid:2.9,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":899,"mouseStartPointY":622,"mouseEndPointX":499,"mouseEndPointY":201}}',
parentGroup:'si2188',
retainState:false,
immo:false,
apsn:'Slide2170',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2297Ad',
trin:0,
trout:0,
isDD:false
},
si2297c:{
b:[486,193,518,225],
fh:false,
fw:false,
uid:2297,
iso:false,
css:{
360:{
l:'50.000%',
t:'31.743%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.000%',
lhID:-1,
lvEID:0,
lvV:'31.743%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'50.000%',
t:'31.743%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.000%',
lhID:-1,
lvEID:0,
lvV:'31.743%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'50.000%',
t:'31.743%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'50.000%',
lhID:-1,
lvEID:0,
lvV:'31.743%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2297',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[486,193,900,622],
vb:[486,193,900,622]
},
si2297Ad:{
src:'ar/Mouse.mp3',
from:1180,
to:1185,
del:2.818,
msa:1,
du:0.182
},
Slide2170:{
lb:'Simulation slide 16',
id:2170,
from:3613,
to:3702,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2170c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si2196',
t:1268
}
]
,
iph:[]
,
oa:'si2297Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2170c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2170,
dn:'Slide2170',
visible:'1'
},
si2330:{
name:'Simulation_16',
type:1268,
from:1267,
to:1356,
rp:0,
rpa:0,
mdi:'si2330c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2304',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2322',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2330c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2330,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2330',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2322:{
name:'Simulation_non_responsive_16',
type:1268,
from:1267,
to:1356,
rp:0,
rpa:0,
mdi:'si2322c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si2330',
retainState:false,
immo:false,
apsn:'Slide2304',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2341',
t:1269
}
,{
n:'si2361',
t:612
}
,{
n:'si2421',
t:612
}
,{
n:'si2431',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2330',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2322c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2322,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2322',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:2338,
tsp:50,
ip:'dr/02338.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2341:{
name:'Highlight_box_11',
type:1269,
from:1267,
to:1356,
rp:0,
rpa:0,
mdi:'si2341c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":498,"left":477,"width":34,"height":20}}',
parentGroup:'si2322',
retainState:false,
immo:false,
apsn:'Slide2304',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si2351',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2341]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2341c:{
b:[477,498,511,518],
fh:false,
fw:false,
uid:2341,
iso:false,
css:{
360:{
l:'49.074%',
t:'81.908%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.074%',
lhID:-1,
lvEID:0,
lvV:'81.908%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'49.074%',
t:'81.908%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.074%',
lhID:-1,
lvEID:0,
lvV:'81.908%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'49.074%',
t:'81.908%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.074%',
lhID:-1,
lvEID:0,
lvV:'81.908%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2341',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[477,498,511,518],
vb:[477,498,511,518]
},
si2351:{
name:'Shape_11',
type:612,
from:1267,
to:1356,
rp:0,
rpa:0,
mdi:'si2351c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2304',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2351]
}
]
,
stis:0,
bstiid:2341,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2341',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2351c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2351,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2351',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2361:{
name:'Rectangle_11',
type:612,
from:1267,
to:1356,
rp:0,
rpa:0,
mdi:'si2361c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":558,"left":492,"width":300,"height":"auto"}}',
parentGroup:'si2322',
retainState:false,
immo:false,
apsn:'Slide2304',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2372,
stt:0,
dsr:'Default_State',
stsi:[2361]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2361','si2374','si2385','si2396'],
isDD:false
},
si2361c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2361,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2361',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2374:{
name:'',
type:612,
from:1267,
to:1356,
rp:0,
rpa:0,
mdi:'si2374c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":558,"left":492,"width":300,"height":"auto"}}',
parentGroup:'si2322',
retainState:false,
immo:false,
apsn:'Slide2304',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2361',
stl:[{
stn:'Normal',
stt:0,
stsi:[2374]
}
]
,
stis:0,
bstiid:2361,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2361,
isDD:false
},
si2374c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2374,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2374',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2385:{
name:'',
type:612,
from:1267,
to:1356,
rp:0,
rpa:0,
mdi:'si2385c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":558,"left":492,"width":300,"height":"auto"}}',
parentGroup:'si2322',
retainState:false,
immo:false,
apsn:'Slide2304',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2361',
stl:[{
stn:'Normal',
stt:0,
stsi:[2385]
}
]
,
stis:0,
bstiid:2361,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2361,
isDD:false
},
si2385c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2385,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2385',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2396:{
name:'',
type:612,
from:1267,
to:1356,
rp:0,
rpa:0,
mdi:'si2396c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":558,"left":492,"width":300,"height":"auto"}}',
parentGroup:'si2322',
retainState:false,
immo:false,
apsn:'Slide2304',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2361',
stl:[{
stn:'Normal',
stt:0,
stsi:[2396]
}
]
,
stis:0,
bstiid:2361,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2361,
isDD:false
},
si2396c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2396,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2396',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2421:{
name:'Instructions_11',
type:612,
from:1267,
to:1356,
rp:0,
rpa:0,
mdi:'si2421c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":528,"left":484,"width":320}}',
parentGroup:'si2322',
retainState:false,
immo:false,
apsn:'Slide2304',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2421]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2421c:{
b:[484,528,804,628],
fh:false,
fw:false,
uid:2421,
iso:false,
css:{
360:{
l:'49.794%',
t:'86.842%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.794%',
lhID:-1,
lvEID:0,
lvV:'86.842%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'49.794%',
t:'86.842%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.794%',
lhID:-1,
lvEID:0,
lvV:'86.842%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'49.794%',
t:'86.842%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.794%',
lhID:-1,
lvEID:0,
lvV:'86.842%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2421',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,806,630],
vb:[-2,-2,806,630]
},
si2431:{
name:'Mouse_16',
type:12,
from:1309,
to:1356,
rp:0,
rpa:0,
mdi:'si2431c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":498,"mouseStartPointY":204,"mouseEndPointX":494,"mouseEndPointY":508}}',
parentGroup:'si2322',
retainState:false,
immo:false,
apsn:'Slide2304',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2431Ad',
trin:0,
trout:0,
isDD:false
},
si2431c:{
b:[481,500,513,532],
fh:false,
fw:false,
uid:2431,
iso:false,
css:{
360:{
l:'49.486%',
t:'82.237%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.486%',
lhID:-1,
lvEID:0,
lvV:'82.237%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'49.486%',
t:'82.237%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.486%',
lhID:-1,
lvEID:0,
lvV:'82.237%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'49.486%',
t:'82.237%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'49.486%',
lhID:-1,
lvEID:0,
lvV:'82.237%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2431',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[481,204,513,532],
vb:[481,204,513,532]
},
si2431Ad:{
src:'ar/Mouse.mp3',
from:1309,
to:1314,
del:2.818,
msa:1,
du:0.182
},
Slide2304:{
lb:'Simulation slide 17',
id:2304,
from:3703,
to:3792,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2304c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si2330',
t:1268
}
]
,
iph:[]
,
oa:'si2431Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2304c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2304,
dn:'Slide2304',
visible:'1'
},
si2464:{
name:'Simulation_17',
type:1268,
from:1357,
to:1446,
rp:0,
rpa:0,
mdi:'si2464c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2438',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2456',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2464c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2464,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2464',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2456:{
name:'Simulation_non_responsive_17',
type:1268,
from:1357,
to:1446,
rp:0,
rpa:0,
mdi:'si2456c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si2464',
retainState:false,
immo:false,
apsn:'Slide2438',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2475',
t:1269
}
,{
n:'si2495',
t:612
}
,{
n:'si2555',
t:612
}
,{
n:'si2565',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2464',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2456c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2456,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2456',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:2472,
tsp:50,
ip:'dr/02472.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2475:{
name:'Highlight_box_12',
type:1269,
from:1357,
to:1446,
rp:0,
rpa:0,
mdi:'si2475c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":498,"left":638,"width":34,"height":20}}',
parentGroup:'si2456',
retainState:false,
immo:false,
apsn:'Slide2438',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si2485',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2475]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2475c:{
b:[638,498,672,518],
fh:false,
fw:false,
uid:2475,
iso:false,
css:{
360:{
l:'65.638%',
t:'81.908%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'65.638%',
lhID:-1,
lvEID:0,
lvV:'81.908%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'65.638%',
t:'81.908%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'65.638%',
lhID:-1,
lvEID:0,
lvV:'81.908%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'65.638%',
t:'81.908%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'65.638%',
lhID:-1,
lvEID:0,
lvV:'81.908%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2475',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[638,498,672,518],
vb:[638,498,672,518]
},
si2485:{
name:'Shape_12',
type:612,
from:1357,
to:1446,
rp:0,
rpa:0,
mdi:'si2485c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2438',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2485]
}
]
,
stis:0,
bstiid:2475,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2475',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2485c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2485,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2485',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2495:{
name:'Rectangle_12',
type:612,
from:1357,
to:1446,
rp:0,
rpa:0,
mdi:'si2495c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":558,"left":653,"width":300,"height":"auto"}}',
parentGroup:'si2456',
retainState:false,
immo:false,
apsn:'Slide2438',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2506,
stt:0,
dsr:'Default_State',
stsi:[2495]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2495','si2508','si2519','si2530'],
isDD:false
},
si2495c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2495,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2495',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2508:{
name:'',
type:612,
from:1357,
to:1446,
rp:0,
rpa:0,
mdi:'si2508c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":558,"left":653,"width":300,"height":"auto"}}',
parentGroup:'si2456',
retainState:false,
immo:false,
apsn:'Slide2438',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2495',
stl:[{
stn:'Normal',
stt:0,
stsi:[2508]
}
]
,
stis:0,
bstiid:2495,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2495,
isDD:false
},
si2508c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2508,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2508',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2519:{
name:'',
type:612,
from:1357,
to:1446,
rp:0,
rpa:0,
mdi:'si2519c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":558,"left":653,"width":300,"height":"auto"}}',
parentGroup:'si2456',
retainState:false,
immo:false,
apsn:'Slide2438',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2495',
stl:[{
stn:'Normal',
stt:0,
stsi:[2519]
}
]
,
stis:0,
bstiid:2495,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2495,
isDD:false
},
si2519c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2519,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2519',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2530:{
name:'',
type:612,
from:1357,
to:1446,
rp:0,
rpa:0,
mdi:'si2530c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":558,"left":653,"width":300,"height":"auto"}}',
parentGroup:'si2456',
retainState:false,
immo:false,
apsn:'Slide2438',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2495',
stl:[{
stn:'Normal',
stt:0,
stsi:[2530]
}
]
,
stis:0,
bstiid:2495,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2495,
isDD:false
},
si2530c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2530,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2530',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2555:{
name:'Instructions_12',
type:612,
from:1357,
to:1446,
rp:0,
rpa:0,
mdi:'si2555c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":528,"left":645,"width":320}}',
parentGroup:'si2456',
retainState:false,
immo:false,
apsn:'Slide2438',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2555]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2555c:{
b:[645,528,965,628],
fh:false,
fw:false,
uid:2555,
iso:false,
css:{
360:{
l:'66.358%',
t:'86.842%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.358%',
lhID:-1,
lvEID:0,
lvV:'86.842%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'66.358%',
t:'86.842%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.358%',
lhID:-1,
lvEID:0,
lvV:'86.842%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'66.358%',
t:'86.842%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.358%',
lhID:-1,
lvEID:0,
lvV:'86.842%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2555',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,967,630],
vb:[-2,-2,967,630]
},
si2565:{
name:'Mouse_17',
type:12,
from:1399,
to:1446,
rp:0,
rpa:0,
mdi:'si2565c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":493,"mouseStartPointY":511,"mouseEndPointX":655,"mouseEndPointY":508}}',
parentGroup:'si2456',
retainState:false,
immo:false,
apsn:'Slide2438',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2565Ad',
trin:0,
trout:0,
isDD:false
},
si2565c:{
b:[651,499,660,517],
fh:false,
fw:false,
uid:2565,
iso:false,
css:{
360:{
l:'66.975%',
t:'82.072%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.975%',
lhID:-1,
lvEID:0,
lvV:'82.072%',
lvID:-1,
w:'9px',
h:'18px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'66.975%',
t:'82.072%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.975%',
lhID:-1,
lvEID:0,
lvV:'82.072%',
lvID:-1,
w:'9px',
h:'18px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'66.975%',
t:'82.072%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.975%',
lhID:-1,
lvEID:0,
lvV:'82.072%',
lvID:-1,
w:'9px',
h:'18px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2565',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[493,499,660,517],
vb:[493,499,660,517]
},
si2565Ad:{
src:'ar/Mouse.mp3',
from:1399,
to:1404,
del:2.818,
msa:1,
du:0.182
},
Slide2438:{
lb:'Simulation slide 18',
id:2438,
from:3793,
to:3882,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2438c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si2464',
t:1268
}
]
,
iph:[]
,
oa:'si2565Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2438c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2438,
dn:'Slide2438',
visible:'1'
},
sf_2614:{
from:1,
to:90,
siaf:0.03,
sid:2.97,
mdi:'sf_2614c',
apsn:'Slide2572',
type:64
},
sf_2614Ad:{
src:'ar/KeyClick.mp3',
from:1,
to:90,
du:2
},
sf_2614c:{
id:'sf_2614c',
b:[0,0,12,9],
l:585,
t:503,
dn:'sf_2614',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg',
pkt:1
},
sf_2618:{
from:1,
to:90,
siaf:0.03,
sid:2.97,
mdi:'sf_2618c',
apsn:'Slide2572',
type:64
},
sf_2618c:{
id:'sf_2618c',
b:[12,0,12,10],
l:585,
t:512,
dn:'sf_2618',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2622:{
from:1,
to:90,
siaf:0.03,
sid:2.97,
mdi:'sf_2622c',
apsn:'Slide2572',
type:64
},
sf_2622c:{
id:'sf_2622c',
b:[24,0,6,10],
l:712,
t:541,
dn:'sf_2622',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2626:{
from:1,
to:90,
siaf:0.03,
sid:2.97,
mdi:'sf_2626c',
apsn:'Slide2572',
type:64
},
sf_2626c:{
id:'sf_2626c',
b:[30,0,27,12],
l:748,
t:581,
dn:'sf_2626',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2634:{
from:6,
to:90,
siaf:0.2,
sid:2.8,
mdi:'sf_2634c',
apsn:'Slide2572',
type:64
},
sf_2634Ad:{
src:'ar/KeyClick.mp3',
from:6,
to:90,
du:2
},
sf_2634c:{
id:'sf_2634c',
b:[57,0,10,9],
l:596,
t:503,
dn:'sf_2634',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg',
pkt:1
},
sf_2638:{
from:6,
to:90,
siaf:0.2,
sid:2.8,
mdi:'sf_2638c',
apsn:'Slide2572',
type:64
},
sf_2638c:{
id:'sf_2638c',
b:[67,0,10,10],
l:596,
t:512,
dn:'sf_2638',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2642:{
from:6,
to:90,
siaf:0.2,
sid:2.8,
mdi:'sf_2642c',
apsn:'Slide2572',
type:64
},
sf_2642c:{
id:'sf_2642c',
b:[77,0,6,9],
l:712,
t:541,
dn:'sf_2642',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2650:{
from:10,
to:90,
siaf:0.33,
sid:2.67,
mdi:'sf_2650c',
apsn:'Slide2572',
type:64
},
sf_2650Ad:{
src:'ar/KeyClick.mp3',
from:10,
to:90,
du:2
},
sf_2650c:{
id:'sf_2650c',
b:[83,0,13,9],
l:605,
t:503,
dn:'sf_2650',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg',
pkt:1
},
sf_2654:{
from:10,
to:90,
siaf:0.33,
sid:2.67,
mdi:'sf_2654c',
apsn:'Slide2572',
type:64
},
sf_2654c:{
id:'sf_2654c',
b:[96,0,13,10],
l:605,
t:512,
dn:'sf_2654',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2658:{
from:10,
to:90,
siaf:0.33,
sid:2.67,
mdi:'sf_2658c',
apsn:'Slide2572',
type:64
},
sf_2658c:{
id:'sf_2658c',
b:[109,0,6,10],
l:712,
t:541,
dn:'sf_2658',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2666:{
from:15,
to:90,
siaf:0.5,
sid:2.5,
mdi:'sf_2666c',
apsn:'Slide2572',
type:64
},
sf_2666Ad:{
src:'ar/KeyClick.mp3',
from:15,
to:90,
du:2
},
sf_2666c:{
id:'sf_2666c',
b:[115,0,5,9],
l:617,
t:503,
dn:'sf_2666',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg',
pkt:1
},
sf_2670:{
from:15,
to:90,
siaf:0.5,
sid:2.5,
mdi:'sf_2670c',
apsn:'Slide2572',
type:64
},
sf_2670c:{
id:'sf_2670c',
b:[120,0,5,10],
l:617,
t:512,
dn:'sf_2670',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2674:{
from:15,
to:90,
siaf:0.5,
sid:2.5,
mdi:'sf_2674c',
apsn:'Slide2572',
type:64
},
sf_2674c:{
id:'sf_2674c',
b:[125,0,7,10],
l:711,
t:541,
dn:'sf_2674',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2680:{
from:17,
to:90,
siaf:0.57,
sid:2.43,
mdi:'sf_2680c',
apsn:'Slide2572',
type:64
},
sf_2680c:{
id:'sf_2680c',
b:[132,0,374,48],
l:74,
t:912,
dn:'sf_2680',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2684:{
from:17,
to:90,
siaf:0.57,
sid:2.43,
mdi:'sf_2684c',
apsn:'Slide2572',
type:64
},
sf_2684c:{
id:'sf_2684c',
b:[506,0,374,24],
l:74,
t:960,
dn:'sf_2684',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2690:{
from:19,
to:90,
siaf:0.63,
sid:2.37,
mdi:'sf_2690c',
apsn:'Slide2572',
type:64
},
sf_2690Ad:{
src:'ar/KeyClick.mp3',
from:19,
to:90,
du:2
},
sf_2690c:{
id:'sf_2690c',
b:[880,0,10,9],
l:621,
t:503,
dn:'sf_2690',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg',
pkt:1
},
sf_2694:{
from:19,
to:90,
siaf:0.63,
sid:2.37,
mdi:'sf_2694c',
apsn:'Slide2572',
type:64
},
sf_2694c:{
id:'sf_2694c',
b:[890,0,10,10],
l:621,
t:512,
dn:'sf_2694',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2698:{
from:19,
to:90,
siaf:0.63,
sid:2.37,
mdi:'sf_2698c',
apsn:'Slide2572',
type:64
},
sf_2698c:{
id:'sf_2698c',
b:[900,0,7,10],
l:711,
t:541,
dn:'sf_2698',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2706:{
from:24,
to:90,
siaf:0.8,
sid:2.2,
mdi:'sf_2706c',
apsn:'Slide2572',
type:64
},
sf_2706c:{
id:'sf_2706c',
b:[907,0,10,9],
l:630,
t:503,
dn:'sf_2706',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2710:{
from:24,
to:90,
siaf:0.8,
sid:2.2,
mdi:'sf_2710c',
apsn:'Slide2572',
type:64
},
sf_2710c:{
id:'sf_2710c',
b:[917,0,10,10],
l:630,
t:512,
dn:'sf_2710',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2714:{
from:24,
to:90,
siaf:0.8,
sid:2.2,
mdi:'sf_2714c',
apsn:'Slide2572',
type:64
},
sf_2714c:{
id:'sf_2714c',
b:[927,0,6,10],
l:712,
t:541,
dn:'sf_2714',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2720:{
from:26,
to:90,
siaf:0.87,
sid:2.13,
mdi:'sf_2720c',
apsn:'Slide2572',
type:64
},
sf_2720Ad:{
src:'ar/KeyClick.mp3',
from:26,
to:90,
du:2
},
sf_2720c:{
id:'sf_2720c',
b:[933,0,10,9],
l:639,
t:503,
dn:'sf_2720',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg',
pkt:1
},
sf_2724:{
from:26,
to:90,
siaf:0.87,
sid:2.13,
mdi:'sf_2724c',
apsn:'Slide2572',
type:64
},
sf_2724c:{
id:'sf_2724c',
b:[943,0,10,10],
l:639,
t:512,
dn:'sf_2724',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2728:{
from:26,
to:90,
siaf:0.87,
sid:2.13,
mdi:'sf_2728c',
apsn:'Slide2572',
type:64
},
sf_2728c:{
id:'sf_2728c',
b:[953,0,7,10],
l:711,
t:541,
dn:'sf_2728',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2736:{
from:31,
to:90,
siaf:1.03,
sid:1.97,
mdi:'sf_2736c',
apsn:'Slide2572',
type:64
},
sf_2736c:{
id:'sf_2736c',
b:[960,0,13,15],
l:1011,
t:4,
dn:'sf_2736',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2740:{
from:31,
to:90,
siaf:1.03,
sid:1.97,
mdi:'sf_2740c',
apsn:'Slide2572',
type:64
},
sf_2740c:{
id:'sf_2740c',
b:[973,0,64,12],
l:1024,
t:6,
dn:'sf_2740',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2744:{
from:31,
to:90,
siaf:1.03,
sid:1.97,
mdi:'sf_2744c',
apsn:'Slide2572',
type:64
},
sf_2744c:{
id:'sf_2744c',
b:[1037,0,55,13],
l:1088,
t:5,
dn:'sf_2744',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2748:{
from:31,
to:90,
siaf:1.03,
sid:1.97,
mdi:'sf_2748c',
apsn:'Slide2572',
type:64
},
sf_2748c:{
id:'sf_2748c',
b:[1092,0,14,14],
l:1195,
t:5,
dn:'sf_2748',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2754:{
from:33,
to:90,
siaf:1.1,
sid:1.9,
mdi:'sf_2754c',
apsn:'Slide2572',
type:64
},
sf_2754Ad:{
src:'ar/KeyClick.mp3',
from:33,
to:90,
du:1
},
sf_2754c:{
id:'sf_2754c',
b:[1106,0,5,9],
l:648,
t:503,
dn:'sf_2754',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg',
pkt:1
},
sf_2758:{
from:33,
to:90,
siaf:1.1,
sid:1.9,
mdi:'sf_2758c',
apsn:'Slide2572',
type:64
},
sf_2758c:{
id:'sf_2758c',
b:[1111,0,5,10],
l:648,
t:512,
dn:'sf_2758',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2762:{
from:33,
to:90,
siaf:1.1,
sid:1.9,
mdi:'sf_2762c',
apsn:'Slide2572',
type:64
},
sf_2762c:{
id:'sf_2762c',
b:[1116,0,7,10],
l:711,
t:541,
dn:'sf_2762',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2770:{
from:37,
to:90,
siaf:1.23,
sid:1.77,
mdi:'sf_2770c',
apsn:'Slide2572',
type:64
},
sf_2770Ad:{
src:'ar/KeyClick.mp3',
from:37,
to:90,
du:1
},
sf_2770c:{
id:'sf_2770c',
b:[1123,0,9,9],
l:652,
t:503,
dn:'sf_2770',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg',
pkt:1
},
sf_2774:{
from:37,
to:90,
siaf:1.23,
sid:1.77,
mdi:'sf_2774c',
apsn:'Slide2572',
type:64
},
sf_2774c:{
id:'sf_2774c',
b:[1132,0,9,10],
l:652,
t:512,
dn:'sf_2774',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
sf_2778:{
from:37,
to:90,
siaf:1.23,
sid:1.77,
mdi:'sf_2778c',
apsn:'Slide2572',
type:64
},
sf_2778c:{
id:'sf_2778c',
b:[1141,0,6,10],
l:712,
t:541,
dn:'sf_2778',
visible:1,
effectiveVi:1,
ip:'dr/sfs5.jpg'
},
si2598:{
name:'Simulation_18',
type:1268,
from:1489,
to:1536,
rp:0,
rpa:0,
mdi:'si2598c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2572',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2590',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2598c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2598,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2598',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2590:{
name:'Simulation_non_responsive_18',
type:1268,
from:1489,
to:1536,
rp:0,
rpa:0,
mdi:'si2590c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"object-typing-text":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si2598',
retainState:false,
immo:false,
apsn:'Slide2572',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'sf_2614',
t:64
}
,{
n:'sf_2618',
t:64
}
,{
n:'sf_2622',
t:64
}
,{
n:'sf_2626',
t:64
}
,{
n:'sf_2634',
t:64
}
,{
n:'sf_2638',
t:64
}
,{
n:'sf_2642',
t:64
}
,{
n:'sf_2650',
t:64
}
,{
n:'sf_2654',
t:64
}
,{
n:'sf_2658',
t:64
}
,{
n:'sf_2666',
t:64
}
,{
n:'sf_2670',
t:64
}
,{
n:'sf_2674',
t:64
}
,{
n:'sf_2680',
t:64
}
,{
n:'sf_2684',
t:64
}
,{
n:'sf_2690',
t:64
}
,{
n:'sf_2694',
t:64
}
,{
n:'sf_2698',
t:64
}
,{
n:'sf_2706',
t:64
}
,{
n:'sf_2710',
t:64
}
,{
n:'sf_2714',
t:64
}
,{
n:'sf_2720',
t:64
}
,{
n:'sf_2724',
t:64
}
,{
n:'sf_2728',
t:64
}
,{
n:'sf_2736',
t:64
}
,{
n:'sf_2740',
t:64
}
,{
n:'sf_2744',
t:64
}
,{
n:'sf_2748',
t:64
}
,{
n:'sf_2754',
t:64
}
,{
n:'sf_2758',
t:64
}
,{
n:'sf_2762',
t:64
}
,{
n:'sf_2770',
t:64
}
,{
n:'sf_2774',
t:64
}
,{
n:'sf_2778',
t:64
}
,{
n:'si2780',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"object-typing-text":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2598',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2590c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2590,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2590',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:2606,
tsp:50,
ip:'dr/02606.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2780:{
name:'Mouse_18',
type:12,
from:1489,
to:1536,
rp:0,
rpa:0,
mdi:'si2780c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":663,"mouseStartPointY":511,"mouseEndPointX":655,"mouseEndPointY":508}}',
parentGroup:'si2590',
retainState:false,
immo:false,
apsn:'Slide2572',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2780Ad',
trin:0,
trout:0,
isDD:false
},
si2780c:{
b:[651,499,660,517],
fh:false,
fw:false,
uid:2780,
iso:false,
css:{
360:{
l:'66.975%',
t:'82.072%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.975%',
lhID:-1,
lvEID:0,
lvV:'82.072%',
lvID:-1,
w:'9px',
h:'18px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'66.975%',
t:'82.072%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.975%',
lhID:-1,
lvEID:0,
lvV:'82.072%',
lvID:-1,
w:'9px',
h:'18px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'66.975%',
t:'82.072%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'66.975%',
lhID:-1,
lvEID:0,
lvV:'82.072%',
lvID:-1,
w:'9px',
h:'18px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2780',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[651,499,663,517],
vb:[651,499,663,517]
},
si2780Ad:{
src:'ar/Mouse.mp3',
from:1489,
to:1494,
del:2.818,
msa:1,
du:0.182
},
Slide2572:{
lb:'Simulation slide 19',
id:2572,
from:3883,
to:3972,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2572c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si2598',
t:1268
}
]
,
iph:[]
,
oa:'si2780Ad,sf_2614Ad,sf_2634Ad,sf_2650Ad,sf_2666Ad,sf_2690Ad,sf_2720Ad,sf_2754Ad,sf_2770Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2572c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2572,
dn:'Slide2572',
visible:'1'
},
si2813:{
name:'Simulation_19',
type:1268,
from:1537,
to:1626,
rp:0,
rpa:0,
mdi:'si2813c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2787',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2805',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2813c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2813,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2813',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2805:{
name:'Simulation_non_responsive_19',
type:1268,
from:1537,
to:1626,
rp:0,
rpa:0,
mdi:'si2805c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si2813',
retainState:false,
immo:false,
apsn:'Slide2787',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2824',
t:1269
}
,{
n:'si2844',
t:612
}
,{
n:'si2904',
t:612
}
,{
n:'si2914',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-highlight-box":true,"slide-item-comment-box":true,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-highlight-box":1,"slide-item-comment-box":1,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2813',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2805c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2805,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2805',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:2821,
tsp:50,
ip:'dr/02821.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2824:{
name:'Highlight_box_13',
type:1269,
from:1537,
to:1626,
rp:0,
rpa:0,
mdi:'si2824c',
tag:'slide-item-highlight-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":true,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":577,"left":747,"width":34,"height":20}}',
parentGroup:'si2805',
retainState:false,
immo:false,
apsn:'Slide2787',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
ihb:true,
si:[{
n:'si2834',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2824]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2824c:{
b:[747,577,781,597],
fh:false,
fw:false,
uid:2824,
iso:false,
css:{
360:{
l:'76.852%',
t:'94.901%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'76.852%',
lhID:-1,
lvEID:0,
lvV:'94.901%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'76.852%',
t:'94.901%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'76.852%',
lhID:-1,
lvEID:0,
lvV:'94.901%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'76.852%',
t:'94.901%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'76.852%',
lhID:-1,
lvEID:0,
lvV:'94.901%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2824',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[747,577,781,597],
vb:[747,577,781,597]
},
si2834:{
name:'Shape_13',
type:612,
from:1537,
to:1626,
rp:0,
rpa:0,
mdi:'si2834c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2787',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2834]
}
]
,
stis:0,
bstiid:2824,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2824',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2834c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2834,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2834',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2844:{
name:'Rectangle_13',
type:612,
from:1537,
to:1626,
rp:0,
rpa:0,
mdi:'si2844c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":637,"left":762,"width":300,"height":"auto"}}',
parentGroup:'si2805',
retainState:false,
immo:false,
apsn:'Slide2787',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2855,
stt:0,
dsr:'Default_State',
stsi:[2844]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2844','si2857','si2868','si2879'],
isDD:false
},
si2844c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2844,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2844',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2857:{
name:'',
type:612,
from:1537,
to:1626,
rp:0,
rpa:0,
mdi:'si2857c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":637,"left":762,"width":300,"height":"auto"}}',
parentGroup:'si2805',
retainState:false,
immo:false,
apsn:'Slide2787',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2844',
stl:[{
stn:'Normal',
stt:0,
stsi:[2857]
}
]
,
stis:0,
bstiid:2844,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2844,
isDD:false
},
si2857c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2857,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2857',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2868:{
name:'',
type:612,
from:1537,
to:1626,
rp:0,
rpa:0,
mdi:'si2868c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":637,"left":762,"width":300,"height":"auto"}}',
parentGroup:'si2805',
retainState:false,
immo:false,
apsn:'Slide2787',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2844',
stl:[{
stn:'Normal',
stt:0,
stsi:[2868]
}
]
,
stis:0,
bstiid:2844,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2844,
isDD:false
},
si2868c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2868,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2868',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2879:{
name:'',
type:612,
from:1537,
to:1626,
rp:0,
rpa:0,
mdi:'si2879c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":637,"left":762,"width":300,"height":"auto"}}',
parentGroup:'si2805',
retainState:false,
immo:false,
apsn:'Slide2787',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2844',
stl:[{
stn:'Normal',
stt:0,
stsi:[2879]
}
]
,
stis:0,
bstiid:2844,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2844,
isDD:false
},
si2879c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2879,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2879',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2904:{
name:'Instructions_13',
type:612,
from:1537,
to:1626,
rp:0,
rpa:0,
mdi:'si2904c',
tag:'slide-item-comment-box',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"currentState":"normal","normal":{"opacity":100,"padding":10,"editorState":{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_comment_box_shape_1_solid_style","fillEnable":true,"strokeEnable":false,"shadowEnable":false,"fillType":1}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":607,"left":754,"width":320}}',
parentGroup:'si2805',
retainState:false,
immo:false,
apsn:'Slide2787',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"Click the  scroller area","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"presetId":"text-comment-box","listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
adj:[3085.71,-6171.43,3600],
isco:1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2904]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si2904c:{
b:[754,607,1074,707],
fh:false,
fw:false,
uid:2904,
iso:false,
css:{
360:{
l:'77.572%',
t:'99.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'77.572%',
lhID:-1,
lvEID:0,
lvV:'99.836%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'77.572%',
t:'99.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'77.572%',
lhID:-1,
lvEID:0,
lvV:'99.836%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'77.572%',
t:'99.836%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'77.572%',
lhID:-1,
lvEID:0,
lvV:'99.836%',
lvID:-1,
w:'32.922%',
h:'16.447%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2904',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:57,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,1076,709],
vb:[-2,-2,1076,709]
},
si2914:{
name:'Mouse_19',
type:12,
from:1579,
to:1626,
rp:0,
rpa:0,
mdi:'si2914c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":663,"mouseStartPointY":511,"mouseEndPointX":764,"mouseEndPointY":587}}',
parentGroup:'si2805',
retainState:false,
immo:false,
apsn:'Slide2787',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2914Ad',
trin:0,
trout:0,
isDD:false
},
si2914c:{
b:[751,579,783,611],
fh:false,
fw:false,
uid:2914,
iso:false,
css:{
360:{
l:'77.263%',
t:'95.230%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'77.263%',
lhID:-1,
lvEID:0,
lvV:'95.230%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'77.263%',
t:'95.230%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'77.263%',
lhID:-1,
lvEID:0,
lvV:'95.230%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'77.263%',
t:'95.230%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'77.263%',
lhID:-1,
lvEID:0,
lvV:'95.230%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2914',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[663,511,783,611],
vb:[663,511,783,611]
},
si2914Ad:{
src:'ar/Mouse.mp3',
from:1579,
to:1584,
del:2.818,
msa:1,
du:0.182
},
Slide2787:{
lb:'Simulation slide 20',
id:2787,
from:3973,
to:4062,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2787c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si2813',
t:1268
}
]
,
iph:[]
,
oa:'si2914Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2787c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2787,
dn:'Slide2787',
visible:'1'
},
si2947:{
name:'Simulation_20',
type:1268,
from:1669,
to:1716,
rp:0,
rpa:0,
mdi:'si2947c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2921',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2939',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2947c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2947,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2947',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2939:{
name:'Simulation_non_responsive_20',
type:1268,
from:1669,
to:1716,
rp:0,
rpa:0,
mdi:'si2939c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si2947',
retainState:false,
immo:false,
apsn:'Slide2921',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2958',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2947',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2939c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2939,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2939',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:2955,
tsp:50,
ip:'dr/02955.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2958:{
name:'Mouse_20',
type:12,
from:1669,
to:1716,
rp:0,
rpa:0,
mdi:'si2958c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:1.4,
sid:1.6,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":763,"mouseStartPointY":591,"mouseEndPointX":621,"mouseEndPointY":329}}',
parentGroup:'si2939',
retainState:false,
immo:false,
apsn:'Slide2921',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si2958Ad',
trin:0,
trout:0,
isDD:false
},
si2958c:{
b:[608,321,640,353],
fh:false,
fw:false,
uid:2958,
iso:false,
css:{
360:{
l:'62.551%',
t:'52.796%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.551%',
lhID:-1,
lvEID:0,
lvV:'52.796%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'62.551%',
t:'52.796%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.551%',
lhID:-1,
lvEID:0,
lvV:'52.796%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'62.551%',
t:'52.796%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'62.551%',
lhID:-1,
lvEID:0,
lvV:'52.796%',
lvID:-1,
w:'32px',
h:'32px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2958',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[608,321,764,591],
vb:[608,321,764,591]
},
si2958Ad:{
src:'ar/Mouse.mp3',
from:1669,
to:1674,
del:2.818,
msa:1,
du:0.182
},
Slide2921:{
lb:'Simulation slide 21',
id:2921,
from:4063,
to:4152,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2921c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si2947',
t:1268
}
]
,
iph:[]
,
oa:'si2958Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2921c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2921,
dn:'Slide2921',
visible:'1'
},
si2983:{
name:'Video_2',
type:1268,
from:1717,
to:1746,
rp:0,
rpa:0,
mdi:'si2983c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide2965',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3002',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2983c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2983,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2983',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3002:{
name:'SlideVideo_2',
type:365,
from:1717,
to:1746,
rp:0,
rpa:0,
mdi:'si3002c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2983',
retainState:false,
immo:false,
apsn:'Slide2965',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si3002c:{
b:[-204,-188,1176,796],
fh:false,
fw:false,
uid:3002,
iso:false,
css:{
360:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3002',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/02998.png',
mp4:'vr/Vi2991.mp4',
vsf:0,
vst:1,
o:100,
vbwr:[-205,-189,1177,797],
vb:[-205,-189,1177,797]
},
Slide2965:{
lb:'Simulation slide 22',
id:2965,
from:4153,
to:4182,
iols:0,
i360qs:false,
sdu:1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2965c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si2983',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2965c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2965,
dn:'Slide2965',
visible:'1'
},
si3027:{
name:'Video_3',
type:1268,
from:1747,
to:1935,
rp:0,
rpa:0,
mdi:'si3027c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide3009',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3046',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3027c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3027,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3027',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3046:{
name:'SlideVideo_3',
type:365,
from:1747,
to:1935,
rp:0,
rpa:0,
mdi:'si3046c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.3,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3027',
retainState:false,
immo:false,
apsn:'Slide3009',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si3046c:{
b:[-204,-188,1176,796],
fh:false,
fw:false,
uid:3046,
iso:false,
css:{
360:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3046',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/03042.png',
mp4:'vr/Vi3035.mp4',
vsf:0,
vst:6.3,
o:100,
vbwr:[-205,-189,1177,797],
vb:[-205,-189,1177,797]
},
Slide3009:{
lb:'Simulation slide 23',
id:3009,
from:4183,
to:4371,
iols:0,
i360qs:false,
sdu:6.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide3009c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si3027',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide3009c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:3009,
dn:'Slide3009',
visible:'1'
},
si3071:{
name:'Video_4',
type:1268,
from:1936,
to:1965,
rp:0,
rpa:0,
mdi:'si3071c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide3053',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3090',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3071c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3071,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3071',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3090:{
name:'SlideVideo_4',
type:365,
from:1936,
to:1965,
rp:0,
rpa:0,
mdi:'si3090c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3071',
retainState:false,
immo:false,
apsn:'Slide3053',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si3090c:{
b:[-204,-188,1176,796],
fh:false,
fw:false,
uid:3090,
iso:false,
css:{
360:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-20.988%',
t:'-30.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-20.988%',
lhID:-1,
lvEID:0,
lvV:'-30.921%',
lvID:-1,
w:'141.975%',
h:'161.842%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3090',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/03086.png',
mp4:'vr/Vi3079.mp4',
vsf:0,
vst:1,
o:100,
vbwr:[-205,-189,1177,797],
vb:[-205,-189,1177,797]
},
Slide3053:{
lb:'Simulation slide 24',
id:3053,
from:4372,
to:4401,
iols:0,
i360qs:false,
sdu:1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide3053c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si3071',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide3053c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:3053,
dn:'Slide3053',
visible:'1'
},
si3123:{
name:'Simulation_21',
type:1268,
from:1966,
to:2055,
rp:0,
rpa:0,
mdi:'si3123c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide3097',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3115',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3123c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3123,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3123',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3115:{
name:'Simulation_non_responsive_21',
type:1268,
from:1966,
to:2055,
rp:0,
rpa:0,
mdi:'si3115c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
parentGroup:'si3123',
retainState:false,
immo:false,
apsn:'Slide3097',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3134',
t:12
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-mouse-pointer":true},"sizeNPos":{"width":1380,"height":984},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-mouse-pointer":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3123',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3115c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3115,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3115',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1380,
h:984,
id:3131,
tsp:50,
ip:'dr/03131.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3134:{
name:'Mouse_21',
type:12,
from:1966,
to:2055,
rp:0,
rpa:0,
mdi:'si3134c',
tag:'slide-item-mouse-pointer',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"mouseMovementPathType":1,"mouseMovementSpeed":1,"mouseStraightPath":false,"scaleValue":"medium","mouseClickData":{"color":"#0000ff","showMouseClick":0,"scaleValue":"medium"},"svgData":{"mousePointerType":0},"mousePathPoints":{"mouseStartPointX":620,"mouseStartPointY":333,"mouseEndPointX":905,"mouseEndPointY":952}}',
parentGroup:'si3115',
retainState:false,
immo:false,
apsn:'Slide3097',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
msa:'si3134Ad',
trin:0,
trout:0,
isDD:false
},
si3134c:{
b:[901,948,918,971],
fh:false,
fw:false,
uid:3134,
iso:false,
css:{
360:{
l:'92.695%',
t:'155.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'92.695%',
lhID:-1,
lvEID:0,
lvV:'155.921%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'92.695%',
t:'155.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'92.695%',
lhID:-1,
lvEID:0,
lvV:'155.921%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'92.695%',
t:'155.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'92.695%',
lhID:-1,
lvEID:0,
lvV:'155.921%',
lvID:-1,
w:'17px',
h:'23px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3134',
visible:1,
effectiveVi:1,
JSONEffectData:false,
t:1,
sz:0,
mpt:0,
data:{
c:'#0000ff',
fca:1,
r:12
}
,
sde:false,
se:false,
vbwr:[620,333,918,971],
vb:[620,333,918,971]
},
si3134Ad:{
src:'ar/Mouse.mp3',
from:1966,
to:1971,
del:2.818,
msa:1,
du:0.182
},
Slide3097:{
lb:'Simulation slide 25',
id:3097,
from:4402,
to:4491,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide3097c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si3123',
t:1268
}
]
,
iph:[]
,
oa:'si3134Ad',
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide3097c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:3097,
dn:'Slide3097',
visible:'1'
},
si3755:{
name:'Result_2',
type:1268,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3755c',
tag:'container-result',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":38,"bottom":38,"left":15,"right":15},"visibilityInfo":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"name":"ResultSlideWidget","isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3763',
t:1268
}
,{
n:'si3933',
t:612
}
]
,
containerType:'result',
widgetProps:'{"padding":{"top":38,"bottom":38,"left":15,"right":15},"visibilityInfo":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"name":"ResultSlideWidget","isQuizContainer":true,"autoFit":true,"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3755c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3755,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3755',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3763:{
name:'Result_Group_1',
type:1268,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3763c',
tag:'container-result-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-result-heading":true,"user-score-label":true,"max-score-label":true,"correct-questions-count-label":true,"total-questions-count-label":true,"accuracy-label":true,"attempt-count-label":true,"user-score-variable":true,"max-score-variable":true,"correct-questions-count-variable":true,"total-questions-count-variable":true,"accuracy-variable":true,"attempt-count-variable":true,"slide-item-review-button":true,"slide-item-continue-button":true,"slide-item-retake-button":true,"card":false},"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-result-field-area":{"all":{"display":"flex","flexDirection":"column","alignItems":"center","gap":"28px","marginTop":"40px","paddingLeft":"6px"},"tablet":{},"mobile":{}},"container-result-field-unit-area":{"all":{"display":"flex","flexDirection":"row","alignItems":"center","width":"100%","justifyContent":"space-between"},"tablet":{},"mobile":{}},"container-result-buttons":{"all":{"display":"flex","gap":"20px","marginTop":"60px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
parentGroup:'si3755',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3771',
t:1250
}
,{
n:'si3780',
t:1250
}
,{
n:'si3789',
t:1250
}
,{
n:'si3798',
t:1250
}
,{
n:'si3807',
t:1250
}
,{
n:'si3816',
t:1250
}
,{
n:'si3825',
t:1250
}
,{
n:'si3834',
t:1250
}
,{
n:'si3843',
t:1250
}
,{
n:'si3852',
t:1250
}
,{
n:'si3861',
t:1250
}
,{
n:'si3870',
t:1250
}
,{
n:'si3879',
t:1250
}
,{
n:'si3888',
t:29
}
,{
n:'si3903',
t:29
}
,{
n:'si3918',
t:29
}
]
,
containerType:'result-card',
widgetProps:'{"visibilityInfo":{"slide-item-result-heading":true,"user-score-label":true,"max-score-label":true,"correct-questions-count-label":true,"total-questions-count-label":true,"accuracy-label":true,"attempt-count-label":true,"user-score-variable":true,"max-score-variable":true,"correct-questions-count-variable":true,"total-questions-count-variable":true,"accuracy-variable":true,"attempt-count-variable":true,"slide-item-review-button":true,"slide-item-continue-button":true,"slide-item-retake-button":true,"card":false},"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-result-field-area":{"all":{"display":"flex","flexDirection":"column","alignItems":"center","gap":"28px","marginTop":"40px","paddingLeft":"6px"},"tablet":{},"mobile":{}},"container-result-field-unit-area":{"all":{"display":"flex","flexDirection":"row","alignItems":"center","width":"100%","justifyContent":"space-between"},"tablet":{},"mobile":{}},"container-result-buttons":{"all":{"display":"flex","gap":"20px","marginTop":"60px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3755',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3763c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3763,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3763',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3771:{
name:'Text_272',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3771c',
tag:'slide-item-result-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"justifyContent":"center"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"duoai","text":"Quiz Results","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":12,"style":"hlnk:"},{"offset":0,"length":12,"style":"hlnkt:wp"},{"offset":0,"length":12,"style":"textOutlineEnable:false"},{"offset":0,"length":12,"style":"opacity:1"},{"offset":0,"length":12,"style":"hlnke:true"},{"offset":0,"length":12,"style":"backgroundColor:unset"},{"offset":0,"length":12,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":12,"style":"textHighlightEnable:false"},{"offset":0,"length":12,"style":"textShadowEnable:false"},{"offset":0,"length":12,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3771]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3771c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3771,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3771',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3780:{
name:'Text_273',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3780c',
tag:'user-score-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"eo2hc","text":"You scored:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3780]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3780c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3780,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3780',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3789:{
name:'Text_274',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3789c',
tag:'user-score-variable',
v:0,
enabled:true,
defEn:true,
vu:[373],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"2f52s","text":"$$Quiz.Score$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3789]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3789c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3789,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3789',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3798:{
name:'Text_275',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3798c',
tag:'max-score-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"dmmbs","text":"Maximum score:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3798]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3798c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3798,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3798',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3807:{
name:'Text_276',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3807c',
tag:'max-score-variable',
v:0,
enabled:true,
defEn:true,
vu:[377],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"374tl","text":"$$Quiz.MaxScore$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"hlnke:true"},{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"overridden:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3807]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3807c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3807,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3807',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3816:{
name:'Text_277',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3816c',
tag:'correct-questions-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"fofds","text":"Correct responses:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":18,"style":"hlnk:"},{"offset":0,"length":18,"style":"hlnkt:wp"},{"offset":0,"length":18,"style":"textOutlineEnable:false"},{"offset":0,"length":18,"style":"opacity:1"},{"offset":0,"length":18,"style":"hlnke:true"},{"offset":0,"length":18,"style":"backgroundColor:unset"},{"offset":0,"length":18,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":18,"style":"textHighlightEnable:false"},{"offset":0,"length":18,"style":"textShadowEnable:false"},{"offset":0,"length":18,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3816]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3816c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3816,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3816',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3825:{
name:'Text_278',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3825c',
tag:'correct-questions-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[376],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"d67j4","text":"$$Quiz.CorrectAnswerCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":27,"style":"hlnk:"},{"offset":0,"length":27,"style":"hlnkt:wp"},{"offset":0,"length":27,"style":"textOutlineEnable:false"},{"offset":0,"length":27,"style":"opacity:1"},{"offset":0,"length":27,"style":"hlnke:true"},{"offset":0,"length":27,"style":"backgroundColor:unset"},{"offset":0,"length":27,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":27,"style":"textHighlightEnable:false"},{"offset":0,"length":27,"style":"textShadowEnable:false"},{"offset":0,"length":27,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3825]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3825c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3825,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3825',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3834:{
name:'Text_279',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3834c',
tag:'total-questions-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"cu7h5","text":"Total questions:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":16,"style":"backgroundColor:unset"},{"offset":0,"length":16,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":16,"style":"textHighlightEnable:false"},{"offset":0,"length":16,"style":"textShadowEnable:false"},{"offset":0,"length":16,"style":"overridden:false"},{"offset":0,"length":16,"style":"hlnk:"},{"offset":0,"length":16,"style":"hlnkt:wp"},{"offset":0,"length":16,"style":"textOutlineEnable:false"},{"offset":0,"length":16,"style":"opacity:1"},{"offset":0,"length":16,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3834]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3834c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3834,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3834',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3843:{
name:'Text_280',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3843c',
tag:'total-questions-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[378],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"f7o4p","text":"$$Quiz.QuestionCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":22,"style":"hlnk:"},{"offset":0,"length":22,"style":"hlnkt:wp"},{"offset":0,"length":22,"style":"textOutlineEnable:false"},{"offset":0,"length":22,"style":"opacity:1"},{"offset":0,"length":22,"style":"hlnke:true"},{"offset":0,"length":22,"style":"backgroundColor:unset"},{"offset":0,"length":22,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":22,"style":"textHighlightEnable:false"},{"offset":0,"length":22,"style":"textShadowEnable:false"},{"offset":0,"length":22,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3843]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3843c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3843,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3843',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3852:{
name:'Text_281',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3852c',
tag:'accuracy-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3q4mq","text":"Accuracy:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3852]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3852c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3852,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3852',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3861:{
name:'Text_282',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3861c',
tag:'accuracy-variable',
v:0,
enabled:true,
defEn:true,
vu:[370],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5eprr","text":"$$Quiz.PercentageScore$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"textHighlightEnable:false"},{"offset":0,"length":24,"style":"textShadowEnable:false"},{"offset":0,"length":24,"style":"overridden:false"},{"offset":0,"length":24,"style":"hlnk:"},{"offset":0,"length":24,"style":"hlnkt:wp"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"backgroundColor:unset"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3861]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3861c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3861,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3861',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3870:{
name:'Text_283',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3870c',
tag:'attempt-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"cjkqr","text":"Number of attempts:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"opacity:1"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3870]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3870c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3870,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3870',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3879:{
name:'Text_284',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3879c',
tag:'attempt-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[371],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"41e8j","text":"$$Quiz.AttemptCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":21,"style":"hlnk:"},{"offset":0,"length":21,"style":"hlnkt:wp"},{"offset":0,"length":21,"style":"textOutlineEnable:false"},{"offset":0,"length":21,"style":"opacity:1"},{"offset":0,"length":21,"style":"hlnke:true"},{"offset":0,"length":21,"style":"backgroundColor:unset"},{"offset":0,"length":21,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":21,"style":"textHighlightEnable:false"},{"offset":0,"length":21,"style":"textShadowEnable:false"},{"offset":0,"length":21,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3879]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3879c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3879,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3879',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3888:{
name:'Button_226',
type:29,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3888c',
tag:'slide-item-review-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"03537.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"asf6a","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"243tb","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8lkt0","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2ibkv","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"frh04","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:7,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3888]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3888c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3888,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3888',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3903:{
name:'Button_227',
type:29,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3903c',
tag:'slide-item-continue-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"03519.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9hdv6","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"aa4hv","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"69oi0","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7insb","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3p90","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:8,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3903]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3903c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3903,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3903',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3918:{
name:'Button_228',
type:29,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3918c',
tag:'slide-item-retake-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"03537.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bnalk","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2sp0t","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6esjn","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8dlun","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4c9g5","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:9,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3918]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3918c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3918,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3918',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3946:{
name:'Caption_3',
type:612,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3946c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3755',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"8kfeg","text":"Congratulations, you passed the quiz!","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":37,"style":"hlnk:"},{"offset":0,"length":37,"style":"hlnkt:wp"},{"offset":0,"length":37,"style":"textOutlineEnable:false"},{"offset":0,"length":37,"style":"opacity:1"},{"offset":0,"length":37,"style":"hlnke:true"},{"offset":0,"length":37,"style":"backgroundColor:unset"},{"offset":0,"length":37,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":37,"style":"textHighlightEnable:false"},{"offset":0,"length":37,"style":"textShadowEnable:false"},{"offset":0,"length":37,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3933',
stl:[{
stn:'Normal',
stt:0,
stsi:[3946]
}
]
,
stis:0,
bstiid:3933,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3933,
isDD:false
},
si3946c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3946,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3946',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3957:{
name:'Caption_3',
type:612,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3957c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3755',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"8udkh","text":"Sorry, you failed the quiz.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":27,"style":"backgroundColor:unset"},{"offset":0,"length":27,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":27,"style":"textHighlightEnable:false"},{"offset":0,"length":27,"style":"textShadowEnable:false"},{"offset":0,"length":27,"style":"overridden:false"},{"offset":0,"length":27,"style":"hlnk:"},{"offset":0,"length":27,"style":"hlnkt:wp"},{"offset":0,"length":27,"style":"textOutlineEnable:false"},{"offset":0,"length":27,"style":"opacity:1"},{"offset":0,"length":27,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3933',
stl:[{
stn:'Normal',
stt:0,
stsi:[3957]
}
]
,
stis:0,
bstiid:3933,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3933,
isDD:false
},
si3957c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3957,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3957',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3933:{
name:'Caption_3',
type:612,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3933c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3755',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"f262g","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:3944,
stt:0,
dsr:'Default_State',
stsi:[3933]
}
,{
stn:3945,
stt:101,
dsr:'Pass',
stsi:[3946]
}
,{
stn:3956,
stt:102,
dsr:'Fail',
stsi:[3957]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si3933','si3946','si3957'],
isDD:false
},
si3933c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3933,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3933',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3763:{
name:'Result_Group_1',
type:1268,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3763c',
tag:'container-result-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-result-heading":true,"user-score-label":true,"max-score-label":true,"correct-questions-count-label":true,"total-questions-count-label":true,"accuracy-label":true,"attempt-count-label":true,"user-score-variable":true,"max-score-variable":true,"correct-questions-count-variable":true,"total-questions-count-variable":true,"accuracy-variable":true,"attempt-count-variable":true,"slide-item-review-button":true,"slide-item-continue-button":true,"slide-item-retake-button":true,"card":false},"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-result-field-area":{"all":{"display":"flex","flexDirection":"column","alignItems":"center","gap":"28px","marginTop":"40px","paddingLeft":"6px"},"tablet":{},"mobile":{}},"container-result-field-unit-area":{"all":{"display":"flex","flexDirection":"row","alignItems":"center","width":"100%","justifyContent":"space-between"},"tablet":{},"mobile":{}},"container-result-buttons":{"all":{"display":"flex","gap":"20px","marginTop":"60px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
parentGroup:'si3755',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3771',
t:1250
}
,{
n:'si3780',
t:1250
}
,{
n:'si3789',
t:1250
}
,{
n:'si3798',
t:1250
}
,{
n:'si3807',
t:1250
}
,{
n:'si3816',
t:1250
}
,{
n:'si3825',
t:1250
}
,{
n:'si3834',
t:1250
}
,{
n:'si3843',
t:1250
}
,{
n:'si3852',
t:1250
}
,{
n:'si3861',
t:1250
}
,{
n:'si3870',
t:1250
}
,{
n:'si3879',
t:1250
}
,{
n:'si3888',
t:29
}
,{
n:'si3903',
t:29
}
,{
n:'si3918',
t:29
}
]
,
containerType:'result-card',
widgetProps:'{"visibilityInfo":{"slide-item-result-heading":true,"user-score-label":true,"max-score-label":true,"correct-questions-count-label":true,"total-questions-count-label":true,"accuracy-label":true,"attempt-count-label":true,"user-score-variable":true,"max-score-variable":true,"correct-questions-count-variable":true,"total-questions-count-variable":true,"accuracy-variable":true,"attempt-count-variable":true,"slide-item-review-button":true,"slide-item-continue-button":true,"slide-item-retake-button":true,"card":false},"padding":{"top":20,"bottom":20,"left":20,"right":20},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--design-option-color3)"}},"alignment":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"container-result-field-area":{"all":{"display":"flex","flexDirection":"column","alignItems":"center","gap":"28px","marginTop":"40px","paddingLeft":"6px"},"tablet":{},"mobile":{}},"container-result-field-unit-area":{"all":{"display":"flex","flexDirection":"row","alignItems":"center","width":"100%","justifyContent":"space-between"},"tablet":{},"mobile":{}},"container-result-buttons":{"all":{"display":"flex","gap":"20px","marginTop":"60px","paddingLeft":"6px"},"tablet":{},"mobile":{"flexDirection":"column"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si3755',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3763c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3763,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3763',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3771:{
name:'Text_272',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3771c',
tag:'slide-item-result-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"justifyContent":"center"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"duoai","text":"Quiz Results","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":12,"style":"hlnk:"},{"offset":0,"length":12,"style":"hlnkt:wp"},{"offset":0,"length":12,"style":"textOutlineEnable:false"},{"offset":0,"length":12,"style":"opacity:1"},{"offset":0,"length":12,"style":"hlnke:true"},{"offset":0,"length":12,"style":"backgroundColor:unset"},{"offset":0,"length":12,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":12,"style":"textHighlightEnable:false"},{"offset":0,"length":12,"style":"textShadowEnable:false"},{"offset":0,"length":12,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3771]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3771c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3771,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3771',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3780:{
name:'Text_273',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3780c',
tag:'user-score-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"eo2hc","text":"You scored:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3780]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3780c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3780,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3780',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3789:{
name:'Text_274',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3789c',
tag:'user-score-variable',
v:0,
enabled:true,
defEn:true,
vu:[373],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"2f52s","text":"$$Quiz.Score$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3789]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3789c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3789,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3789',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3798:{
name:'Text_275',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3798c',
tag:'max-score-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"dmmbs","text":"Maximum score:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3798]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3798c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3798,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3798',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3807:{
name:'Text_276',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3807c',
tag:'max-score-variable',
v:0,
enabled:true,
defEn:true,
vu:[377],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"374tl","text":"$$Quiz.MaxScore$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"hlnke:true"},{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"overridden:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3807]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3807c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3807,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3807',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3816:{
name:'Text_277',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3816c',
tag:'correct-questions-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"fofds","text":"Correct responses:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":18,"style":"hlnk:"},{"offset":0,"length":18,"style":"hlnkt:wp"},{"offset":0,"length":18,"style":"textOutlineEnable:false"},{"offset":0,"length":18,"style":"opacity:1"},{"offset":0,"length":18,"style":"hlnke:true"},{"offset":0,"length":18,"style":"backgroundColor:unset"},{"offset":0,"length":18,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":18,"style":"textHighlightEnable:false"},{"offset":0,"length":18,"style":"textShadowEnable:false"},{"offset":0,"length":18,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3816]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3816c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3816,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3816',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3825:{
name:'Text_278',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3825c',
tag:'correct-questions-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[376],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"d67j4","text":"$$Quiz.CorrectAnswerCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":27,"style":"hlnk:"},{"offset":0,"length":27,"style":"hlnkt:wp"},{"offset":0,"length":27,"style":"textOutlineEnable:false"},{"offset":0,"length":27,"style":"opacity:1"},{"offset":0,"length":27,"style":"hlnke:true"},{"offset":0,"length":27,"style":"backgroundColor:unset"},{"offset":0,"length":27,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":27,"style":"textHighlightEnable:false"},{"offset":0,"length":27,"style":"textShadowEnable:false"},{"offset":0,"length":27,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3825]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3825c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3825,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3825',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3834:{
name:'Text_279',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3834c',
tag:'total-questions-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"cu7h5","text":"Total questions:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":16,"style":"backgroundColor:unset"},{"offset":0,"length":16,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":16,"style":"textHighlightEnable:false"},{"offset":0,"length":16,"style":"textShadowEnable:false"},{"offset":0,"length":16,"style":"overridden:false"},{"offset":0,"length":16,"style":"hlnk:"},{"offset":0,"length":16,"style":"hlnkt:wp"},{"offset":0,"length":16,"style":"textOutlineEnable:false"},{"offset":0,"length":16,"style":"opacity:1"},{"offset":0,"length":16,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3834]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3834c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3834,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3834',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3843:{
name:'Text_280',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3843c',
tag:'total-questions-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[378],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"f7o4p","text":"$$Quiz.QuestionCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":22,"style":"hlnk:"},{"offset":0,"length":22,"style":"hlnkt:wp"},{"offset":0,"length":22,"style":"textOutlineEnable:false"},{"offset":0,"length":22,"style":"opacity:1"},{"offset":0,"length":22,"style":"hlnke:true"},{"offset":0,"length":22,"style":"backgroundColor:unset"},{"offset":0,"length":22,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":22,"style":"textHighlightEnable:false"},{"offset":0,"length":22,"style":"textShadowEnable:false"},{"offset":0,"length":22,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3843]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3843c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3843,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3843',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3852:{
name:'Text_281',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3852c',
tag:'accuracy-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3q4mq","text":"Accuracy:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3852]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3852c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3852,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3852',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3861:{
name:'Text_282',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3861c',
tag:'accuracy-variable',
v:0,
enabled:true,
defEn:true,
vu:[370],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5eprr","text":"$$Quiz.PercentageScore$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"textHighlightEnable:false"},{"offset":0,"length":24,"style":"textShadowEnable:false"},{"offset":0,"length":24,"style":"overridden:false"},{"offset":0,"length":24,"style":"hlnk:"},{"offset":0,"length":24,"style":"hlnkt:wp"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"backgroundColor:unset"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3861]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3861c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3861,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3861',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3870:{
name:'Text_283',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3870c',
tag:'attempt-count-label',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"question","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"cjkqr","text":"Number of attempts:","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"opacity:1"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3870]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3870c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3870,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3870',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3879:{
name:'Text_284',
type:1250,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3879c',
tag:'attempt-count-variable',
v:0,
enabled:true,
defEn:true,
vu:[371],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"answer","designOptionStyles":{"all":{"width":"calc(50% - 16px)"},"tablet":{},"mobile":{}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"41e8j","text":"$$Quiz.AttemptCount$$","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":21,"style":"hlnk:"},{"offset":0,"length":21,"style":"hlnkt:wp"},{"offset":0,"length":21,"style":"textOutlineEnable:false"},{"offset":0,"length":21,"style":"opacity:1"},{"offset":0,"length":21,"style":"hlnke:true"},{"offset":0,"length":21,"style":"backgroundColor:unset"},{"offset":0,"length":21,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":21,"style":"textHighlightEnable:false"},{"offset":0,"length":21,"style":"textShadowEnable:false"},{"offset":0,"length":21,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-variable-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3879]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3879c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:3879,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3879',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si3888:{
name:'Button_226',
type:29,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3888c',
tag:'slide-item-review-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"03537.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"asf6a","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"243tb","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8lkt0","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2ibkv","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"frh04","text":"Review quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:7,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3888]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3888c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3888,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3888',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3903:{
name:'Button_227',
type:29,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3903c',
tag:'slide-item-continue-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"03519.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9hdv6","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"aa4hv","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"69oi0","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7insb","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3p90","text":"Continue","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:8,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3903]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3903c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3903,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3903',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3918:{
name:'Button_228',
type:29,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3918c',
tag:'slide-item-retake-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":false,"disabled":true,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"03537.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bnalk","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color1)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5_light)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2sp0t","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color6)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6esjn","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color2)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8dlun","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color4_dark)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4c9g5","text":"Retake quiz","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5_light)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color4_dark)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"designOption":"BUTTON_ITEM_OPTION_1","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si3763',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:9,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3918]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
isDD:false
},
si3918c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3918,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3918',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3946:{
name:'Caption_3',
type:612,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3946c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3755',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"8kfeg","text":"Congratulations, you passed the quiz!","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":37,"style":"hlnk:"},{"offset":0,"length":37,"style":"hlnkt:wp"},{"offset":0,"length":37,"style":"textOutlineEnable:false"},{"offset":0,"length":37,"style":"opacity:1"},{"offset":0,"length":37,"style":"hlnke:true"},{"offset":0,"length":37,"style":"backgroundColor:unset"},{"offset":0,"length":37,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":37,"style":"textHighlightEnable:false"},{"offset":0,"length":37,"style":"textShadowEnable:false"},{"offset":0,"length":37,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3933',
stl:[{
stn:'Normal',
stt:0,
stsi:[3946]
}
]
,
stis:0,
bstiid:3933,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3933,
isDD:false
},
si3946c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3946,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3946',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3957:{
name:'Caption_3',
type:612,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3957c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3755',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"8udkh","text":"Sorry, you failed the quiz.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":27,"style":"backgroundColor:unset"},{"offset":0,"length":27,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":27,"style":"textHighlightEnable:false"},{"offset":0,"length":27,"style":"textShadowEnable:false"},{"offset":0,"length":27,"style":"overridden:false"},{"offset":0,"length":27,"style":"hlnk:"},{"offset":0,"length":27,"style":"hlnkt:wp"},{"offset":0,"length":27,"style":"textOutlineEnable:false"},{"offset":0,"length":27,"style":"opacity:1"},{"offset":0,"length":27,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si3933',
stl:[{
stn:'Normal',
stt:0,
stsi:[3957]
}
]
,
stis:0,
bstiid:3933,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:3933,
isDD:false
},
si3957c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3957,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3957',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
si3933:{
name:'Caption_3',
type:612,
from:4492,
to:4581,
rp:0,
rpa:0,
mdi:'si3933c',
tag:'slide-item-result-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"name":"Caption","position":1,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si3755',
retainState:false,
immo:false,
apsn:'Slide3714',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"f262g","text":"<Caption goes here>","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"opacity:0"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-caption","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:3944,
stt:0,
dsr:'Default_State',
stsi:[3933]
}
,{
stn:3945,
stt:101,
dsr:'Pass',
stsi:[3946]
}
,{
stn:3956,
stt:102,
dsr:'Fail',
stsi:[3957]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si3933','si3946','si3957'],
isDD:false
},
si3933c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3933,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.278%',
h:'0.132%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.167%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3933',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:0,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-4,-4,2,2],
vb:[-4,-4,2,2]
},
Slide3714:{
lb:'Result 1',
id:3714,
from:4492,
to:4581,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide3714c',
st:'Question Slide',
sk:'Quiz Result',
slideTag:'quiz-result-slide',
type:102,
accProps:{
}
,
si:[{
n:'si3755',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
osa:'{"scripts":[{"then":[["cp.jumpToNextSlide(3745);"]]}]}',
stsi:true,
ofa:'{"scripts":[{"then":[["cp.jumpToNextSlide(3754);"]]}]}',
stfi:true,
bph:[]
,
bookmarks:[]
,
qs:'',
pa:4520,
iph:{
3745:{
ts:'',
tr:''
}
,
3754:{
ts:'',
tr:''
}

}

},
Slide3714c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:3714,
dn:'Slide3714',
visible:'1'
},
quizzingData:{
resultSlideId:'Slide3714',
allowBackwardMovement:true,
allowReviewMode:true,
reviewShowAnswers:true,
it:false,
firstSlideInQuiz:-1,
lastSlideInQuiz:-1,
quizScopeEndSlide:27,
maxScore:0,
minScore:0,
maxPretestScore:0,
numQuestionsInQuiz:1,
numQuizAttemptsAllowed:1,
passingScore:0,
quizInfoCurrentAttempt:0,
quizInfoPercentScored:0,
quizMandateLevel:0,
quizID:199,
questionPoolsInitialized:true,
quizInfoAttempts:1,
quizInfoLastSlidePointScored:0,
quizInfoMaxAttemptsOnCurrentQuestion:1,
quizInfoPassFail:0,
quizInfoPointsPerQuestionSlide:0,
quizInfoPointsScored:0,
quizInfoQuizPassPercent:80,
quizInfoQuizPassPoints:0,
quizInfoTotalCorrectAnswers:0,
quizInfoTotalProjectPoints:0,
quizInfoTotalQuestionsPerProject:1,
quizInfoTotalQuizPoints:0,
quizInfoTotalUnansweredQuestions:0,
reportingEnabled:false,
submitAll:false,
hidePlaybarInQuiz:false,
quizBranchAware:false,
passFailPassingScoreTypeInPrecent:true,
passFailPassingScoreValue:80,
showRetake:false,
showReviewButtons:true,
oid:'$$OBJECTIVE_ID',
quizVariableVsIdMap:{
learnerId:'var346',
learnerName:'var347',
isInQuizScope:'var368',
isInReviewMode:'var369',
quizInfoPercentScored:'var370',
quizInfoAttempts:'var371',
quizInfoPassFail:'var372',
score:'var373',
quizInfoQuizPassPercent:'var374',
passingScore:'var375',
quizInfoTotalCorrectAnswers:'var376',
maxScore:'var377',
quizInfoTotalQuestionsPerProject:'var378',
quizInfoTotalUnansweredQuestions:'var379',
quizInfoAnswerChoice:'var380',
quizInfoPreviousQuestionScore:'var381',
questionInfoMaxAttempts:'var382',
questionInfoNegativePoints:'var383',
questionInfoPointsAssigned:'var384'
}

},
quizReportingData:{
lWriteDebugInfo:false,
lmsType:0,
sendScoreAsPercent:true,
trackingLevel:0,
slideViewPercentage:100,
reportingOption:1,
slideViewsForSuccess:0,
slideViewsTypeForSuccess:0,
slideViewsForCompletion:0,
slideViewsTypeForCompletion:0,
quizCriteriaForCompletion:1,
quizCriteriaForSuccess:1,
completionCriteria:4,
successCriteria:4,
companyName:'',
departmentName:'',
courseName:'',
courseNode:'',
isTrackedFlag:false,
trackingUrlEncodeVersionAndSession:0,
commitDataOnEverySlide:false,
trackingSendResumeData:true,
cmiExitNormalAfterCompletion:false,
lmsInitializationString:'cp.movie.playbackController.SetLMSType();cp.movie.playbackController.SetSendScoreAsPercent();cp.movie.playbackController.SetTrackingLevel();cp.movie.playbackController.SetSlideViewPercentage();cp.movie.playbackController.SetReportingOption();cp.movie.playbackController.SetSlideViewsForSuccess();cp.movie.playbackController.SetSlideViewsForCompletion();cp.movie.playbackController.SetQuizCriteriaForCompletion();cp.movie.playbackController.SetQuizCriteriaForSuccess();cp.movie.playbackController.SetCompletionCriteria();cp.movie.playbackController.SetSuccessCriteria();cp.movie.playbackController.SetDirectory();cp.movie.playbackController.SetCourseNode();cp.movie.playbackController.SetIsTrackedFlag();cp.movie.playbackController.SetTrackingUrlEncodeVersionAndSession();cp.movie.playbackController.SetCommitDataOnEverySlide();cp.movie.playbackController.SetTrackingSendResumeData();cp.movie.playbackController.SetCmiExitNormalAfterCompletion();'
},
var346var346:{
vid:346,
name:'LMS.LearnerID',
vv:'',
vvt:2,
vt:0
},
var347var347:{
vid:347,
name:'LMS.LearnerName',
vv:'',
vvt:2,
vt:0
},
var348var348:{
vid:348,
name:'LMS.CourseName',
vv:'',
vvt:2,
vt:0
},
var349var349:{
vid:349,
name:'Project.ClosedCaptions',
vv:1,
vvt:0,
vt:9
},
var350var350:{
vid:350,
name:'Project.MuteAudio',
vv:0,
vvt:0,
vt:9
},
var351var351:{
vid:351,
name:'Project.ShowPlaybar',
vv:1,
vvt:0,
vt:9
},
var352var352:{
vid:352,
name:'Project.ShowTOC',
vv:0,
vvt:0,
vt:9
},
var353var353:{
vid:353,
name:'Project.AudioLevel',
vv:100,
vvt:1,
vt:9
},
var354var354:{
vid:354,
name:'Project.LockTOC',
vv:0,
vvt:0,
vt:9
},
var355var355:{
vid:355,
name:'Project.CurrentSlideNumber',
vv:1,
vvt:1,
vt:9
},
var356var356:{
vid:356,
name:'Project.CurrentSlideName',
vv:'slide',
vvt:2,
vt:9
},
var357var357:{
vid:357,
name:'Project.SlideCount',
vv:1,
vvt:1,
vt:9
},
var358var358:{
vid:358,
name:'Date.Today',
vv:'dd',
vvt:3,
vt:5
},
var359var359:{
vid:359,
name:'Date.DateMMDDYY',
vv:'mm/dd/yyyy',
vvt:3,
vt:5
},
var360var360:{
vid:360,
name:'Date.DateDDMMYY',
vv:'dd/mm/yyyy',
vvt:3,
vt:5
},
var361var361:{
vid:361,
name:'Date.Day',
vv:'1',
vvt:3,
vt:5
},
var362var362:{
vid:362,
name:'Date.Hours',
vv:'hh',
vvt:3,
vt:5
},
var363var363:{
vid:363,
name:'Date.LocaleString',
vv:'',
vvt:3,
vt:5
},
var364var364:{
vid:364,
name:'Date.Minutes',
vv:'mm',
vvt:3,
vt:5
},
var365var365:{
vid:365,
name:'Date.Month',
vv:'mm',
vvt:3,
vt:5
},
var366var366:{
vid:366,
name:'Date.Time',
vv:'hh:mm:ss',
vvt:3,
vt:5
},
var367var367:{
vid:367,
name:'Date.Year',
vv:'yyyy',
vvt:3,
vt:5
},
var368var368:{
vid:368,
name:'Quiz.InScope',
vv:0,
vvt:0,
vt:7
},
var369var369:{
vid:369,
name:'Quiz.InReview',
vv:0,
vvt:0,
vt:7
},
var370var370:{
vid:370,
name:'Quiz.PercentageScore',
vv:'0',
vvt:2,
vt:7
},
var371var371:{
vid:371,
name:'Quiz.AttemptCount',
vv:0,
vvt:1,
vt:7
},
var372var372:{
vid:372,
name:'Quiz.Pass',
vv:0,
vvt:0,
vt:7
},
var373var373:{
vid:373,
name:'Quiz.Score',
vv:0,
vvt:1,
vt:7
},
var374var374:{
vid:374,
name:'Quiz.PassPercentage',
vv:80,
vvt:1,
vt:7
},
var375var375:{
vid:375,
name:'Quiz.PassPoints',
vv:0,
vvt:1,
vt:7
},
var376var376:{
vid:376,
name:'Quiz.CorrectAnswerCount',
vv:0,
vvt:1,
vt:7
},
var377var377:{
vid:377,
name:'Quiz.MaxScore',
vv:0,
vvt:1,
vt:7
},
var378var378:{
vid:378,
name:'Quiz.QuestionCount',
vv:0,
vvt:1,
vt:7
},
var379var379:{
vid:379,
name:'Quiz.UnansweredQuestionCount',
vv:0,
vvt:1,
vt:7
},
var380var380:{
vid:380,
name:'Question.AnswerChoice',
vv:'',
vvt:2,
vt:7
},
var381var381:{
vid:381,
name:'Question.PreviousQuestionScore',
vv:0,
vvt:1,
vt:7
},
var382var382:{
vid:382,
name:'Question.MaxAttempts',
vv:0,
vvt:1,
vt:7
},
var383var383:{
vid:383,
name:'Question.NegativePoints',
vv:0,
vvt:1,
vt:7
},
var384var384:{
vid:384,
name:'Question.PointsAssigned',
vv:0,
vvt:1,
vt:7
},
var3299var3299:{
vid:3299,
name:'variableEditBoxStr_1',
vv:'',
vvt:2,
vt:0
},
variableIdVsNameMap:{
var346:'LMS.LearnerID',
var347:'LMS.LearnerName',
var348:'LMS.CourseName',
var349:'Project.ClosedCaptions',
var350:'Project.MuteAudio',
var351:'Project.ShowPlaybar',
var352:'Project.ShowTOC',
var353:'Project.AudioLevel',
var354:'Project.LockTOC',
var355:'Project.CurrentSlideNumber',
var356:'Project.CurrentSlideName',
var357:'Project.SlideCount',
var358:'Date.Today',
var359:'Date.DateMMDDYY',
var360:'Date.DateDDMMYY',
var361:'Date.Day',
var362:'Date.Hours',
var363:'Date.LocaleString',
var364:'Date.Minutes',
var365:'Date.Month',
var366:'Date.Time',
var367:'Date.Year',
var368:'Quiz.InScope',
var369:'Quiz.InReview',
var370:'Quiz.PercentageScore',
var371:'Quiz.AttemptCount',
var372:'Quiz.Pass',
var373:'Quiz.Score',
var374:'Quiz.PassPercentage',
var375:'Quiz.PassPoints',
var376:'Quiz.CorrectAnswerCount',
var377:'Quiz.MaxScore',
var378:'Quiz.QuestionCount',
var379:'Quiz.UnansweredQuestionCount',
var380:'Question.AnswerChoice',
var381:'Question.PreviousQuestionScore',
var382:'Question.MaxAttempts',
var383:'Question.NegativePoints',
var384:'Question.PointsAssigned',
var3299:'variableEditBoxStr_1'
},
project:{
fps:30,
hasTOC:1,
hasCC:false,
showClosedCaptions:true,
w:1380,
h:984,
iw:1380,
ih:984,
prm:[1,1,0,0],
stateNameToLocalizedStateNameMap:{
kCPNormalState:'Normal',
kCPDownState:'Click',
kCPRolloverState:'Hover',
kCPVisitedState:'Visited',
kCPDragoverState:'',
kCPDragstartState:'',
kCPDropCorrect:'',
kCPDropIncorrect:'',
kCPDropAccept:'',
kCPDropReject:''
}
,
prjBgColor:'#ffffff',
pkt:1,
htmlBgColor:'#f5f4f1',
shc:false,
pN:'untitled_demo1.cpt'
},
projectThemeData:{
image_presets:'{\
  "theme_image_default": {\
    "meta": {\
      "name": "kCPImageStyleNormal",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_default--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_default--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Normal",\
        "mixBlendMode": "normal"\
      }\
    }\
  },\
\
  "theme_image_greyscale": {\
    "meta": {\
      "name": "kCPImageStyleGreyscale",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_greyscale--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_greyscale--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Greyscale",\
        "mixBlendMode": "saturation",\
        "intensity": "var(--theme_image_greyscale--intensity)",\
        "filterColor": {\
          "fill": "#000000",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_lighten": {\
    "meta": {\
      "name": "kCPImageStyleLighten",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_lighten--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_lighten--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Lighten",\
        "mixBlendMode": "soft-light",\
        "intensity": "var(--theme_image_lighten--intensity)",\
        "filterColor": {\
          "fill": "#FFFFFF",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_darken": {\
    "meta": {\
      "name": "kCPImageStyleDarken",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_darken--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_darken--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Darken",\
        "mixBlendMode": "soft-light",\
        "intensity": "var(--theme_image_darken--intensity)",\
        "filterColor": {\
          "fill": "var(--black)",\
          "fillOpacity": 1\
        }\
      }\
    }\
  },\
\
  "theme_image_overlay": {\
    "meta": {\
      "name": "kCPImageStyleOverlay",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_overlay--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_overlay--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Overlay",\
        "mixBlendMode": "overlay",\
        "intensity": "var(--theme_image_overlay--intensity)",\
        "filterColor": {\
          "fill": "var(--theme_image_overlay--primaryFillColor)",\
          "fillOpacity": 1,\
          "gradientProps": {\
            "linearGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 0 },\
                { "x": 50, "y": 100 }\
              ]\
            },\
            "radialGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 50 },\
                { "x": 100, "y": 50 }\
              ],\
              "radialHandlePoints": [\
                { "x": 50, "y": 100 },\
                { "x": 100, "y": 100 }\
              ]\
            }\
          }\
        }\
      }\
    }\
  },\
\
  "theme_image_colorize": {\
    "meta": {\
      "name": "kCPImageStyleColorize",\
      "type": 2,\
      "fillEnable": 1,\
      "fillType": 1,\
      "borderEnable": 0,\
      "shadowEnable": 0\
    },\
    "styles": {\
      "border": {\
        "color": "var(--theme_image_colorize--strokeColor)",\
        "size": 1,\
        "type": 0,\
        "style": 0\
      },\
      "boxShadow": {\
        "shadowXOffset": 1,\
        "shadowYOffset": 2,\
        "shadowBlur": 4,\
        "color": "var(--theme_image_colorize--boxShadowColor)"\
      },\
      "imageFilter": {\
        "filterType": "Colorize",\
        "mixBlendMode": "color",\
        "intensity": "var(--theme_image_colorize--intensity)",\
        "filterColor": {\
          "fill": "var(--theme_image_colorize--primaryFillColor)",\
          "fillOpacity": 1,\
          "gradientProps": {\
            "linearGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 0 },\
                { "x": 50, "y": 100 }\
              ]\
            },\
            "radialGradientProps": {\
              "colorStops": [\
                {\
                  "color": "#378ef0",\
                  "alpha": 1,\
                  "scaledPosition": 0\
                },\
                {\
                  "color": "#1c4778",\
                  "alpha": 1,\
                  "scaledPosition": 1\
                }\
              ],\
              "endPoints": [\
                { "x": 50, "y": 50 },\
                { "x": 100, "y": 50 }\
              ],\
              "radialHandlePoints": [\
                { "x": 50, "y": 100 },\
                { "x": 100, "y": 100 }\
              ]\
            }\
          }\
        }\
      }\
    }\
  }\
}\
',
meta:'{\
  "name": "kCPThemeLight",\
  "description": "kCPThemeLightDescription",\
  "version": 0.1,\
  "guid": "Default-Light-Theme",\
  "default_presets": {\
    "0": "cp_default_shape_solid_style",\
    "1": "text-body-1",\
    "2": "theme_image_default",\
    "3": "cp_default_slide_style",\
    "4": "cp_textinshape_body_1",\
    "5": "cp_default_line_shape_style",\
    "6": "cp_default_complex_shape_solid_style",\
    "7": "cp_button_style_1_textonly",\
    "8": "cp_checkbox_style_1_textonly",\
    "9": "cp_svg_style",\
    "10": "cp_dropDown_style_1",\
    "11": "cp_radiobutton_style_1_textonly",\
    "12": "cp_inputField_style_1",\
    "13": "cp_clickbox_style",\
    "14": "cp_responsive_container_style",\
    "15": "cp_default_shape_solid_style"\
  },\
  "color_palettes": [\
    {\
      "name": "Light Palette - 1",\
      "colors": [\
        "var(--color1)",\
        "var(--color2)",\
        "var(--color3)",\
        "var(--color4)",\
        "var(--color5)",\
        "var(--color6)",\
        "var(--color7)",\
        "var(--color5_light)",\
        "var(--color4_dark)"\
      ]\
    }\
  ],\
  "active_color_palette": 0\
}',
other_presets:'{\
  "cp_default_slide_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "type": 3,\
      "category": 0\
    },\
    "backgroundColor": "var(--palette-color1)",\
    "outlineColor": "var(--palette-color5)",\
    "outlineWidth": 1,\
    "outlineStyle": "solid",\
    "outlineCap": "butt",\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color2)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 0,\
            "y": 0\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color2)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_responsive_container_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 14,\
      "category": 0\
    },\
    "fill": "var(--palette-color6)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": 1,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_correct": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--success)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_incorrect": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--error)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_incomplete": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--incomplete)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_hint": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--hint)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_retry": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--retry)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_caption_shape_solid_style_timeout": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--timeout)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color6)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color1)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_linear_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_default_shape_radial_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 0,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color1)",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  }\
}',
theme:'{\
  "--primary": "#F1EEE6",\
\
  "--color1": "#FFFFFF",\
  "--color2": "#F8F7F4",\
  "--color3": "#F1EEE6",\
  "--color4": "#D6D5D1",\
  "--color5": "#666666",\
  "--color6": "#333333",\
  "--color7": "#020C1C",\
  "--colorC7": "#F7F7F7",\
  "--disabledC12": "#989898",\
  "--color1_light": "#FFCD74",\
  "--color1_dark": "#C76D12",\
  "--color2_light": "#86FFFF",\
  "--color2_dark": "#00ACCC",\
  "--color3_light": "#9B5DFF",\
  "--color3_dark": "#0000CA",\
  "--color4_light": "#99FF99",\
  "--color4_dark": "#112FA7",\
  "--color5_light": "#163EE5",\
  "--color5_dark": "#00CB92",\
  "--color6_light": "#7697FF",\
  "--color6_dark": "#0040CB",\
  "--color7_light": "#FF8E64",\
  "--color7_dark": "#C5230B",\
\
  "--success": "#558564",\
  "--error": "#C83E4D",\
  "--hint": "#CB6F10",\
  "--incomplete":"#E8BD2B",\
  "--timeout": "#C74545",\
  "--retry": "#CB6F10",\
  "--white": "#ffffff",\
  "--black": "#000000",\
\
  "--greyscale1": "#FFFFFF",\
  "--greyscale2": "#F1EEE61F",\
  "--greyscale3": "#B3B3B3",\
  "--greyscale4": "#4B4B4B",\
  "--greyscale5": "#333333",\
  "--disabled": "#818181",\
\
  "--palette-color0": "var(--color1)",\
  "--palette-color1": "var(--color2)",\
  "--palette-color2": "var(--color3)",\
  "--palette-color3": "var(--color4)",\
  "--palette-color4": "var(--color5)",\
  "--palette-color5": "var(--color6)",\
  "--palette-color6": "var(--color7)",\
  "--palette-color7": "var(--color5_light)",\
  "--palette-color8": "var(--color4_dark)",\
\
  "--design-option-color1": "255, 255, 255",\
  "--design-option-color2": "248, 247, 244",\
  "--design-option-color3": "241, 238, 230",\
  "--design-option-color4": "214, 213, 209",\
  "--design-option-color5": "102, 102, 102",\
  "--design-option-color6": "51, 51, 51",\
  "--design-option-color7": "2, 12, 28",\
  "--design-option-color5_light": "22, 62, 229",\
  "--design-option-color4_dark": "17, 47, 167",\
\
  "--c1": "var(--design-option-color1)",\
  "--c2": "var(--design-option-color2)",\
  "--c3": "var(--design-option-color3)",\
  "--c4": "var(--design-option-color4)",\
  "--c5": "var(--design-option-color5)",\
  "--c6": "var(--design-option-color6)",\
  "--c7": "var(--design-option-color7)",\
  "--c8": "var(--design-option-color5_light)",\
  "--c9": "var(--design-option-color4_dark)",\
  \
  "--widget-container--fillcolor": "var(--palette-color1)",\
\
  "--font1": "Georgia",\
  "--font2": "Arial",\
  "--text-style-unset": "none",\
\
  "--text-heading-1--fontSize--desktop": "120px",\
  "--text-heading-1--fontSize--tablet": "100px",\
  "--text-heading-1--fontSize--mobile": "80px",\
  "--text-heading-1--fontFamily": "var(--font1)",\
  "--text-heading-1--fontWeight": "normal",\
  "--text-heading-1--fontType": "regular",\
  "--text-heading-1--fontStyle": "normal",\
  "--text-heading-1--fontStretch": "normal",\
  "--text-heading-1--lineHeight": "1.07",\
  "--text-heading-1--marginLeft": "0px",\
  "--text-heading-1--color": "var(--palette-color6)",\
  "--text-heading-1--borderBottomStyle": "none",\
  "--text-heading-1--textDecoration": "none",\
  "--text-heading-1--letterSpacing": "-0.01",\
  "--text-heading-1--textTransform": "none",\
  "--text-heading-1--stroke": "var(--palette-color2)",\
  "--text-heading-1--textAlign": "left",\
  "--text-heading-1--justifyContent": "flex-start",\
  "--text-heading-1--marginTop": "auto",\
  "--text-heading-1--marginBottom": "0",\
  "--text-heading-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-1--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-2--fontSize--desktop": "80px",\
  "--text-heading-2--fontSize--tablet": "72px",\
  "--text-heading-2--fontSize--mobile": "60px",\
  "--text-heading-2--fontFamily": "var(--font1)",\
  "--text-heading-2--fontWeight": "normal",\
  "--text-heading-2--fontType": "regular",\
  "--text-heading-2--fontStyle": "normal",\
  "--text-heading-2--fontStretch": "normal",\
  "--text-heading-2--lineHeight": "1.1",\
  "--text-heading-2--marginLeft": "0px",\
  "--text-heading-2--color": "var(--palette-color6)",\
  "--text-heading-2--borderBottomStyle": "none",\
  "--text-heading-2--textDecoration": "none",\
  "--text-heading-2--letterSpacing": "-0.04",\
  "--text-heading-2--textTransform": "none",\
  "--text-heading-2--stroke": "var(--palette-color2)",\
  "--text-heading-2--textAlign": "left",\
  "--text-heading-2--justifyContent": "flex-start",\
  "--text-heading-2--marginTop": "auto",\
  "--text-heading-2--marginBottom": "0",\
  "--text-heading-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-2--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-3--fontSize--desktop": "60px",\
  "--text-heading-3--fontSize--tablet": "52px",\
  "--text-heading-3--fontSize--mobile": "44px",\
  "--text-heading-3--fontFamily": "var(--font1)",\
  "--text-heading-3--fontWeight": "normal",\
  "--text-heading-3--fontType": "regular",\
  "--text-heading-3--fontStyle": "normal",\
  "--text-heading-3--fontStretch": "normal",\
  "--text-heading-3--lineHeight": "1.1",\
  "--text-heading-3--marginLeft": "0px",\
  "--text-heading-3--color": "var(--palette-color6)",\
  "--text-heading-3--borderBottomStyle": "none",\
  "--text-heading-3--textDecoration": "none",\
  "--text-heading-3--letterSpacing": "0.03",\
  "--text-heading-3--textTransform": "none",\
  "--text-heading-3--stroke": "var(--palette-color2)",\
  "--text-heading-3--textAlign": "left",\
  "--text-heading-3--justifyContent": "flex-start",\
  "--text-heading-3--marginTop": "auto",\
  "--text-heading-3--marginBottom": "0",\
  "--text-heading-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-3--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-4--fontSize--desktop": "52px",\
  "--text-heading-4--fontSize--tablet": "40px",\
  "--text-heading-4--fontSize--mobile": "32px",\
  "--text-heading-4--fontFamily": "var(--font1)",\
  "--text-heading-4--fontWeight": "normal",\
  "--text-heading-4--fontType": "regular",\
  "--text-heading-4--fontStyle": "normal",\
  "--text-heading-4--fontStretch": "normal",\
  "--text-heading-4--lineHeight": "1.15",\
  "--text-heading-4--marginLeft": "0px",\
  "--text-heading-4--color": "var(--palette-color6)",\
  "--text-heading-4--borderBottomStyle": "none",\
  "--text-heading-4--textDecoration": "none",\
  "--text-heading-4--letterSpacing": "0.10",\
  "--text-heading-4--textTransform": "uppercase",\
  "--text-heading-4--stroke": "var(--palette-color2)",\
  "--text-heading-4--textAlign": "left",\
  "--text-heading-4--justifyContent": "flex-start",\
  "--text-heading-4--marginTop": "auto",\
  "--text-heading-4--marginBottom": "0",\
  "--text-heading-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-4--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-5--fontSize--desktop": "40px",\
  "--text-heading-5--fontSize--tablet": "32px",\
  "--text-heading-5--fontSize--mobile": "28px",\
  "--text-heading-5--fontFamily": "var(--font1)",\
  "--text-heading-5--fontWeight": "normal",\
  "--text-heading-5--fontType": "regular",\
  "--text-heading-5--fontStyle": "normal",\
  "--text-heading-5--fontStretch": "normal",\
  "--text-heading-5--lineHeight": "1.2",\
  "--text-heading-5--marginLeft": "0px",\
  "--text-heading-5--color": "var(--palette-color6)",\
  "--text-heading-5--borderBottomStyle": "none",\
  "--text-heading-5--textDecoration": "none",\
  "--text-heading-5--letterSpacing": "0",\
  "--text-heading-5--textTransform": "none",\
  "--text-heading-5--stroke": "var(--palette-color2)",\
  "--text-heading-5--textAlign": "left",\
  "--text-heading-5--justifyContent": "flex-start",\
  "--text-heading-5--marginTop": "auto",\
  "--text-heading-5--marginBottom": "0",\
  "--text-heading-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-5--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-6--fontSize--desktop": "36px",\
  "--text-heading-6--fontSize--tablet": "28px",\
  "--text-heading-6--fontSize--mobile": "24px",\
  "--text-heading-6--fontFamily": "var(--font2)",\
  "--text-heading-6--fontWeight": "normal",\
  "--text-heading-6--fontType": "regular",\
  "--text-heading-6--fontStyle": "normal",\
  "--text-heading-6--fontStretch": "normal",\
  "--text-heading-6--lineHeight": "1.2",\
  "--text-heading-6--marginLeft": "0px",\
  "--text-heading-6--color": "var(--palette-color6)",\
  "--text-heading-6--borderBottomStyle": "none",\
  "--text-heading-6--textDecoration": "none",\
  "--text-heading-6--letterSpacing": "0",\
  "--text-heading-6--textTransform": "none",\
  "--text-heading-6--stroke": "var(--palette-color2)",\
  "--text-heading-6--textAlign": "left",\
  "--text-heading-6--justifyContent": "flex-start",\
  "--text-heading-6--marginTop": "auto",\
  "--text-heading-6--marginBottom": "0",\
  "--text-heading-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-6--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-7--fontSize--desktop": "20px",\
  "--text-heading-7--fontSize--tablet": "20px",\
  "--text-heading-7--fontSize--mobile": "20px",\
  "--text-heading-7--fontFamily": "var(--font1)",\
  "--text-heading-7--fontWeight": "normal",\
  "--text-heading-7--fontType": "regular",\
  "--text-heading-7--fontStyle": "normal",\
  "--text-heading-7--fontStretch": "normal",\
  "--text-heading-7--lineHeight": "1.35",\
  "--text-heading-7--marginLeft": "0px",\
  "--text-heading-7--color": "var(--palette-color5)",\
  "--text-heading-7--borderBottomStyle": "none",\
  "--text-heading-7--textDecoration": "none",\
  "--text-heading-7--letterSpacing": "0",\
  "--text-heading-7--textTransform": "none",\
  "--text-heading-7--stroke": "var(--palette-color2)",\
  "--text-heading-7--textAlign": "left",\
  "--text-heading-7--justifyContent": "flex-start",\
  "--text-heading-7--marginTop": "auto",\
  "--text-heading-7--marginBottom": "0",\
  "--text-heading-7--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-7--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-7--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-7--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-8--fontSize--desktop": "72px",\
  "--text-heading-8--fontSize--tablet": "48px",\
  "--text-heading-8--fontSize--mobile": "32px",\
  "--text-heading-8--fontFamily": "var(--font1)",\
  "--text-heading-8--fontWeight": "normal",\
  "--text-heading-8--fontType": "regular",\
  "--text-heading-8--fontStyle": "normal",\
  "--text-heading-8--fontStretch": "normal",\
  "--text-heading-8--lineHeight": "1.35",\
  "--text-heading-8--marginLeft": "0px",\
  "--text-heading-8--color": "var(--palette-color5)",\
  "--text-heading-8--borderBottomStyle": "none",\
  "--text-heading-8--textDecoration": "none",\
  "--text-heading-8--letterSpacing": "0",\
  "--text-heading-8--textTransform": "none",\
  "--text-heading-8--stroke": "var(--palette-color2)",\
  "--text-heading-8--textAlign": "center",\
  "--text-heading-8--justifyContent": "flex-start",\
  "--text-heading-8--marginTop": "auto",\
  "--text-heading-8--marginBottom": "0",\
  "--text-heading-8--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-8--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-8--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-8--textShadow": "var(--text-style-unset)",\
\
  "--text-heading-9--fontSize--desktop": "32px",\
  "--text-heading-9--fontSize--tablet": "32px",\
  "--text-heading-9--fontSize--mobile": "32px",\
  "--text-heading-9--fontFamily": "var(--font1)",\
  "--text-heading-9--fontWeight": "normal",\
  "--text-heading-9--fontType": "regular",\
  "--text-heading-9--fontStyle": "normal",\
  "--text-heading-9--fontStretch": "normal",\
  "--text-heading-9--lineHeight": "1.35",\
  "--text-heading-9--marginLeft": "0px",\
  "--text-heading-9--color": "var(--palette-color5)",\
  "--text-heading-9--borderBottomStyle": "none",\
  "--text-heading-9--textDecoration": "none",\
  "--text-heading-9--letterSpacing": "0",\
  "--text-heading-9--textTransform": "none",\
  "--text-heading-9--stroke": "var(--palette-color2)",\
  "--text-heading-9--textAlign": "center",\
  "--text-heading-9--justifyContent": "flex-start",\
  "--text-heading-9--marginTop": "auto",\
  "--text-heading-9--marginBottom": "0",\
  "--text-heading-9--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-heading-9--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-heading-9--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-heading-9--textShadow": "var(--text-style-unset)",\
\
  "--text-body-1--fontSize--desktop": "22px",\
  "--text-body-1--fontSize--tablet": "20px",\
  "--text-body-1--fontSize--mobile": "18px",\
  "--text-body-1--fontFamily": "var(--font1)",\
  "--text-body-1--fontWeight": "normal",\
  "--text-body-1--fontType": "regular",\
  "--text-body-1--fontStyle": "normal",\
  "--text-body-1--fontStretch": "normal",\
  "--text-body-1--lineHeight": "1.3",\
  "--text-body-1--marginLeft": "0px",\
  "--text-body-1--color": "var(--palette-color5)",\
  "--text-body-1--borderBottomStyle": "none",\
  "--text-body-1--textDecoration": "none",\
  "--text-body-1--letterSpacing": "0",\
  "--text-body-1--textTransform": "none",\
  "--text-body-1--stroke": "var(--palette-color2)",\
  "--text-body-1--textAlign": "left",\
  "--text-body-1--justifyContent": "flex-start",\
  "--text-body-1--marginTop": "auto",\
  "--text-body-1--marginBottom": "0",\
  "--text-body-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-1--textShadow": "var(--text-style-unset)",\
\
  "--text-body-2--fontSize--desktop": "22px",\
  "--text-body-2--fontSize--tablet": "20px",\
  "--text-body-2--fontSize--mobile": "18px",\
  "--text-body-2--fontFamily": "var(--font2)",\
  "--text-body-2--fontWeight": "normal",\
  "--text-body-2--fontType": "regular",\
  "--text-body-2--fontStyle": "normal",\
  "--text-body-2--fontStretch": "normal",\
  "--text-body-2--lineHeight": "1.3",\
  "--text-body-2--marginLeft": "0px",\
  "--text-body-2--color": "var(--palette-color4)",\
  "--text-body-2--borderBottomStyle": "none",\
  "--text-body-2--textDecoration": "none",\
  "--text-body-2--letterSpacing": "0.03",\
  "--text-body-2--textTransform": "none",\
  "--text-body-2--Stroke": "var(--palette-color2)",\
  "--text-body-2--textAlign": "left",\
  "--text-body-2--justifyContent": "flex-start",\
  "--text-body-2--marginTop": "auto",\
  "--text-body-2--marginBottom": "0",\
  "--text-body-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-2--textShadow": "var(--text-style-unset)",\
\
  "--text-body-3--fontSize--desktop": "18px",\
  "--text-body-3--fontSize--tablet": "16px",\
  "--text-body-3--fontSize--mobile": "16px",\
  "--text-body-3--fontFamily": "var(--font1)",\
  "--text-body-3--fontWeight": "normal",\
  "--text-body-3--fontType": "regular",\
  "--text-body-3--fontStyle": "normal",\
  "--text-body-3--fontStretch": "normal",\
  "--text-body-3--lineHeight": "1.35",\
  "--text-body-3--marginLeft": "0px",\
  "--text-body-3--color": "var(--palette-color4)",\
  "--text-body-3--borderBottomStyle": "none",\
  "--text-body-3--textDecoration": "none",\
  "--text-body-3--letterSpacing": "0",\
  "--text-body-3--textTransform": "none",\
  "--text-body-3--Stroke": "var(--palette-color2)",\
  "--text-body-3--textAlign": "left",\
  "--text-body-3--justifyContent": "flex-start",\
  "--text-body-3--marginTop": "auto",\
  "--text-body-3--marginBottom": "0",\
  "--text-body-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-3--textShadow": "var(--text-style-unset)",\
\
  "--text-body-4--fontSize--desktop": "18px",\
  "--text-body-4--fontSize--tablet": "16px",\
  "--text-body-4--fontSize--mobile": "16px",\
  "--text-body-4--fontFamily": "var(--font2)",\
  "--text-body-4--fontWeight": "normal",\
  "--text-body-4--fontType": "regular",\
  "--text-body-4--fontStyle": "normal",\
  "--text-body-4--fontStretch": "normal",\
  "--text-body-4--lineHeight": "1.35",\
  "--text-body-4--marginLeft": "0px",\
  "--text-body-4--color": "var(--palette-color4)",\
  "--text-body-4--borderBottomStyle": "none",\
  "--text-body-4--textDecoration": "none",\
  "--text-body-4--letterSpacing": "0",\
  "--text-body-4--textTransform": "none",\
  "--text-body-4--Stroke": "var(--palette-color2)",\
  "--text-body-4--textAlign": "left",\
  "--text-body-4--justifyContent": "flex-start",\
  "--text-body-4--marginTop": "auto",\
  "--text-body-4--marginBottom": "0",\
  "--text-body-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-4--textShadow": "var(--text-style-unset)",\
\
  "--text-body-5--fontSize--desktop": "18px",\
  "--text-body-5--fontSize--tablet": "16px",\
  "--text-body-5--fontSize--mobile": "16px",\
  "--text-body-5--fontFamily": "var(--font1)",\
  "--text-body-5--fontWeight": "normal",\
  "--text-body-5--fontType": "italic",\
  "--text-body-5--fontStyle": "normal",\
  "--text-body-5--fontStretch": "normal",\
  "--text-body-5--lineHeight": "1.35",\
  "--text-body-5--marginLeft": "0px",\
  "--text-body-5--color": "var(--palette-color4)",\
  "--text-body-5--borderBottomStyle": "none",\
  "--text-body-5--textDecoration": "none",\
  "--text-body-5--letterSpacing": "0",\
  "--text-body-5--textTransform": "none",\
  "--text-body-5--Stroke": "var(--palette-color2)",\
  "--text-body-5--textAlign": "center",\
  "--text-body-5--justifyContent": "flex-start",\
  "--text-body-5--marginTop": "auto",\
  "--text-body-5--marginBottom": "0",\
  "--text-body-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-5--textShadow": "var(--text-style-unset)",\
\
  "--text-body-6--fontSize--desktop": "16px",\
  "--text-body-6--fontSize--tablet": "14px",\
  "--text-body-6--fontSize--mobile": "14px",\
  "--text-body-6--fontFamily": "var(--font2)",\
  "--text-body-6--fontWeight": "normal",\
  "--text-body-6--fontType": "regular",\
  "--text-body-6--fontStyle": "normal",\
  "--text-body-6--fontStretch": "normal",\
  "--text-body-6--lineHeight": "1.35",\
  "--text-body-6--marginLeft": "0px",\
  "--text-body-6--color": "var(--palette-color4)",\
  "--text-body-6--borderBottomStyle": "none",\
  "--text-body-6--textDecoration": "none",\
  "--text-body-6--letterSpacing": "0",\
  "--text-body-6--textTransform": "none",\
  "--text-body-6--Stroke": "var(--palette-color2)",\
  "--text-body-6--textAlign": "left",\
  "--text-body-6--justifyContent": "flex-start",\
  "--text-body-6--marginTop": "auto",\
  "--text-body-6--marginBottom": "0",\
  "--text-body-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-body-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-body-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-body-6--textShadow": "var(--text-style-unset)",\
\
  "--text-component-1--fontSize--desktop": "22px",\
  "--text-component-1--fontSize--tablet": "20px",\
  "--text-component-1--fontSize--mobile": "20px",\
  "--text-component-1--fontFamily": "var(--font1)",\
  "--text-component-1--fontWeight": "normal",\
  "--text-component-1--fontType": "regular",\
  "--text-component-1--fontStyle": "normal",\
  "--text-component-1--fontStretch": "normal",\
  "--text-component-1--lineHeight": "1.35",\
  "--text-component-1--marginLeft": "0px",\
  "--text-component-1--color": "var(--color6)",\
  "--text-component-1--borderBottomStyle": "none",\
  "--text-component-1--textDecoration": "none",\
  "--text-component-1--letterSpacing": "0",\
  "--text-component-1--textTransform": "none",\
  "--text-component-1--stroke": "var(--palette-color2)",\
  "--text-component-1--textAlign": "left",\
  "--text-component-1--justifyContent": "flex-start",\
  "--text-component-1--marginTop": "auto",\
  "--text-component-1--marginBottom": "0",\
  "--text-component-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-1--textShadow": "var(--text-style-unset)",\
\
  "--text-component-2--fontSize--desktop": "24px",\
  "--text-component-2--fontSize--tablet": "20px",\
  "--text-component-2--fontSize--mobile": "20px",\
  "--text-component-2--fontFamily": "var(--font1)",\
  "--text-component-2--fontWeight": "normal",\
  "--text-component-2--fontType": "regular",\
  "--text-component-2--fontStyle": "normal",\
  "--text-component-2--fontStretch": "normal",\
  "--text-component-2--lineHeight": "1.35",\
  "--text-component-2--marginLeft": "0px",\
  "--text-component-2--color": "var(--palette-color1)",\
  "--text-component-2--borderBottomStyle": "none",\
  "--text-component-2--textDecoration": "none",\
  "--text-component-2--letterSpacing": "0.16",\
  "--text-component-2--textTransform": "none",\
  "--text-component-2--stroke": "var(--palette-color2)",\
  "--text-component-2--textAlign": "left",\
  "--text-component-2--justifyContent": "flex-start",\
  "--text-component-2--marginTop": "auto",\
  "--text-component-2--marginBottom": "0",\
  "--text-component-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-2--textShadow": "var(--text-style-unset)",\
\
  "--text-component-3--fontSize--desktop": "14px",\
  "--text-component-3--fontSize--tablet": "14px",\
  "--text-component-3--fontSize--mobile": "14px",\
  "--text-component-3--fontFamily": "var(--font1)",\
  "--text-component-3--fontWeight": "normal",\
  "--text-component-3--fontType": "regular",\
  "--text-component-3--fontStyle": "normal",\
  "--text-component-3--fontStretch": "normal",\
  "--text-component-3--lineHeight": "1.35",\
  "--text-component-3--marginLeft": "0px",\
  "--text-component-3--color": "var(--palette-color6)",\
  "--text-component-3--borderBottomStyle": "none",\
  "--text-component-3--textDecoration": "none",\
  "--text-component-3--letterSpacing": "0.2",\
  "--text-component-3--textTransform": "uppercase",\
  "--text-component-3--stroke": "var(--palette-color2)",\
  "--text-component-3--textAlign": "center",\
  "--text-component-3--justifyContent": "flex-start",\
  "--text-component-3--marginTop": "auto",\
  "--text-component-3--marginBottom": "0",\
  "--text-component-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-3--textShadow": "var(--text-style-unset)",\
\
  "--text-component-4--fontSize--desktop": "22px",\
  "--text-component-4--fontSize--tablet": "20px",\
  "--text-component-4--fontSize--mobile": "20px",\
  "--text-component-4--fontFamily": "var(--font1)",\
  "--text-component-4--fontWeight": "normal",\
  "--text-component-4--fontType": "regular",\
  "--text-component-4--fontStyle": "normal",\
  "--text-component-4--fontStretch": "normal",\
  "--text-component-4--lineHeight": "1.35",\
  "--text-component-4--marginLeft": "0px",\
  "--text-component-4--color": "var(--color6)",\
  "--text-component-4--borderBottomStyle": "none",\
  "--text-component-4--textDecoration": "none",\
  "--text-component-4--letterSpacing": "0.02",\
  "--text-component-4--textTransform": "none",\
  "--text-component-4--stroke": "var(--palette-color2)",\
  "--text-component-4--textAlign": "left",\
  "--text-component-4--justifyContent": "flex-start",\
  "--text-component-4--marginTop": "auto",\
  "--text-component-4--marginBottom": "0",\
  "--text-component-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-component-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-component-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-component-4--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-1--fontSize--desktop": "36px",\
  "--text-subheading-1--fontSize--tablet": "32px",\
  "--text-subheading-1--fontSize--mobile": "28px",\
  "--text-subheading-1--fontFamily": "var(--font2)",\
  "--text-subheading-1--fontWeight": "normal",\
  "--text-subheading-1--fontType": "regular",\
  "--text-subheading-1--fontStyle": "normal",\
  "--text-subheading-1--fontStretch": "normal",\
  "--text-subheading-1--lineHeight": "1.1",\
  "--text-subheading-1--marginLeft": "0px",\
  "--text-subheading-1--color": "var(--palette-color6)",\
  "--text-subheading-1--borderBottomStyle": "none",\
  "--text-subheading-1--textDecoration": "none",\
  "--text-subheading-1--letterSpacing": "0.05",\
  "--text-subheading-1--textTransform": "uppercase",\
  "--text-subheading-1--stroke": "var(--palette-color2)",\
  "--text-subheading-1--textAlign": "left",\
  "--text-subheading-1--justifyContent": "flex-start",\
  "--text-subheading-1--marginTop": "auto",\
  "--text-subheading-1--marginBottom": "0",\
  "--text-subheading-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-1--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-2--fontSize--desktop": "28px",\
  "--text-subheading-2--fontSize--tablet": "24px",\
  "--text-subheading-2--fontSize--mobile": "20px",\
  "--text-subheading-2--fontFamily": "var(--font2)",\
  "--text-subheading-2--fontWeight": "normal",\
  "--text-subheading-2--fontType": "bold",\
  "--text-subheading-2--fontStyle": "normal",\
  "--text-subheading-2--fontStretch": "normal",\
  "--text-subheading-2--lineHeight": "1.15",\
  "--text-subheading-2--marginLeft": "0px",\
  "--text-subheading-2--color": "var(--palette-color6)",\
  "--text-subheading-2--borderBottomStyle": "none",\
  "--text-subheading-2--textDecoration": "none",\
  "--text-subheading-2--letterSpacing": "0.05",\
  "--text-subheading-2--textTransform": "none",\
  "--text-subheading-2--stroke": "var(--palette-color2)",\
  "--text-subheading-2--textAlign": "left",\
  "--text-subheading-2--justifyContent": "flex-start",\
  "--text-subheading-2--marginTop": "auto",\
  "--text-subheading-2--marginBottom": "0",\
  "--text-subheading-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-2--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-3--fontSize--desktop": "26px",\
  "--text-subheading-3--fontSize--tablet": "22px",\
  "--text-subheading-3--fontSize--mobile": "18px",\
  "--text-subheading-3--fontFamily": "var(--font2)",\
  "--text-subheading-3--fontWeight": "normal",\
  "--text-subheading-3--fontType": "regular",\
  "--text-subheading-3--fontStyle": "normal",\
  "--text-subheading-3--fontStretch": "normal",\
  "--text-subheading-3--lineHeight": "1.15",\
  "--text-subheading-3--marginLeft": "0px",\
  "--text-subheading-3--color": "var(--palette-color6)",\
  "--text-subheading-3--borderBottomStyle": "none",\
  "--text-subheading-3--textDecoration": "none",\
  "--text-subheading-3--letterSpacing": "0",\
  "--text-subheading-3--textTransform": "none",\
  "--text-subheading-3--stroke": "var(--palette-color2)",\
  "--text-subheading-3--textAlign": "center",\
  "--text-subheading-3--justifyContent": "flex-start",\
  "--text-subheading-3--marginTop": "auto",\
  "--text-subheading-3--marginBottom": "0",\
  "--text-subheading-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-3--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-4--fontSize--desktop": "24px",\
  "--text-subheading-4--fontSize--tablet": "20px",\
  "--text-subheading-4--fontSize--mobile": "16px",\
  "--text-subheading-4--fontFamily": "var(--font2)",\
  "--text-subheading-4--fontWeight": "normal",\
  "--text-subheading-4--fontType": "bold",\
  "--text-subheading-4--fontStyle": "normal",\
  "--text-subheading-4--fontStretch": "normal",\
  "--text-subheading-4--lineHeight": "1.15",\
  "--text-subheading-4--marginLeft": "0px",\
  "--text-subheading-4--color": "var(--palette-color0)",\
  "--text-subheading-4--borderBottomStyle": "none",\
  "--text-subheading-4--textDecoration": "none",\
  "--text-subheading-4--letterSpacing": "0.05",\
  "--text-subheading-4--textTransform": "none",\
  "--text-subheading-4--stroke": "var(--palette-color2)",\
  "--text-subheading-4--textAlign": "left",\
  "--text-subheading-4--justifyContent": "flex-start",\
  "--text-subheading-4--marginTop": "auto",\
  "--text-subheading-4--marginBottom": "0",\
  "--text-subheading-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-4--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-5--fontSize--desktop": "24px",\
  "--text-subheading-5--fontSize--tablet": "20px",\
  "--text-subheading-5--fontSize--mobile": "16px",\
  "--text-subheading-5--fontFamily": "var(--font1)",\
  "--text-subheading-5--fontWeight": "normal",\
  "--text-subheading-5--fontType": "bold",\
  "--text-subheading-5--fontStyle": "normal",\
  "--text-subheading-5--fontStretch": "normal",\
  "--text-subheading-5--lineHeight": "1.15",\
  "--text-subheading-5--marginLeft": "0px",\
  "--text-subheading-5--color": "var(--palette-color5)",\
  "--text-subheading-5--borderBottomStyle": "none",\
  "--text-subheading-5--textDecoration": "none",\
  "--text-subheading-5--letterSpacing": "-0.05",\
  "--text-subheading-5--textTransform": "none",\
  "--text-subheading-5--stroke": "var(--palette-color2)",\
  "--text-subheading-5--textAlign": "left",\
  "--text-subheading-5--justifyContent": "flex-start",\
  "--text-subheading-5--marginTop": "auto",\
  "--text-subheading-5--marginBottom": "0",\
  "--text-subheading-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-5--textShadow": "var(--text-style-unset)",\
\
  "--text-subheading-6--fontSize--desktop": "18px",\
  "--text-subheading-6--fontSize--tablet": "16px",\
  "--text-subheading-6--fontSize--mobile": "14px",\
  "--text-subheading-6--fontFamily": "var(--font2)",\
  "--text-subheading-6--fontWeight": "normal",\
  "--text-subheading-6--fontType": "bold",\
  "--text-subheading-6--fontStyle": "normal",\
  "--text-subheading-6--fontStretch": "normal",\
  "--text-subheading-6--lineHeight": "1.25",\
  "--text-subheading-6--marginLeft": "0px",\
  "--text-subheading-6--color": "var(--palette-color5)",\
  "--text-subheading-6--borderBottomStyle": "none",\
  "--text-subheading-6--textDecoration": "none",\
  "--text-subheading-6--letterSpacing": "0",\
  "--text-subheading-6--textTransform": "none",\
  "--text-subheading-6--stroke": "var(--palette-color2)",\
  "--text-subheading-6--textAlign": "left",\
  "--text-subheading-6--justifyContent": "flex-start",\
  "--text-subheading-6--marginTop": "auto",\
  "--text-subheading-6--marginBottom": "0",\
  "--text-subheading-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-subheading-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-subheading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-subheading-6--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-1--fontSize--desktop": "20px",\
  "--text-detail-1--fontSize--tablet": "18px",\
  "--text-detail-1--fontSize--mobile": "16px",\
  "--text-detail-1--fontFamily": "var(--font2)",\
  "--text-detail-1--fontWeight": "normal",\
  "--text-detail-1--fontType": "regular",\
  "--text-detail-1--fontStyle": "normal",\
  "--text-detail-1--fontStretch": "normal",\
  "--text-detail-1--lineHeight": "1.2",\
  "--text-detail-1--marginLeft": "0px",\
  "--text-detail-1--color": "var(--palette-color6)",\
  "--text-detail-1--borderBottomStyle": "none",\
  "--text-detail-1--textDecoration": "none",\
  "--text-detail-1--letterSpacing": "0",\
  "--text-detail-1--textTransform": "uppercase",\
  "--text-detail-1--stroke": "var(--palette-color5)",\
  "--text-detail-1--textAlign": "left",\
  "--text-detail-1--justifyContent": "flex-start",\
  "--text-detail-1--marginTop": "auto",\
  "--text-detail-1--marginBottom": "0",\
  "--text-detail-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-1--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-2--fontSize--desktop": "16px",\
  "--text-detail-2--fontSize--tablet": "14px",\
  "--text-detail-2--fontSize--mobile": "12px",\
  "--text-detail-2--fontFamily": "var(--font2)",\
  "--text-detail-2--fontWeight": "normal",\
  "--text-detail-2--fontType": "bold",\
  "--text-detail-2--fontStyle": "normal",\
  "--text-detail-2--fontStretch": "normal",\
  "--text-detail-2--lineHeight": "1.3",\
  "--text-detail-2--marginLeft": "0px",\
  "--text-detail-2--color": "var(--palette-color6)",\
  "--text-detail-2--borderBottomStyle": "none",\
  "--text-detail-2--textDecoration": "none",\
  "--text-detail-2--letterSpacing": "0",\
  "--text-detail-2--textTransform": "uppercase",\
  "--text-detail-2--stroke": "var(--palette-color2)",\
  "--text-detail-2--textAlign": "left",\
  "--text-detail-2--justifyContent": "flex-start",\
  "--text-detail-2--marginTop": "auto",\
  "--text-detail-2--marginBottom": "0",\
  "--text-detail-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-2--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-3--fontSize--desktop": "16px",\
  "--text-detail-3--fontSize--tablet": "14px",\
  "--text-detail-3--fontSize--mobile": "12px",\
  "--text-detail-3--fontFamily": "var(--font2)",\
  "--text-detail-3--fontWeight": "normal",\
  "--text-detail-3--fontType": "regular",\
  "--text-detail-3--fontStyle": "normal",\
  "--text-detail-3--fontStretch": "normal",\
  "--text-detail-3--lineHeight": "1.35",\
  "--text-detail-3--marginLeft": "0px",\
  "--text-detail-3--color": "var(--palette-color4)",\
  "--text-detail-3--borderBottomStyle": "none",\
  "--text-detail-3--textDecoration": "none",\
  "--text-detail-3--letterSpacing": "0.2",\
  "--text-detail-3--textTransform": "uppercase",\
  "--text-detail-3--stroke": "var(--palette-color2)",\
  "--text-detail-3--textAlign": "left",\
  "--text-detail-3--justifyContent": "flex-start",\
  "--text-detail-3--marginTop": "auto",\
  "--text-detail-3--marginBottom": "0",\
  "--text-detail-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-3--textShadow": "var(--text-style-unset)",\
\
  "--text-detail-4--fontSize--desktop": "22px",\
  "--text-detail-4--fontSize--tablet": "20px",\
  "--text-detail-4--fontSize--mobile": "20px",\
  "--text-detail-4--fontFamily": "var(--font1)",\
  "--text-detail-4--fontWeight": "normal",\
  "--text-detail-4--fontType": "regular",\
  "--text-detail-4--fontStyle": "normal",\
  "--text-detail-4--fontStretch": "normal",\
  "--text-detail-4--lineHeight": "1.35",\
  "--text-detail-4--marginLeft": "0px",\
  "--text-detail-4--color": "var(--palette-color5)",\
  "--text-detail-4--borderBottomStyle": "none",\
  "--text-detail-4--textDecoration": "none",\
  "--text-detail-4--letterSpacing": "0",\
  "--text-detail-4--textTransform": "none",\
  "--text-detail-4--stroke": "var(--palette-color2)",\
  "--text-detail-4--textAlign": "center",\
  "--text-detail-4--justifyContent": "flex-start",\
  "--text-detail-4--marginTop": "auto",\
  "--text-detail-4--marginBottom": "0",\
  "--text-detail-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-detail-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-detail-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-detail-4--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-1--fontSize--desktop": "36px",\
  "--text-variable-1--fontSize--tablet": "32px",\
  "--text-variable-1--fontSize--mobile": "30px",\
  "--text-variable-1--fontFamily": "var(--font2)",\
  "--text-variable-1--fontWeight": "normal",\
  "--text-variable-1--fontType": "bold",\
  "--text-variable-1--fontStyle": "normal",\
  "--text-variable-1--fontStretch": "normal",\
  "--text-variable-1--lineHeight": "1.2",\
  "--text-variable-1--marginLeft": "0px",\
  "--text-variable-1--color": "var(--palette-color7)",\
  "--text-variable-1--borderBottomStyle": "none",\
  "--text-variable-1--textDecoration": "none",\
  "--text-variable-1--letterSpacing": "0.02",\
  "--text-variable-1--textTransform": "none",\
  "--text-variable-1--stroke": "var(--palette-color2)",\
  "--text-variable-1--textAlign": "left",\
  "--text-variable-1--justifyContent": "flex-start",\
  "--text-variable-1--marginTop": "auto",\
  "--text-variable-1--marginBottom": "0",\
  "--text-variable-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-1--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-2--fontSize--desktop": "24px",\
  "--text-variable-2--fontSize--tablet": "22px",\
  "--text-variable-2--fontSize--mobile": "20px",\
  "--text-variable-2--fontFamily": "var(--font2)",\
  "--text-variable-2--fontWeight": "normal",\
  "--text-variable-2--fontType": "bold",\
  "--text-variable-2--fontStyle": "normal",\
  "--text-variable-2--fontStretch": "normal",\
  "--text-variable-2--lineHeight": "1.15",\
  "--text-variable-2--marginLeft": "0px",\
  "--text-variable-2--color": "var(--palette-color6)",\
  "--text-variable-2--borderBottomStyle": "none",\
  "--text-variable-2--textDecoration": "none",\
  "--text-variable-2--letterSpacing": "0",\
  "--text-variable-2--textTransform": "none",\
  "--text-variable-2--stroke": "var(--palette-color2)",\
  "--text-variable-2--textAlign": "left",\
  "--text-variable-2--justifyContent": "flex-start",\
  "--text-variable-2--marginTop": "auto",\
  "--text-variable-2--marginBottom": "0",\
  "--text-variable-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-2--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-3--fontSize--desktop": "20px",\
  "--text-variable-3--fontSize--tablet": "18px",\
  "--text-variable-3--fontSize--mobile": "16px",\
  "--text-variable-3--fontFamily": "var(--font1)",\
  "--text-variable-3--fontWeight": "normal",\
  "--text-variable-3--fontType": "bold",\
  "--text-variable-3--fontStyle": "normal",\
  "--text-variable-3--fontStretch": "normal",\
  "--text-variable-3--lineHeight": "1.2",\
  "--text-variable-3--marginLeft": "0px",\
  "--text-variable-3--color": "var(--palette-color6)",\
  "--text-variable-3--borderBottomStyle": "none",\
  "--text-variable-3--textDecoration": "none",\
  "--text-variable-3--letterSpacing": "0",\
  "--text-variable-3--textTransform": "none",\
  "--text-variable-3--stroke": "var(--palette-color2)",\
  "--text-variable-3--textAlign": "left",\
  "--text-variable-3--justifyContent": "flex-start",\
  "--text-variable-3--marginTop": "auto",\
  "--text-variable-3--marginBottom": "0",\
  "--text-variable-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-3--textShadow": "var(--text-style-unset)",\
\
  "--text-variable-4--fontSize--desktop": "16px",\
  "--text-variable-4--fontSize--tablet": "14px",\
  "--text-variable-4--fontSize--mobile": "12px",\
  "--text-variable-4--fontFamily": "var(--font2)",\
  "--text-variable-4--fontWeight": "normal",\
  "--text-variable-4--fontType": "bold",\
  "--text-variable-4--fontStyle": "normal",\
  "--text-variable-4--fontStretch": "normal",\
  "--text-variable-4--lineHeight": "1.3",\
  "--text-variable-4--marginLeft": "0px",\
  "--text-variable-4--color": "var(--palette-color6)",\
  "--text-variable-4--borderBottomStyle": "none",\
  "--text-variable-4--textDecoration": "none",\
  "--text-variable-4--letterSpacing": "0.02",\
  "--text-variable-4--textTransform": "none",\
  "--text-variable-4--stroke": "var(--palette-color2)",\
  "--text-variable-4--textAlign": "left",\
  "--text-variable-4--justifyContent": "flex-start",\
  "--text-variable-4--marginTop": "auto",\
  "--text-variable-4--marginBottom": "0",\
  "--text-variable-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-variable-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-variable-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-variable-4--textShadow": "var(--text-style-unset)",\
\
  "--text-question-1--fontSize--desktop": "48px",\
  "--text-question-1--fontSize--tablet": "20px",\
  "--text-question-1--fontSize--mobile": "20px",\
  "--text-question-1--fontFamily": "var(--font1)",\
  "--text-question-1--fontWeight": "normal",\
  "--text-question-1--fontType": "regular",\
  "--text-question-1--fontStyle": "normal",\
  "--text-question-1--fontStretch": "normal",\
  "--text-question-1--lineHeight": "1.35",\
  "--text-question-1--marginLeft": "0px",\
  "--text-question-1--color": "var(--palette-color5)",\
  "--text-question-1--borderBottomStyle": "none",\
  "--text-question-1--textDecoration": "none",\
  "--text-question-1--letterSpacing": "0",\
  "--text-question-1--textTransform": "none",\
  "--text-question-1--stroke": "var(--palette-color2)",\
  "--text-question-1--textAlign": "left",\
  "--text-question-1--justifyContent": "flex-start",\
  "--text-question-1--marginTop": "auto",\
  "--text-question-1--marginBottom": "0",\
  "--text-question-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-question-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-question-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-question-1--textShadow": "var(--text-style-unset)",\
\
  "--text-question-2--fontSize--desktop": "24px",\
  "--text-question-2--fontSize--tablet": "20px",\
  "--text-question-2--fontSize--mobile": "20px",\
  "--text-question-2--fontFamily": "var(--font1)",\
  "--text-question-2--fontWeight": "normal",\
  "--text-question-2--fontType": "bold",\
  "--text-question-2--fontStyle": "normal",\
  "--text-question-2--fontStretch": "normal",\
  "--text-question-2--lineHeight": "1.35",\
  "--text-question-2--marginLeft": "0px",\
  "--text-question-2--color": "var(--palette-color5)",\
  "--text-question-2--borderBottomStyle": "none",\
  "--text-question-2--textDecoration": "none",\
  "--text-question-2--letterSpacing": "0",\
  "--text-question-2--textTransform": "none",\
  "--text-question-2--stroke": "var(--palette-color2)",\
  "--text-question-2--textAlign": "left",\
  "--text-question-2--justifyContent": "flex-start",\
  "--text-question-2--marginTop": "auto",\
  "--text-question-2--marginBottom": "0",\
  "--text-question-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-question-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-question-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-question-2--textShadow": "var(--text-style-unset)",\
\
  "--text-button-1--fontSize--desktop": "16px",\
  "--text-button-1--fontSize--tablet": "16px",\
  "--text-button-1--fontSize--mobile": "16px",\
  "--text-button-1--fontFamily": "var(--font2)",\
  "--text-button-1--fontWeight": "normal",\
  "--text-button-1--fontType": "regular",\
  "--text-button-1--fontStyle": "normal",\
  "--text-button-1--fontStretch": "normal",\
  "--text-button-1--lineHeight": "1.25",\
  "--text-button-1--marginLeft": "0px",\
  "--text-button-1--color": "var(--palette-color7)",\
  "--text-button-1--borderBottomStyle": "none",\
  "--text-button-1--textDecoration": "none",\
  "--text-button-1--letterSpacing": "0.12",\
  "--text-button-1--textTransform": "uppercase",\
  "--text-button-1--stroke": "var(--palette-color2)",\
  "--text-button-1--textAlign": "center",\
  "--text-button-1--justifyContent": "flex-start",\
  "--text-button-1--marginTop": "auto",\
  "--text-button-1--marginBottom": "0",\
  "--text-button-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-1--textShadow": "var(--text-style-unset)",\
\
  "--text-button-2--fontSize--desktop": "16px",\
  "--text-button-2--fontSize--tablet": "16px",\
  "--text-button-2--fontSize--mobile": "16px",\
  "--text-button-2--fontFamily": "var(--font2)",\
  "--text-button-2--fontWeight": "normal",\
  "--text-button-2--fontType": "regular",\
  "--text-button-2--fontStyle": "normal",\
  "--text-button-2--fontStretch": "normal",\
  "--text-button-2--lineHeight": "1.25",\
  "--text-button-2--marginLeft": "0px",\
  "--text-button-2--color": "var(--palette-color0)",\
  "--text-button-2--borderBottomStyle": "none",\
  "--text-button-2--textDecoration": "none",\
  "--text-button-2--letterSpacing": "0.12",\
  "--text-button-2--textTransform": "uppercase",\
  "--text-button-2--stroke": "var(--palette-color2)",\
  "--text-button-2--textAlign": "center",\
  "--text-button-2--justifyContent": "flex-start",\
  "--text-button-2--marginTop": "auto",\
  "--text-button-2--marginBottom": "0",\
  "--text-button-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-2--textShadow": "var(--text-style-unset)",\
\
  "--text-button-3--fontSize--desktop": "16px",\
  "--text-button-3--fontSize--tablet": "16px",\
  "--text-button-3--fontSize--mobile": "16px",\
  "--text-button-3--fontFamily": "var(--font2)",\
  "--text-button-3--fontWeight": "normal",\
  "--text-button-3--fontType": "regular",\
  "--text-button-3--fontStyle": "normal",\
  "--text-button-3--fontStretch": "normal",\
  "--text-button-3--lineHeight": "1.25",\
  "--text-button-3--marginLeft": "0px",\
  "--text-button-3--color": "var(--palette-color5)",\
  "--text-button-3--borderBottomStyle": "none",\
  "--text-button-3--textDecoration": "none",\
  "--text-button-3--letterSpacing": "0.12",\
  "--text-button-3--textTransform": "uppercase",\
  "--text-button-3--stroke": "var(--palette-color2)",\
  "--text-button-3--textAlign": "center",\
  "--text-button-3--justifyContent": "flex-start",\
  "--text-button-3--marginTop": "auto",\
  "--text-button-3--marginBottom": "0",\
  "--text-button-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-3--textShadow": "var(--text-style-unset)",\
\
  "--text-button-4--fontSize--desktop": "16px",\
  "--text-button-4--fontSize--tablet": "16px",\
  "--text-button-4--fontSize--mobile": "16px",\
  "--text-button-4--fontFamily": "var(--font2)",\
  "--text-button-4--fontWeight": "normal",\
  "--text-button-4--fontType": "regular",\
  "--text-button-4--fontStyle": "normal",\
  "--text-button-4--fontStretch": "normal",\
  "--text-button-4--lineHeight": "1.25",\
  "--text-button-4--marginLeft": "0px",\
  "--text-button-4--color": "var(--palette-color4)",\
  "--text-button-4--borderBottomStyle": "none",\
  "--text-button-4--textDecoration": "none",\
  "--text-button-4--letterSpacing": "0.12",\
  "--text-button-4--textTransform": "uppercase",\
  "--text-button-4--stroke": "var(--palette-color2)",\
  "--text-button-4--textAlign": "center",\
  "--text-button-4--justifyContent": "flex-start",\
  "--text-button-4--marginTop": "auto",\
  "--text-button-4--marginBottom": "0",\
  "--text-button-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-button-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-button-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-button-4--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-1--fontSize--desktop": "18px",\
  "--text-uic-1--fontSize--tablet": "18px",\
  "--text-uic-1--fontSize--mobile": "18px",\
  "--text-uic-1--fontFamily": "var(--font1)",\
  "--text-uic-1--fontWeight": "normal",\
  "--text-uic-1--fontType": "italic",\
  "--text-uic-1--fontStyle": "normal",\
  "--text-uic-1--fontStretch": "normal",\
  "--text-uic-1--lineHeight": "1.35",\
  "--text-uic-1--marginLeft": "0px",\
  "--text-uic-1--color": "var(--palette-color4)",\
  "--text-uic-1--borderBottomStyle": "none",\
  "--text-uic-1--textDecoration": "none",\
  "--text-uic-1--letterSpacing": "0",\
  "--text-uic-1--textTransform": "none",\
  "--text-uic-1--stroke": "var(--palette-color2)",\
  "--text-uic-1--textAlign": "left",\
  "--text-uic-1--justifyContent": "flex-start",\
  "--text-uic-1--marginTop": "auto",\
  "--text-uic-1--marginBottom": "0",\
  "--text-uic-1--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-1--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-2--fontSize--desktop": "18px",\
  "--text-uic-2--fontSize--tablet": "18px",\
  "--text-uic-2--fontSize--mobile": "18px",\
  "--text-uic-2--fontFamily": "var(--font1)",\
  "--text-uic-2--fontWeight": "normal",\
  "--text-uic-2--fontType": "italic",\
  "--text-uic-2--fontStyle": "normal",\
  "--text-uic-2--fontStretch": "normal",\
  "--text-uic-2--lineHeight": "1.35",\
  "--text-uic-2--marginLeft": "0px",\
  "--text-uic-2--color": "var(--palette-color1)",\
  "--text-uic-2--borderBottomStyle": "none",\
  "--text-uic-2--textDecoration": "none",\
  "--text-uic-2--letterSpacing": "0",\
  "--text-uic-2--textTransform": "none",\
  "--text-uic-2--stroke": "var(--palette-color2)",\
  "--text-uic-2--textAlign": "left",\
  "--text-uic-2--justifyContent": "flex-start",\
  "--text-uic-2--marginTop": "auto",\
  "--text-uic-2--marginBottom": "0",\
  "--text-uic-2--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-2--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-3--fontSize--desktop": "22px",\
  "--text-uic-3--fontSize--tablet": "22px",\
  "--text-uic-3--fontSize--mobile": "22px",\
  "--text-uic-3--fontFamily": "var(--font1)",\
  "--text-uic-3--fontWeight": "normal",\
  "--text-uic-3--fontType": "regular",\
  "--text-uic-3--fontStyle": "normal",\
  "--text-uic-3--fontStretch": "normal",\
  "--text-uic-3--lineHeight": "1.25",\
  "--text-uic-3--marginLeft": "0px",\
  "--text-uic-3--color": "var(--palette-color5)",\
  "--text-uic-3--borderBottomStyle": "none",\
  "--text-uic-3--textDecoration": "none",\
  "--text-uic-3--letterSpacing": "0",\
  "--text-uic-3--textTransform": "none",\
  "--text-uic-3--stroke": "var(--palette-color2)",\
  "--text-uic-3--textAlign": "left",\
  "--text-uic-3--justifyContent": "flex-start",\
  "--text-uic-3--marginTop": "auto",\
  "--text-uic-3--marginBottom": "0",\
  "--text-uic-3--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-3--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-4--fontSize--desktop": "22px",\
  "--text-uic-4--fontSize--tablet": "22px",\
  "--text-uic-4--fontSize--mobile": "22px",\
  "--text-uic-4--fontFamily": "var(--font1)",\
  "--text-uic-4--fontWeight": "normal",\
  "--text-uic-4--fontType": "regular",\
  "--text-uic-4--fontStyle": "normal",\
  "--text-uic-4--fontStretch": "normal",\
  "--text-uic-4--lineHeight": "1.25",\
  "--text-uic-4--marginLeft": "0px",\
  "--text-uic-4--color": "var(--palette-color4)",\
  "--text-uic-4--borderBottomStyle": "none",\
  "--text-uic-4--textDecoration": "none",\
  "--text-uic-4--letterSpacing": "0",\
  "--text-uic-4--textTransform": "none",\
  "--text-uic-4--stroke": "var(--palette-color2)",\
  "--text-uic-4--textAlign": "left",\
  "--text-uic-4--justifyContent": "flex-start",\
  "--text-uic-4--marginTop": "auto",\
  "--text-uic-4--marginBottom": "0",\
  "--text-uic-4--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-4--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-5--fontSize--desktop": "22px",\
  "--text-uic-5--fontSize--tablet": "22px",\
  "--text-uic-5--fontSize--mobile": "22px",\
  "--text-uic-5--fontFamily": "var(--font1)",\
  "--text-uic-5--fontWeight": "normal",\
  "--text-uic-5--fontType": "regular",\
  "--text-uic-5--fontStyle": "normal",\
  "--text-uic-5--fontStretch": "normal",\
  "--text-uic-5--lineHeight": "1.25",\
  "--text-uic-5--marginLeft": "0px",\
  "--text-uic-5--color": "var(--palette-color3)",\
  "--text-uic-5--borderBottomStyle": "none",\
  "--text-uic-5--textDecoration": "none",\
  "--text-uic-5--letterSpacing": "0",\
  "--text-uic-5--textTransform": "none",\
  "--text-uic-5--stroke": "var(--palette-color2)",\
  "--text-uic-5--textAlign": "left",\
  "--text-uic-5--justifyContent": "flex-start",\
  "--text-uic-5--marginTop": "auto",\
  "--text-uic-5--marginBottom": "0",\
  "--text-uic-5--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-5--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-5--textShadow": "var(--text-style-unset)",\
\
  "--text-uic-6--fontSize--desktop": "16px",\
  "--text-uic-6--fontSize--tablet": "16px",\
  "--text-uic-6--fontSize--mobile": "16px",\
  "--text-uic-6--fontFamily": "var(--font2)",\
  "--text-uic-6--fontWeight": "normal",\
  "--text-uic-6--fontType": "bold",\
  "--text-uic-6--fontStyle": "normal",\
  "--text-uic-6--fontStretch": "normal",\
  "--text-uic-6--lineHeight": "1.5",\
  "--text-uic-6--marginLeft": "0px",\
  "--text-uic-6--color": "var(--palette-color7)",\
  "--text-uic-6--borderBottomStyle": "none",\
  "--text-uic-6--textDecoration": "none",\
  "--text-uic-6--letterSpacing": "0.12",\
  "--text-uic-6--textTransform": "none",\
  "--text-uic-6--stroke": "var(--palette-color2)",\
  "--text-uic-6--textAlign": "left",\
  "--text-uic-6--justifyContent": "flex-start",\
  "--text-uic-6--marginTop": "auto",\
  "--text-uic-6--marginBottom": "0",\
  "--text-uic-6--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-uic-6--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-uic-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-uic-6--textShadow": "var(--text-style-unset)",\
\
  "--text-closedcaptions--fontSize--desktop": "24px",\
  "--text-closedcaptions--fontSize--tablet": "24px",\
  "--text-closedcaptions--fontSize--mobile": "24px",\
  "--text-closedcaptions--fontFamily": "var(--font1)",\
  "--text-closedcaptions--fontWeight": "normal",\
  "--text-closedcaptions--fontType": "regular",\
  "--text-closedcaptions--fontStyle": "normal",\
  "--text-closedcaptions--fontStretch": "normal",\
  "--text-closedcaptions--lineHeight": "1.35",\
  "--text-closedcaptions--marginLeft": "0px",\
  "--text-closedcaptions--color": "var(--white)",\
  "--text-closedcaptions--borderBottomStyle": "none",\
  "--text-closedcaptions--textDecoration": "none",\
  "--text-closedcaptions--letterSpacing": "0",\
  "--text-closedcaptions--textTransform": "none",\
  "--text-closedcaptions--stroke": "var(--palette-color2)",\
  "--text-closedcaptions--textAlign": "center",\
  "--text-closedcaptions--justifyContent": "flex-start",\
  "--text-closedcaptions--marginTop": "auto",\
  "--text-closedcaptions--marginBottom": "0",\
  "--text-closedcaptions--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-closedcaptions--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-closedcaptions--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-closedcaptions--textShadow": "var(--text-style-unset)",\
\
  "--text-caption--fontSize--desktop": "24px",\
  "--text-caption--fontSize--tablet": "24px",\
  "--text-caption--fontSize--mobile": "24px",\
  "--text-caption--fontFamily": "var(--font1)",\
  "--text-caption--fontWeight": "normal",\
  "--text-caption--fontType": "regular",\
  "--text-caption--fontStyle": "normal",\
  "--text-caption--fontStretch": "normal",\
  "--text-caption--lineHeight": "1.35",\
  "--text-caption--marginLeft": "0px",\
  "--text-caption--color": "var(--palette-color6)",\
  "--text-caption--borderBottomStyle": "none",\
  "--text-caption--textDecoration": "none",\
  "--text-caption--letterSpacing": "0",\
  "--text-caption--textTransform": "none",\
  "--text-caption--stroke": "var(--palette-color2)",\
  "--text-caption--textAlign": "center",\
  "--text-caption--justifyContent": "flex-start",\
  "--text-caption--marginTop": "auto",\
  "--text-caption--marginBottom": "0",\
  "--text-caption--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_correct--fontSize--desktop": "24px",\
  "--text-caption_correct--fontSize--tablet": "24px",\
  "--text-caption_correct--fontSize--mobile": "24px",\
  "--text-caption_correct--fontFamily": "var(--font1)",\
  "--text-caption_correct--fontWeight": "normal",\
  "--text-caption_correct--fontType": "regular",\
  "--text-caption_correct--fontStyle": "normal",\
  "--text-caption_correct--fontStretch": "normal",\
  "--text-caption_correct--lineHeight": "1.35",\
  "--text-caption_correct--marginLeft": "0px",\
  "--text-caption_correct--color": "var(--palette-color6)",\
  "--text-caption_correct--borderBottomStyle": "none",\
  "--text-caption_correct--textDecoration": "none",\
  "--text-caption_correct--letterSpacing": "0",\
  "--text-caption_correct--textTransform": "none",\
  "--text-caption_correct--stroke": "var(--palette-color2)",\
  "--text-caption_correct--textAlign": "center",\
  "--text-caption_correct--justifyContent": "flex-start",\
  "--text-caption_correct--marginTop": "auto",\
  "--text-caption_correct--marginBottom": "0",\
  "--text-caption_correct--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_correct--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_correct--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_correct--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_incorrect--fontSize--desktop": "24px",\
  "--text-caption_incorrect--fontSize--tablet": "24px",\
  "--text-caption_incorrect--fontSize--mobile": "24px",\
  "--text-caption_incorrect--fontFamily": "var(--font1)",\
  "--text-caption_incorrect--fontWeight": "normal",\
  "--text-caption_incorrect--fontType": "regular",\
  "--text-caption_incorrect--fontStyle": "normal",\
  "--text-caption_incorrect--fontStretch": "normal",\
  "--text-caption_incorrect--lineHeight": "1.35",\
  "--text-caption_incorrect--marginLeft": "0px",\
  "--text-caption_incorrect--color": "var(--palette-color6)",\
  "--text-caption_incorrect--borderBottomStyle": "none",\
  "--text-caption_incorrect--textDecoration": "none",\
  "--text-caption_incorrect--letterSpacing": "0",\
  "--text-caption_incorrect--textTransform": "none",\
  "--text-caption_incorrect--stroke": "var(--palette-color2)",\
  "--text-caption_incorrect--textAlign": "center",\
  "--text-caption_incorrect--justifyContent": "flex-start",\
  "--text-caption_incorrect--marginTop": "auto",\
  "--text-caption_incorrect--marginBottom": "0",\
  "--text-caption_incorrect--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_incorrect--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_incorrect--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_incorrect--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_incomplete--fontSize--desktop": "24px",\
  "--text-caption_incomplete--fontSize--tablet": "24px",\
  "--text-caption_incomplete--fontSize--mobile": "24px",\
  "--text-caption_incomplete--fontFamily": "var(--font1)",\
  "--text-caption_incomplete--fontWeight": "normal",\
  "--text-caption_incomplete--fontType": "regular",\
  "--text-caption_incomplete--fontStyle": "normal",\
  "--text-caption_incomplete--fontStretch": "normal",\
  "--text-caption_incomplete--lineHeight": "1.35",\
  "--text-caption_incomplete--marginLeft": "0px",\
  "--text-caption_incomplete--color": "var(--palette-color6)",\
  "--text-caption_incomplete--borderBottomStyle": "none",\
  "--text-caption_incomplete--textDecoration": "none",\
  "--text-caption_incomplete--letterSpacing": "0",\
  "--text-caption_incomplete--textTransform": "none",\
  "--text-caption_incomplete--stroke": "var(--palette-color2)",\
  "--text-caption_incomplete--textAlign": "center",\
  "--text-caption_incomplete--justifyContent": "flex-start",\
  "--text-caption_incomplete--marginTop": "auto",\
  "--text-caption_incomplete--marginBottom": "0",\
  "--text-caption_incomplete--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_incomplete--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_incomplete--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_incomplete--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_hint--fontSize--desktop": "24px",\
  "--text-caption_hint--fontSize--tablet": "24px",\
  "--text-caption_hint--fontSize--mobile": "24px",\
  "--text-caption_hint--fontFamily": "var(--font1)",\
  "--text-caption_hint--fontWeight": "normal",\
  "--text-caption_hint--fontType": "regular",\
  "--text-caption_hint--fontStyle": "normal",\
  "--text-caption_hint--fontStretch": "normal",\
  "--text-caption_hint--lineHeight": "1.35",\
  "--text-caption_hint--marginLeft": "0px",\
  "--text-caption_hint--color": "var(--palette-color6)",\
  "--text-caption_hint--borderBottomStyle": "none",\
  "--text-caption_hint--textDecoration": "none",\
  "--text-caption_hint--letterSpacing": "0",\
  "--text-caption_hint--textTransform": "none",\
  "--text-caption_hint--stroke": "var(--palette-color2)",\
  "--text-caption_hint--textAlign": "center",\
  "--text-caption_hint--justifyContent": "flex-start",\
  "--text-caption_hint--marginTop": "auto",\
  "--text-caption_hint--marginBottom": "0",\
  "--text-caption_hint--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_hint--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_hint--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_hint--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_retry--fontSize--desktop": "24px",\
  "--text-caption_retry--fontSize--tablet": "24px",\
  "--text-caption_retry--fontSize--mobile": "24px",\
  "--text-caption_retry--fontFamily": "var(--font1)",\
  "--text-caption_retry--fontWeight": "normal",\
  "--text-caption_retry--fontType": "regular",\
  "--text-caption_retry--fontStyle": "normal",\
  "--text-caption_retry--fontStretch": "normal",\
  "--text-caption_retry--lineHeight": "1.35",\
  "--text-caption_retry--marginLeft": "0px",\
  "--text-caption_retry--color": "var(--palette-color6)",\
  "--text-caption_retry--borderBottomStyle": "none",\
  "--text-caption_retry--textDecoration": "none",\
  "--text-caption_retry--letterSpacing": "0",\
  "--text-caption_retry--textTransform": "none",\
  "--text-caption_retry--stroke": "var(--palette-color2)",\
  "--text-caption_retry--textAlign": "center",\
  "--text-caption_retry--justifyContent": "flex-start",\
  "--text-caption_retry--marginTop": "auto",\
  "--text-caption_retry--marginBottom": "0",\
  "--text-caption_retry--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_retry--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_retry--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_retry--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_timeout--fontSize--desktop": "24px",\
  "--text-caption_timeout--fontSize--tablet": "24px",\
  "--text-caption_timeout--fontSize--mobile": "24px",\
  "--text-caption_timeout--fontFamily": "var(--font1)",\
  "--text-caption_timeout--fontWeight": "normal",\
  "--text-caption_timeout--fontType": "regular",\
  "--text-caption_timeout--fontStyle": "normal",\
  "--text-caption_timeout--fontStretch": "normal",\
  "--text-caption_timeout--lineHeight": "1.35",\
  "--text-caption_timeout--marginLeft": "0px",\
  "--text-caption_timeout--color": "var(--palette-color6)",\
  "--text-caption_timeout--borderBottomStyle": "none",\
  "--text-caption_timeout--textDecoration": "none",\
  "--text-caption_timeout--letterSpacing": "0",\
  "--text-caption_timeout--textTransform": "none",\
  "--text-caption_timeout--stroke": "var(--palette-color2)",\
  "--text-caption_timeout--textAlign": "center",\
  "--text-caption_timeout--justifyContent": "flex-start",\
  "--text-caption_timeout--marginTop": "auto",\
  "--text-caption_timeout--marginBottom": "0",\
  "--text-caption_timeout--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-caption_timeout--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_timeout--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_timeout--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_1--fontSize--desktop": "18px",\
  "--text-caption_1--fontSize--tablet": "18px",\
  "--text-caption_1--fontSize--mobile": "16px",\
  "--text-caption_1--fontFamily": "var(--font2)",\
  "--text-caption_1--fontWeight": "normal",\
  "--text-caption_1--fontType": "regular",\
  "--text-caption_1--fontStyle": "normal",\
  "--text-caption_1--fontStretch": "normal",\
  "--text-caption_1--lineHeight": "1.2",\
  "--text-caption_1--marginLeft": "0px",\
  "--text-caption_1--color": "#FFFFFF",\
  "--text-caption_1--borderBottomStyle": "none",\
  "--text-caption_1--textDecoration": "none",\
  "--text-caption_1--letterSpacing": "0",\
  "--text-caption_1--textTransform": "none",\
  "--text-caption_1--stroke": "#00000000",\
  "--text-caption_1--textAlign": "left",\
  "--text-caption_1--justifyContent": "flex-start",\
  "--text-caption_1--marginTop": "auto",\
  "--text-caption_1--marginBottom": "0",\
  "--text-caption_1--defaultTextStroke": "1px #00000000",\
  "--text-caption_1--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_1--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_2--fontSize--desktop": "20px",\
  "--text-caption_2--fontSize--tablet": "20px",\
  "--text-caption_2--fontSize--mobile": "18px",\
  "--text-caption_2--fontFamily": "var(--font2)",\
  "--text-caption_2--fontWeight": "normal",\
  "--text-caption_2--fontType": "bold",\
  "--text-caption_2--fontStyle": "normal",\
  "--text-caption_2--fontStretch": "normal",\
  "--text-caption_2--lineHeight": "1.2",\
  "--text-caption_2--marginLeft": "0px",\
  "--text-caption_2--color": "#FFFFFF",\
  "--text-caption_2--borderBottomStyle": "none",\
  "--text-caption_2--textDecoration": "none",\
  "--text-caption_2--letterSpacing": "0",\
  "--text-caption_2--textTransform": "none",\
  "--text-caption_2--stroke": "#00000000",\
  "--text-caption_2--textAlign": "left",\
  "--text-caption_2--justifyContent": "flex-start",\
  "--text-caption_2--marginTop": "auto",\
  "--text-caption_2--marginBottom": "0",\
  "--text-caption_2--defaultTextStroke": "1px #00000000",\
  "--text-caption_2--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_2--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_3--fontSize--desktop": "24px",\
  "--text-caption_3--fontSize--tablet": "24px",\
  "--text-caption_3--fontSize--mobile": "22px",\
  "--text-caption_3--fontFamily": "var(--font1)",\
  "--text-caption_3--fontWeight": "normal",\
  "--text-caption_3--fontType": "italic",\
  "--text-caption_3--fontStyle": "normal",\
  "--text-caption_3--fontStretch": "normal",\
  "--text-caption_3--lineHeight": "1.2",\
  "--text-caption_3--marginLeft": "0px",\
  "--text-caption_3--color": "#FFFFFF",\
  "--text-caption_3--borderBottomStyle": "none",\
  "--text-caption_3--textDecoration": "none",\
  "--text-caption_3--letterSpacing": "0",\
  "--text-caption_3--textTransform": "none",\
  "--text-caption_3--stroke": "#00000000",\
  "--text-caption_3--textAlign": "left",\
  "--text-caption_3--justifyContent": "flex-start",\
  "--text-caption_3--marginTop": "auto",\
  "--text-caption_3--marginBottom": "0",\
  "--text-caption_3--defaultTextStroke": "1px #00000000",\
  "--text-caption_3--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_3--textShadow": "var(--text-style-unset)",\
\
  "--text-caption_4--fontSize--desktop": "22px",\
  "--text-caption_4--fontSize--tablet": "22px",\
  "--text-caption_4--fontSize--mobile": "20px",\
  "--text-caption_4--fontFamily": "var(--font2)",\
  "--text-caption_4--fontWeight": "normal",\
  "--text-caption_4--fontType": "italic",\
  "--text-caption_4--fontStyle": "normal",\
  "--text-caption_4--fontStretch": "normal",\
  "--text-caption_4--lineHeight": "1.3",\
  "--text-caption_4--marginLeft": "0px",\
  "--text-caption_4--color": "#666666",\
  "--text-caption_4--borderBottomStyle": "none",\
  "--text-caption_4--textDecoration": "none",\
  "--text-caption_4--letterSpacing": "0",\
  "--text-caption_4--textTransform": "none",\
  "--text-caption_4--stroke": "#00000000",\
  "--text-caption_4--textAlign": "left",\
  "--text-caption_4--justifyContent": "flex-start",\
  "--text-caption_4--marginTop": "auto",\
  "--text-caption_4--marginBottom": "0",\
  "--text-caption_4--defaultTextStroke": "1px #00000000",\
  "--text-caption_4--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-caption_4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-caption_4--textShadow": "var(--text-style-unset)",\
\
  "--text-comment-box--fontSize--desktop": "20px",\
  "--text-comment-box--fontSize--tablet": "20px",\
  "--text-comment-box--fontSize--mobile": "20px",\
  "--text-comment-box--fontFamily": "var(--font1)",\
  "--text-comment-box--fontWeight": "normal",\
  "--text-comment-box--fontType": "regular",\
  "--text-comment-box--fontStyle": "normal",\
  "--text-comment-box--fontStretch": "normal",\
  "--text-comment-box--lineHeight": "1.35",\
  "--text-comment-box--marginLeft": "0px",\
  "--text-comment-box--color": "var(--palette-color6)",\
  "--text-comment-box--borderBottomStyle": "none",\
  "--text-comment-box--textDecoration": "none",\
  "--text-comment-box--letterSpacing": "0",\
  "--text-comment-box--textTransform": "none",\
  "--text-comment-box--stroke": "var(--palette-color2)",\
  "--text-comment-box--textAlign": "center",\
  "--text-comment-box--justifyContent": "flex-start",\
  "--text-comment-box--marginTop": "auto",\
  "--text-comment-box--marginBottom": "0",\
  "--text-comment-box--defaultTextStroke": "1px var(--palette-color2)",\
  "--text-comment-box--WebkitTextStroke": "var(--text-style-unset)",\
  "--text-comment-box--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\
  "--text-comment-box--textShadow": "var(--text-style-unset)",\
\
  "--theme_image_default--strokeColor": "var(--palette-color1)",\
  "--theme_image_default--boxShadowColor": "var(--greyscale3)",\
\
  "--theme_image_greyscale--strokeColor": "var(--palette-color1)",\
  "--theme_image_greyscale--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_greyscale--intensity": 100,\
\
  "--theme_image_lighten--strokeColor": "var(--palette-color1)",\
  "--theme_image_lighten--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_lighten--intensity": 80,\
\
  "--theme_image_darken--strokeColor": "var(--palette-color1)",\
  "--theme_image_darken--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_darken--intensity": 80,\
\
  "--theme_image_overlay--strokeColor": "var(--palette-color1)",\
  "--theme_image_overlay--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_overlay--intensity": 80,\
  "--theme_image_overlay--primaryFillColor": "var(--palette-color2)",\
  "--theme_image_overlay--secondaryFillColor": "var(--palette-color1)",\
\
  "--theme_image_colorize--strokeColor": "var(--palette-color1)",\
  "--theme_image_colorize--boxShadowColor": "var(--greyscale3)",\
  "--theme_image_colorize--intensity": 80,\
  "--theme_image_colorize--primaryFillColor": "var(--palette-color4)",\
  "--theme_image_colorize--secondaryFillColor": "var(--palette-color1)",\
\
\
  "--button-normal--primaryColor": "var(--palette-color7)",\
  "--button-normal--borderColor": "var(--palette-color7)",\
  "--button-normal--shadowColor": "var(--greyscale3)",\
  "--text-button-normal--color": "var(--palette-color0)",\
  "--text-button-normal--fontFamily": "var(--font2)",\
  "--text-button-normal--fontType": "regular",\
  "--text-button-normal--fontSize--desktop": "16px",\
  "--text-button-normal--fontSize--tablet": "16px",\
  "--text-button-normal--fontSize--mobile": "16px",\
\
  "--button-selected--primaryColor": "var(--palette-color5)",\
  "--button-selected--borderColor": "var(--palette-color5)",\
  "--button-selected--shadowColor": "var(--greyscale3)",\
  "--text-button-selected--color": "var(--palette-color0)",\
  "--text-button-selected--fontFamily": "var(--font2)",\
  "--text-button-selected--fontType": "regular",\
  "--text-button-selected--fontSize--desktop": "16px",\
  "--text-button-selected--fontSize--tablet": "16px",\
  "--text-button-selected--fontSize--mobile": "16px",\
\
  "--button-disabled--primaryColor": "var(--palette-color3)",\
  "--button-disabled--borderColor": "var(--palette-color3)",\
  "--button-disabled--shadowColor": "var(--greyscale3)",\
  "--text-button-disabled--color": "var(--palette-color4)",\
  "--text-button-disabled--fontFamily": "var(--font2)",\
  "--text-button-disabled--fontType": "regular",\
  "--text-button-disabled--fontSize--desktop": "16px",\
  "--text-button-disabled--fontSize--tablet": "16px",\
  "--text-button-disabled--fontSize--mobile": "16px",\
\
  "--button-hover--primaryColor": "#112FA7",\
  "--button-hover--borderColor": "#112FA7",\
  "--button-hover--shadowColor": "var(--greyscale3)",\
  "--text-button-hover--color": "var(--palette-color0)",\
  "--text-button-hover--fontFamily": "var(--font2)",\
  "--text-button-hover--fontType": "regular",\
  "--text-button-hover--fontSize--desktop": "16px",\
  "--text-button-hover--fontSize--tablet": "16px",\
  "--text-button-hover--fontSize--mobile": "16px",\
\
  "--button-visited--primaryColor": "#112FA780",\
  "--button-visited--borderColor": "#112FA780",\
  "--button-visited--shadowColor": "var(--greyscale3)",\
  "--text-button-visited--color": "var(--palette-color0)",\
  "--text-button-visited--fontFamily": "var(--font2)",\
  "--text-button-visited--fontType": "regular",\
  "--text-button-visited--fontSize--desktop": "16px",\
  "--text-button-visited--fontSize--tablet": "16px",\
  "--text-button-visited--fontSize--mobile": "16px",\
\
  "--checkbox-normal--primaryColor": "var(--palette-color0)",\
  "--checkbox-normal--borderColor": "var(--palette-color3)",\
  "--checkbox-normal--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-normal--color": "var(--palette-color4)",\
  "--text-checkbox-normal--fontFamily": "var(--font1)",\
  "--text-checkbox-normal--fontType": "regular",\
  "--text-checkbox-normal--fontSize--desktop": "22px",\
  "--text-checkbox-normal--fontSize--tablet": "20px",\
  "--text-checkbox-normal--fontSize--mobile": "20px",\
\
  "--checkbox-selected--primaryColor": "var(--palette-color7)",\
  "--checkbox-selected--borderColor": "var(--palette-color4)",\
  "--checkbox-selected--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-selected--color": "var(--palette-color4)",\
  "--text-checkbox-selected--fontFamily": "var(--font1)",\
  "--text-checkbox-selected--fontType": "regular",\
  "--text-checkbox-selected--fontSize--desktop": "22px",\
  "--text-checkbox-selected--fontSize--tablet": "20px",\
  "--text-checkbox-selected--fontSize--mobile": "20px",\
\
  "--checkbox-disabled-checked--primaryColor": "var(--palette-color3)",\
  "--checkbox-disabled-checked--borderColor": "var(--palette-color3)",\
  "--checkbox-disabled-checked--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-disabled-checked--color": "var(--palette-color3)",\
  "--text-checkbox-disabled-checked--fontFamily": "var(--font1)",\
  "--text-checkbox-disabled-checked--fontType": "regular",\
  "--text-checkbox-disabled-checked--fontSize--desktop": "22px",\
  "--text-checkbox-disabled-checked--fontSize--tablet": "20px",\
  "--text-checkbox-disabled-checked--fontSize--mobile": "20px",\
\
  "--checkbox-hover--primaryColor": "var(--palette-color0)",\
  "--checkbox-hover--borderColor": "var(--palette-color3)",\
  "--checkbox-hover--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-hover--color": "var(--palette-color5)",\
  "--text-checkbox-hover--fontFamily": "var(--font1)",\
  "--text-checkbox-hover--fontType": "regular",\
  "--text-checkbox-hover--fontSize--desktop": "22px",\
  "--text-checkbox-hover--fontSize--tablet": "20px",\
  "--text-checkbox-hover--fontSize--mobile": "20px",\
\
  "--checkbox-disabled-unchecked--primaryColor": "var(--palette-color3)",\
  "--checkbox-disabled-unchecked--borderColor": "var(--palette-color3)",\
  "--checkbox-disabled-unchecked--shadowColor": "var(--greyscale3)",\
  "--text-checkbox-disabled-unchecked--color": "var(--palette-color3)",\
  "--text-checkbox-disabled-unchecked--fontFamily": "var(--font1)",\
  "--text-checkbox-disabled-unchecked--fontType": "regular",\
  "--text-checkbox-disabled-unchecked--fontSize--desktop": "22px",\
  "--text-checkbox-disabled-unchecked--fontSize--tablet": "20px",\
  "--text-checkbox-disabled-unchecked--fontSize--mobile": "20px",\
\
  "--inputfield-normal--primaryColor": "var(--palette-color0)", \
  "--inputfield-normal--borderColor": "var(--palette-color3)",\
  "--inputfield-normal--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-normal--color": "var(--palette-color4)",\
  "--text-inputfield-normal--fontFamily": "var(--font1)",\
  "--text-inputfield-normal--fontType": "regular",\
  "--text-inputfield-normal--fontSize--desktop": "18px",\
  "--text-inputfield-normal--fontSize--tablet": "20px",\
  "--text-inputfield-normal--fontSize--mobile": "20px",\
\
  "--inputfield-active--primaryColor": "var(--palette-color0)",\
  "--inputfield-active--borderColor": "var(--palette-color7)",\
  "--inputfield-active--shadowColor": "#var(--greyscale3)",\
  "--text-inputfield-active--color": "var(--palette-color4)",\
  "--text-inputfield-active--fontFamily": "var(--font1)",\
  "--text-inputfield-active--fontType": "regular",\
  "--text-inputfield-active--fontSize--desktop": "18px",\
  "--text-inputfield-active--fontSize--tablet": "20px",\
  "--text-inputfield-active--fontSize--mobile": "20px",\
\
  "--inputfield-disabled--primaryColor": "var(--palette-color3)",\
  "--inputfield-disabled--borderColor": "var(--palette-color3)",\
  "--inputfield-disabled--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-disabled--color": "var(--palette-color1)",\
  "--text-inputfield-disabled--fontFamily": "var(--font1)",\
  "--text-inputfield-disabled--fontType": "regular",\
  "--text-inputfield-disabled--fontSize--desktop": "18px",\
  "--text-inputfield-disabled--fontSize--tablet": "20px",\
  "--text-inputfield-disabled--fontSize--mobile": "20px",\
\
  "--inputfield-focusLost--primaryColor": "var(--palette-color0)",\
  "--inputfield-focusLost--borderColor": "var(--palette-color3)",\
  "--inputfield-focusLost--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-focusLost--color": "var(--palette-color4)",\
  "--text-inputfield-focusLost--fontFamily": "var(--font1)",\
  "--text-inputfield-focusLost--fontType": "regular",\
  "--text-inputfield-focusLost--fontSize--desktop": "18px",\
  "--text-inputfield-focusLost--fontSize--tablet": "20px",\
  "--text-inputfield-focusLost--fontSize--mobile": "20px",\
\
  "--inputfield-error--primaryColor": "var(--palette-color0)",\
  "--inputfield-error--borderColor": "var(--error)",\
  "--inputfield-error--shadowColor": "var(--greyscale3)",\
  "--text-inputfield-error--color": "var(--palette-color4)",\
  "--text-inputfield-error--fontFamily": "var(--font1)",\
  "--text-inputfield-error--fontType": "regular",\
  "--text-inputfield-error--fontSize--desktop": "18px",\
  "--text-inputfield-error--fontSize--tablet": "20px",\
  "--text-inputfield-error--fontSize--mobile": "20px",\
\
  "--dropdown-normal--primaryColor": "var(--palette-color0)",\
  "--dropdown-normal--borderColor": "var(--palette-color3)",\
  "--dropdown-normal--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-normal--color": "var(--palette-color4)",\
  "--text-dropdown-normal--fontFamily": "var(--font1)",\
  "--text-dropdown-normal--fontType": "italic",\
  "--text-dropdown-normal--fontSize--desktop": "18px",\
  "--text-dropdown-normal--fontSize--tablet": "18px",\
  "--text-dropdown-normal--fontSize--mobile": "18px",\
\
  "--dropdown-selected--primaryColor": "var(--palette-color0)",\
  "--dropdown-selected--borderColor": "var(--palette-color7)",\
  "--dropdown-selected--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-selected--color": "var(--palette-color4)",\
  "--text-dropdown-selected--fontFamily": "var(--font1)",\
  "--text-dropdown-selected--fontType": "italic",\
  "--text-dropdown-selected--fontSize--desktop": "18px",\
  "--text-dropdown-selected--fontSize--tablet": "18px",\
  "--text-dropdown-selected--fontSize--mobile": "18px",\
\
  "--dropdown-disabled--primaryColor": "var(--palette-color3)",\
  "--dropdown-disabled--borderColor": "var(--palette-color3)",\
  "--dropdown-disabled--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-disabled--color": "var(--palette-color1)",\
  "--text-dropdown-disabled--fontFamily": "var(--font1)",\
  "--text-dropdown-disabled--fontType": "italic",\
  "--text-dropdown-disabled--fontSize--desktop": "18px",\
  "--text-dropdown-disabled--fontSize--tablet": "18px",\
  "--text-dropdown-disabled--fontSize--mobile": "18px",\
\
  "--dropdown-hover--primaryColor": "var(--palette-color0)",\
  "--dropdown-hover--borderColor": "var(--palette-color3)",\
  "--dropdown-hover--shadowColor": "var(--greyscale3)",\
  "--text-dropdown-hover--color": "var(--palette-color4)",\
  "--text-dropdown-hover--fontFamily": "var(--font1)",\
  "--text-dropdown-hover--fontType": "italic",\
  "--text-dropdown-hover--fontSize--desktop": "18px",\
  "--text-dropdown-hover--fontSize--tablet": "18px",\
  "--text-dropdown-hover--fontSize--mobile": "18px",\
\
  "--radio-normal--primaryColor": "var(--palette-color0)",\
  "--radio-normal--borderColor": "var(--palette-color3)",\
  "--radio-normal--shadowColor": "var(--greyscale3)",\
  "--text-radio-normal--color": "var(--palette-color4)",\
  "--text-radio-normal--fontFamily": "var(--font1)",\
  "--text-radio-normal--fontType": "regular",\
  "--text-radio-normal--fontSize--desktop": "22px",\
  "--text-radio-normal--fontSize--tablet": "20px",\
  "--text-radio-normal--fontSize--mobile": "20px",\
\
  "--radio-selected--primaryColor": "var(--palette-color0)",\
  "--radio-selected--borderColor": "var(--palette-color4)",\
  "--radio-selected--shadowColor": "var(--greyscale3)",\
  "--text-radio-selected--color": "var(--palette-color4)",\
  "--text-radio-selected--fontFamily": "var(--font1)",\
  "--text-radio-selected--fontType": "regular",\
  "--text-radio-selected--fontSize--desktop": "22px",\
  "--text-radio-selected--fontSize--tablet": "20px",\
  "--text-radio-selected--fontSize--mobile": "20px",\
\
  "--radio-disabled-checked--primaryColor": "var(--palette-color3)",\
  "--radio-disabled-checked--borderColor": "var(--palette-color3)",\
  "--radio-disabled-checked--shadowColor": "var(--greyscale3)",\
  "--text-radio-disabled-checked--color": "var(--palette-color3)",\
  "--text-radio-disabled-checked--fontFamily": "var(--font1)",\
  "--text-radio-disabled-checked--fontType": "regular",\
  "--text-radio-disabled-checked--fontSize--desktop": "22px",\
  "--text-radio-disabled-checked--fontSize--tablet": "20px",\
  "--text-radio-disabled-checked--fontSize--mobile": "20px",\
\
  "--radio-hover--primaryColor": "var(--palette-color0)",\
  "--radio-hover--borderColor": "var(--palette-color3)",\
  "--radio-hover--shadowColor": "var(--greyscale3)",\
  "--text-radio-hover--color": "var(--palette-color5)",\
  "--text-radio-hover--fontFamily": "var(--font1)",\
  "--text-radio-hover--fontType": "regular",\
  "--text-radio-hover--fontSize--desktop": "22px",\
  "--text-radio-hover--fontSize--tablet": "20px",\
  "--text-radio-hover--fontSize--mobile": "20px",\
\
  "--radio-disabled-unchecked--primaryColor": "var(--palette-color3)",\
  "--radio-disabled-unchecked--borderColor": "var(--palette-color3)",\
  "--radio-disabled-unchecked--shadowColor": "var(--greyscale3)",\
  "--text-radio-disabled-unchecked--color": "var(--palette-color3)",\
  "--text-radio-disabled-unchecked--fontFamily": "var(--font1)",\
  "--text-radio-disabled-unchecked--fontType": "regular",\
  "--text-radio-disabled-unchecked--fontSize--desktop": "22px",\
  "--text-radio-disabled-unchecked--fontSize--tablet": "20px",\
  "--text-radio-disabled-unchecked--fontSize--mobile": "20px",\
\
  "--video_preset-color": "#666666",\
  "--video_preset-borderColor": "#666666",\
  \
  "--clickbox-preset-fill-color": "#3F80E4",\
\
  "--drag-object-default-state-fill-color": "255, 255, 255",\
  "--drag-object-hover-state-fill-color": "250, 250, 250",\
  "--drag-object-transition-state-fill-color": "250, 250, 250",\
  "--drag-object-dragOver-state-fill-color": "250, 250, 250",\
  "--drag-object-dropped-state-fill-color": "255, 255, 255",\
\
  "--drag-object-default-state-border-color": "214, 213, 209",\
  "--drag-object-hover-state-border-color": "214, 213, 209",\
  "--drag-object-transition-state-border-color": "214, 213, 209",\
  "--drag-object-dragOver-state-border-color": "230, 132, 80",\
  "--drag-object-dropped-state-border-color": "214, 213, 209",\
\
  "--drop-object-default-state-fill-color": "255, 255, 255",\
  "--drop-object-hover-state-fill-color": "255, 255, 255",\
  "--drop-object-dragOver-state-fill-color": "230, 132, 80",\
  "--drop-object-dropped-state-fill-color": "255, 255, 255",\
\
  "--drop-object-default-state-border-color": "42, 49, 62",\
  "--drop-object-hover-state-border-color": "230, 132, 80",\
  "--drop-object-dragOver-state-border-color": "230, 132, 80",\
  "--drop-object-dropped-state-border-color": "42, 49, 62"\
}',
uic_presets:'{\
  "cp_button_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-normal--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 1,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-hover--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 7,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 0.53\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-selected--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "--button-selected--shadowColor",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_visited": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-visited--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-visited--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-visited--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-disabled--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style": {\
    "fill": "var(--palette-color0)",\
    "fillOpacity": 1,\
    "stroke": "#707070",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_hover": {\
    "fill": "#9ec4f3",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 7,\
      "spread": null,\
      "color": "var(--black)",\
      "inset": null,\
      "opacity": 0.53\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_selected": {\
    "fill": "var(--palette-color5)",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_visited": {\
    "fill": "#0A00FF",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_disabled": {\
    "fill": "#0A00FF",\
    "fillOpacity": 1,\
    "stroke": "var(--color6)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_disabled_checked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-disabled-checked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-disabled-checked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-disabled-checked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_checkbox_shape_1_solid_style_disabled_unchecked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--checkbox-disabled-unchecked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--checkbox-disabled-unchecked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--checkbox-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_active": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-active--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-active--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-active--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_focusLost": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-focusLost--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-focusLost--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-focusLost--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_error": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-error--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-error--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-error--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_inputField_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--inputfield-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--inputfield-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--inputfield-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-normal--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-hover--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 0,\
      "y": 0,\
      "blur": 14,\
      "spread": null,\
      "color": "var(--dropdown-hover--shadowColor)",\
      "inset": null,\
      "opacity": 0.78\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-selected--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_dropDown_shape_1_solid_style_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-disabled--borderColor)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "video_preset_style": {\
    "fillEnable": 0,\
    "strokeEnable": 0,\
    "shadowEnable": 0,\
    "fill": "var(--video_preset-color)",\
    "fillOpacity": 1,\
    "stroke": "var(--video_preset-border)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_comment_box_shape_1_solid_style": {\
    "fill": "#F2B807",\
    "fillOpacity": 1,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_clickbox_shape_solid_style": {\
    "fill": "var(--clickbox-preset-fill-color)",\
    "fillOpacity": 0.6,\
    "stroke": "var(--palette-color3)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "2, 3",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-hover--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_visited": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-visited--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-visited--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_shape_1_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--button-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--button-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_default": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#333333",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#000000",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "button_navigate_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#D6D5D1",\
    "fillOpacity": 1,\
    "stroke": "#D6D5D1",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--button-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "dropdown_shape_1_disabled": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--dropdown-disabled--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--dropdown-disabled--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--dropdown-disabled--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_normal": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-normal--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-normal--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-normal--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_hover": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-hover--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-hover--borderColor)",\
    "strokeWidth": 3,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-hover--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_selected": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-selected--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-selected--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-selected--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_disabled_checked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-disabled-checked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-disabled-checked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-checked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "radio_shape_1_disabled_unchecked": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--radio-disabled-unchecked--primaryColor)",\
    "fillOpacity": 1,\
    "stroke": "var(--radio-disabled-unchecked--borderColor)",\
    "strokeWidth": 2,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_clicktoreveal_default": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 1,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "#ffffff",\
    "fillOpacity": 1,\
    "stroke": "#ffffff",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_linear_style": {\
    "meta": {\
      "fillEnable": 1,\
      "fillType": 3,\
      "strokeEnable": 1,\
      "shadowEnable": 0,\
      "type": 0,\
      "category": 0\
    },\
    "fill": "var(--palette-color0)",\
    "fillOpacity": 1,\
    "stroke": "var(--black)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "#FF335E",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "#ECA8B6",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color7)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color8)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  },\
  "cp_button_shape_8_solid_style_blue": {\
    "fill": "#ADD8E6",\
    "fillOpacity": 1,\
    "stroke": "var(--black)",\
    "strokeWidth": 1,\
    "strokeLinecap": "butt",\
    "strokeDasharray": "none",\
    "brightness": 0,\
    "contrast": 0,\
    "saturation": 0,\
    "sharpness": 0,\
    "boxShadow": {\
      "x": 1,\
      "y": 2,\
      "blur": 4,\
      "spread": null,\
      "color": "var(--greyscale3)",\
      "inset": null,\
      "opacity": 1\
    },\
    "gradientFill": {\
      "linearFill": {\
        "colorStops": [\
          {\
            "color": "#FF335E",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "#ECA8B6",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 0\
          },\
          {\
            "x": 50,\
            "y": 100\
          }\
        ]\
      },\
      "radialFill": {\
        "colorStops": [\
          {\
            "color": "var(--palette-color1)",\
            "alpha": 1,\
            "scaledPosition": 0\
          },\
          {\
            "color": "var(--palette-color0)",\
            "alpha": 1,\
            "scaledPosition": 1\
          }\
        ],\
        "endPoints": [\
          {\
            "x": 50,\
            "y": 50\
          },\
          {\
            "x": 100,\
            "y": 50\
          }\
        ],\
        "radialHandlePoints": [\
          {\
            "x": 50,\
            "y": 100\
          },\
          {\
            "x": 100,\
            "y": 100\
          }\
        ]\
      }\
    }\
  }\
}'
},
project_main:{
from:1,
to:0,
currentFrame:1,
featureFlags:{
isNewWidgetArchitecture:'{"isEnabled":true,"featureData":{}}'
}
,
useResponsive:true,
responsiveType:512,
isResponsiveSim:1,
currentFrame:1,
useWidgetVersion7:false,
isPublishedFromLacuna:false,
vestr:0,
vim:0,
slides:'Slide460,Slide604,Slide3409,Slide648,Slide782,Slide949,Slide1083,Slide1127,Slide1261,Slide1395,Slide3410,Slide1529,Slide1573,Slide1724,Slide1858,Slide1902,Slide2036,Slide2170,Slide2304,Slide2438,Slide2572,Slide2787,Slide2921,Slide2965,Slide3009,Slide3053,Slide3097,Slide3714',
questionSlides:'Slide3410',
slideVideos:['si1566','si3002','si3046','si3090'],
questions:'Slide3410q0',
autoplay:false,
preloader:true,
preloaderFileName:'dr/loading.gif',
preloaderPercentage:100,
pprtd:false,
peon:false,
fadeInAtStart:0,
fadeOutAtEnd:0
},
borderProperties:{
hasBorder:false
},
playBarProperties:{
hasPlayBar:true,
jsfile:'playbarScript.js',
cssfile:'playbarStyle.css',
position:3,
layout:3,
showOnHover:false,
overlay:true,
tworow:false,
hasRewind:true,
hasBackward:true,
hasPlay:true,
hasEnterVR:false,
hasSlider:true,
hasForward:true,
hasCC:false,
hasAudioOn:true,
hasExit:true,
hasFastForward:true,
applyColors:false,
alpha:100,
noToolTips:false,
locale:0
},
tocProperties:{
tocProperties:'{"tocConfig":{"labels":{"TITLE":"Table of Content","SLIDE_DETAILS":"SLIDE TITLE","DURATION":"DURATION","CLOSE_BUTTON_LABEL":"Close"},"slideDetails":[{"label":"Simulation slide 1","type":"slide","parentId":null,"id":"Slide460","isVisible":true,"slideVisited":false,"originalId":460,"labelShouldBeInSync":true},{"label":"Simulation slide 2","type":"slide","parentId":null,"id":"Slide604","isVisible":true,"slideVisited":false,"originalId":604,"labelShouldBeInSync":true},{"label":"Benefits of a Healthy Diet","type":"slide","parentId":null,"id":"Slide3409","isVisible":true,"slideVisited":false,"originalId":3409,"labelShouldBeInSync":true},{"label":"Simulation slide 3","type":"slide","parentId":null,"id":"Slide648","isVisible":true,"slideVisited":false,"originalId":648,"labelShouldBeInSync":true},{"label":"Simulation slide 4","type":"slide","parentId":null,"id":"Slide782","isVisible":true,"slideVisited":false,"originalId":782,"labelShouldBeInSync":true},{"label":"Simulation slide 5","type":"slide","parentId":null,"id":"Slide949","isVisible":true,"slideVisited":false,"originalId":949,"labelShouldBeInSync":true},{"label":"Simulation slide 6","type":"slide","parentId":null,"id":"Slide1083","isVisible":true,"slideVisited":false,"originalId":1083,"labelShouldBeInSync":true},{"label":"Simulation slide 7","type":"slide","parentId":null,"id":"Slide1127","isVisible":true,"slideVisited":false,"originalId":1127,"labelShouldBeInSync":true},{"label":"Simulation slide 8","type":"slide","parentId":null,"id":"Slide1261","isVisible":true,"slideVisited":false,"originalId":1261,"labelShouldBeInSync":true},{"label":"Simulation slide 9","type":"slide","parentId":null,"id":"Slide1395","isVisible":true,"slideVisited":false,"originalId":1395,"labelShouldBeInSync":true},{"label":"True or false 1","type":"slide","parentId":null,"id":"Slide3410","isVisible":true,"slideVisited":false,"originalId":3410,"labelShouldBeInSync":true},{"label":"Simulation slide 10","type":"slide","parentId":null,"id":"Slide1529","isVisible":true,"slideVisited":false,"originalId":1529,"labelShouldBeInSync":true},{"label":"Simulation slide 11","type":"slide","parentId":null,"id":"Slide1573","isVisible":true,"slideVisited":false,"originalId":1573,"labelShouldBeInSync":true},{"label":"Simulation slide 12","type":"slide","parentId":null,"id":"Slide1724","isVisible":true,"slideVisited":false,"originalId":1724,"labelShouldBeInSync":true},{"label":"Simulation slide 13","type":"slide","parentId":null,"id":"Slide1858","isVisible":true,"slideVisited":false,"originalId":1858,"labelShouldBeInSync":true},{"label":"Simulation slide 14","type":"slide","parentId":null,"id":"Slide1902","isVisible":true,"slideVisited":false,"originalId":1902,"labelShouldBeInSync":true},{"label":"Simulation slide 15","type":"slide","parentId":null,"id":"Slide2036","isVisible":true,"slideVisited":false,"originalId":2036,"labelShouldBeInSync":true},{"label":"Simulation slide 16","type":"slide","parentId":null,"id":"Slide2170","isVisible":true,"slideVisited":false,"originalId":2170,"labelShouldBeInSync":true},{"label":"Simulation slide 17","type":"slide","parentId":null,"id":"Slide2304","isVisible":true,"slideVisited":false,"originalId":2304,"labelShouldBeInSync":true},{"label":"Simulation slide 18","type":"slide","parentId":null,"id":"Slide2438","isVisible":true,"slideVisited":false,"originalId":2438,"labelShouldBeInSync":true},{"label":"Simulation slide 19","type":"slide","parentId":null,"id":"Slide2572","isVisible":true,"slideVisited":false,"originalId":2572,"labelShouldBeInSync":true},{"label":"Simulation slide 20","type":"slide","parentId":null,"id":"Slide2787","isVisible":true,"slideVisited":false,"originalId":2787,"labelShouldBeInSync":true},{"label":"Simulation slide 21","type":"slide","parentId":null,"id":"Slide2921","isVisible":true,"slideVisited":false,"originalId":2921,"labelShouldBeInSync":true},{"label":"Simulation slide 22","type":"slide","parentId":null,"id":"Slide2965","isVisible":true,"slideVisited":false,"originalId":2965,"labelShouldBeInSync":true},{"label":"Simulation slide 23","type":"slide","parentId":null,"id":"Slide3009","isVisible":true,"slideVisited":false,"originalId":3009,"labelShouldBeInSync":true},{"label":"Simulation slide 24","type":"slide","parentId":null,"id":"Slide3053","isVisible":true,"slideVisited":false,"originalId":3053,"labelShouldBeInSync":true},{"label":"Simulation slide 25","type":"slide","parentId":null,"id":"Slide3097","isVisible":true,"slideVisited":false,"originalId":3097,"labelShouldBeInSync":true},{"label":"Result 1","type":"slide","parentId":null,"id":"Slide3714","isVisible":true,"slideVisited":false,"originalId":3714,"labelShouldBeInSync":true}],"tocGeneratedOnPreviewClick":true,"preserveSlidesOrder":true},"playbarConfig":{"isPlaybarControlsPlayEnabled":true,"isPlaybarControlsNextEnabled":true,"isPlaybarControlsTOCEnabled":true,"isShowPlaybarEnabled":true,"isShowTooltipsEnabled":true,"isPlaybarControlsBackEnabled":true,"isHidePlaybarInQuizEnabled":false,"isPlaybarControlsMuteEnabled":true,"isPlaybarControlsClosedCaptionsEnabled":false}}'
},
trecs:[{
link:460,
text:[]
}
,{
link:604,
text:[]
}
,{
link:3409,
text:[]
}
,{
link:648,
text:[]
}
,{
link:782,
text:[]
}
,{
link:949,
text:[]
}
,{
link:1083,
text:[]
}
,{
link:1127,
text:[]
}
,{
link:1261,
text:[]
}
,{
link:1395,
text:[]
}
,{
link:3410,
text:[]
}
,{
link:1529,
text:[]
}
,{
link:1573,
text:[]
}
,{
link:1724,
text:[]
}
,{
link:1858,
text:[]
}
,{
link:1902,
text:[]
}
,{
link:2036,
text:[]
}
,{
link:2170,
text:[]
}
,{
link:2304,
text:[]
}
,{
link:2438,
text:[]
}
,{
link:2572,
text:[]
}
,{
link:2787,
text:[]
}
,{
link:2921,
text:[]
}
,{
link:2965,
text:[]
}
,{
link:3009,
text:[]
}
,{
link:3053,
text:[]
}
,{
link:3097,
text:[]
}
]

,
typekit:{
kit_id:''
},
};
cp.model.projectImages=[
'assets/htmlimages/Answer_checkbox_correct.png',
'assets/htmlimages/Answer_checkbox_hover.png',
'assets/htmlimages/Answer_checkbox_incorrect.png',
'assets/htmlimages/Answer_checkbox_normal.png',
'assets/htmlimages/Answer_checkbox_select.png',
'assets/htmlimages/Answer_radio_correct.png',
'assets/htmlimages/Answer_radio_hover.png',
'assets/htmlimages/Answer_radio_incorrect.png',
'assets/htmlimages/Answer_radio_normal.png',
'assets/htmlimages/Answer_radio_select.png',
'assets/htmlimages/Graph.jpg',
'assets/htmlimages/HotspotDisplayImage.png',
'assets/htmlimages/HotspotDisplayText.png',
'assets/htmlimages/HotspotQuestionOverlays.png',
'assets/htmlimages/ThreeD_Close.svg',
'assets/htmlimages/ThreeD_HotspotDefaultGlow.png',
'assets/htmlimages/ThreeD_HotspotGlow.png',
'assets/htmlimages/VR_move_left.png',
'assets/htmlimages/VR_move_right.png',
'assets/htmlimages/assessmenthotspotvisited.svg',
'assets/htmlimages/checkboxchecked.png',
'assets/htmlimages/checkboxunchecked.png',
'assets/htmlimages/correct_answer_normal.png',
'assets/htmlimages/correct_answer_small.png',
'assets/htmlimages/correct_question_normal.png',
'assets/htmlimages/correct_question_small.png',
'assets/htmlimages/expand_icon.png',
'assets/htmlimages/img_trans.gif',
'assets/htmlimages/incorrect_answer_normal.png',
'assets/htmlimages/incorrect_answer_small.png',
'assets/htmlimages/incorrect_question_normal.png',
'assets/htmlimages/incorrect_question_small.png',
'assets/htmlimages/partial_correct_question_normal.png',
'assets/htmlimages/partial_correct_question_small.png',
'assets/htmlimages/placeholder.png',
'assets/htmlimages/radioButton_disabled.png',
'assets/htmlimages/radioButton_normal.png',
'assets/htmlimages/radioButton_selected.png',
'assets/htmlimages/radioButton_selectedDisabled.png',
'assets/htmlimages/radiochecked.png',
'assets/htmlimages/radiounchecked.png',
'assets/htmlimages/skip_answer_normal.png',
'assets/htmlimages/skip_answer_small.png',
'assets/htmlimages/skip_question_normal.png',
'assets/htmlimages/skip_question_small.png'
];
cp.model.data.images=[{
ip:'dr/01117.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01161.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01295.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01429.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01562.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01607.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01758.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01892.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01936.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02070.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02204.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02338.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02472.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02606.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02821.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02955.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02998.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03042.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03086.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03131.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03274.jpeg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03318.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03404.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03493.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03519.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03537.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/04015.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0494.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0638.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0682.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0816.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0983.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/sfs0.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/sfs1.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/sfs2.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/sfs3.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/sfs4.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/sfs5.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
];
cp.model.videos=[
];
cp.model.slideVideos=[
'vr/Vi1555.mp4',
'vr/Vi2991.mp4',
'vr/Vi3035.mp4',
'vr/Vi3079.mp4'
];
cp.model.tocVideos=[
];
cp.model.audios=[
];

cp.initVariables = function(){
cp.cv('CaptivateVersion','12.2.0',1,1000,0);
cp.cv('Date.DateDDMMYY','dd/mm/yyyy',1,15,0);
cp.cv('Date.DateMMDDYY','mm/dd/yyyy',1,15,0);
cp.cv('Date.Day',1,1,15,0);
cp.cv('Date.Hours','hh',1,15,0);
cp.cv('Date.LocaleString','',1,15,0);
cp.cv('Date.Minutes','mm',1,15,0);
cp.cv('Date.Month','mm',1,15,0);
cp.cv('Date.Time','hh:mm:ss',1,15,0);
cp.cv('Date.Today','dd',1,15,0);
cp.cv('Date.Year','yyyy',1,15,0);
cp.cv('Project.AudioLevel',100,1,15,0);
cp.cv('Project.ClosedCaptions',1,1,15,0);
cp.cv('Project.CurrentSlideName','slide',1,15,0);
cp.cv('Project.CurrentSlideNumber',1,1,15,0);
cp.cv('Project.LockTOC',0,1,15,0);
cp.cv('Project.MuteAudio',0,1,15,0);
cp.cv('Project.ShowPlaybar',1,1,15,0);
cp.cv('Project.ShowTOC',0,1,15,0);
cp.cv('Project.SlideCount',1,1,15,0);
cp.cv('Question.AnswerChoice','',1,15,0);
cp.cv('Question.MaxAttempts',0,1,15,0);
cp.cv('Question.NegativePoints',0,1,15,0);
cp.cv('Question.PointsAssigned',0,1,15,0);
cp.cv('Question.PreviousQuestionScore',0,1,15,0);
cp.cv('Quiz.AttemptCount',0,1,15,0);
cp.cv('Quiz.CorrectAnswerCount',0,1,15,0);
cp.cv('Quiz.InReview',0,1,15,0);
cp.cv('Quiz.InScope',0,1,15,0);
cp.cv('Quiz.MaxScore',0,1,1000,0);
cp.cv('Quiz.Pass',0,1,15,0);
cp.cv('Quiz.PassPercentage',80,1,1000,0);
cp.cv('Quiz.PassPoints',0,1,1000,0);
cp.cv('Quiz.PercentageScore',0,1,15,0);
cp.cv('Quiz.QuestionCount',1,1,1000,0);
cp.cv('Quiz.Score',0,1,15,0);
cp.cv('Quiz.UnansweredQuestionCount',1,1,1000,0);
cp.cv('cpInfoHasPlaybar',1,1,1000,0);
cp.cv('cpInfoSlidesInProject',28,1,1000,0);
cp.cv('cpLockTOC',0,1,1000,0);
cp.cv('cpQuizInfoPreTestTotalQuestions',0,1,1000,0);
cp.cv('cpQuizInfoTotalQuizPoints',0,1,1000,0);
cp.cv('cpInfoPrevFrame',0,1,15,0);
cp.cv('LMS.CourseName','',0,15,0);
cp.cv('LMS.LearnerID','',0,15,0);
cp.cv('LMS.LearnerName','',0,15,0);
cp.cv('variableEditBoxStr_1','',0,15,0);
};cp.ReportingVariables="LMS.CourseName,LMS.LearnerID,LMS.LearnerName,variableEditBoxStr_1,";
};cp.sbw=0;cp.useg=0;cp.geo=0;cp.pg=0;cp.win8=0;cp.autoGrow=1;cp.fluidFont=1;
